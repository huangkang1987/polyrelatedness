#ifndef ML2_H
#define ML2_H
#include <iostream>
using namespace std;
void ml_assign2(double *f, int *a, double *c, int IBS);
#endif