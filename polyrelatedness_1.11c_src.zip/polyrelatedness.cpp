/*
 PolyRelatedness V1.11c
 -- Calculate relatedness coefficient for polyploids.
 
 Author      Kang Huang
 Affiliation Northwest University
 Email       huangkang@nwu.edu.cn
 Update      2023/10/21
 */

#define ESTIMATOR_NUM (18)
#pragma comment(linker, "/STACK:20971520")
#ifdef WIN64
	unsigned int __stdcall ThreadFunc(void * p);
	#include <windows.h>
	#include <process.h>
	#include <direct.h>
	CRITICAL_SECTION lock1;
	#define SLEEP(x) Sleep(x)
	#define lock_(x) EnterCriticalSection(x)
	#define unlock_(x) LeaveCriticalSection(x)
	
	typedef unsigned int uint;
	typedef unsigned short ushort;
	typedef unsigned char byte;
	typedef unsigned __int64 uint64;
	typedef __int64 int64;

	#pragma warning(disable:4996)
	#pragma warning(disable:4366)
#else
	void* ThreadFunc(void * p);
	#include <pthread.h>
	#include <sys/types.h>
	#include <unistd.h>
	pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;

	#define SLEEP(x) usleep((x)*1000)
	#define lock_(x) pthread_mutex_lock(x)
	#define unlock_(x) pthread_mutex_unlock(x)
	
	typedef unsigned int uint;
	typedef unsigned short ushort;
	typedef unsigned char byte;
	typedef unsigned long long uint64;
	typedef long long int64;
	typedef pthread_attr_t HANDLE;
#endif

#ifdef linux
	pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <math.h>
#include <time.h>
#include "ml.h"
#include "mom.h"

#ifdef __APPLE__
	#include <mach-o/dyld.h>
#endif

using namespace std;

#define VERSION ("1.11c")

//ploidy identifier in polyploid moment estimators
#define CPM1	(1)
#define CPM1P	(2)
#define CPM2	(2)
#define CPM2P	(3)
#define CPM3	(3)
#define CPM3P	(4)
#define CPM4	(4)
#define CPM4P	(5)
#define CPM5	(5)
#define CPM5P	(6)
#define CPM6	(6)
#define CPM6P	(7)
#define CPM7	(7)
#define CPM7P	(8)
#define CPM8	(8)
#define CPM8P	(9)

//the stop threshold of likelihood difference in the best and worse point of the simplex
#define LIKESTOP1 (1e-8)

//maximum iteration in downhill simplex
#define MAX_ITER_ML (1200)

//other limitations
#define MAX_WEIGHT (1e300)
#define MAX_ITERA (60)
#define MIN_DOUBLE (1e-30)
#define MINLIKELIHOOD (-1e100)
#define MAXALLELES (65536)
#define MAXLOCUS (65536)
#define MAXINDS (65536)
#define MAXTHREAD (64)
#define MAXPLOIDY (8)
#define MAXPLOIDYP (9)
#define MAXPLOIDY2 (64)
#define MISSING_ALLELE (-1)
#define AMBIGUOUS_ALLELE (-2)
#define NULL_ALLELE (-3)
#define BUFLEN (400000)
#define EPS (1e-100)

//fractions frequently used
#define f12 (0.5)
#define f23 (0.6666666666666666667)
#define f13 (0.3333333333333333333)
#define f34 (0.75)
#define f24 (0.5)
#define f14 (0.25)
#define f45 (0.8)
#define f35 (0.6)
#define f25 (0.4)
#define f15 (0.2)
#define f56 (0.8333333333333333333)
#define f46 (0.6666666666666666667)
#define f36 (0.5)
#define f26 (0.3333333333333333333)
#define f16 (0.1666666666666666667)
#define f67 (0.857142857142857143)
#define f57 (0.714285714285714286)
#define f47 (0.571428571428571429)
#define f37 (0.428571428571428571)
#define f27 (0.285714285714285714)
#define f17 (0.142857142857142857)
#define f78 (0.875)
#define f68 (0.75)
#define f58 (0.625)
#define f48 (0.5)
#define f38 (0.375)
#define f28 (0.25)
#define f18 (0.125)

//refreash interval for process bar
#define SLEEP_TIME 10

#pragma pack(1)

int thread_count;

bool iscommand;

struct ThreadPar
{
	//Multiple thread processing information
	void * a;
	int id;
	int total;
	int fun;
	int popid;
};

struct GENOTYPE
{
	//genotype information, different loci may have different ploidy
	int *ploidy;
	int *a;
	int *b;
	int *c;
	int *d;
	int *e;
	int *f;
	int *g;
	int *h;
};

struct IND
{
	char *name;
	int id;
	int popid;
	GENOTYPE genotype;
};

struct POP
{
	char *name;
	int popid;
	vector <IND> inds;
	double **freobs;
	double **frenull;
	int frecalced;
	double* Hs;
};

struct LOCUS
{
	char *name;
	int n; //number of observed alleles
	int typed;
	int maxploidy;
	double weight;
	double rate;
	double AR;//Allelic richeness
	double py;// frequency of null alleles
	double C1, C2, C3, C4, C5, C6;
	double A0, A02, A1, A12, A13, A2, A22, A3, A4;
	double Au;
};

template <typename T1, typename T2>
class FASTTABLE
{
public:
	struct entry2
	{
		T1 key;
		T2 val;
	};
	entry2 *bucket;
	uint *index;
	uint shift;
	uint size;

	FASTTABLE()
	{
		bool haslist = true;
		shift = 0x7;
		size = 0;
		byte* buf;
		buf = new byte[(sizeof(entry2) + (haslist ? sizeof(uint) : 0)) * (shift + 1)];

		bucket = (entry2*)buf;
		index = (uint*)(haslist ? buf + sizeof(entry2) * (shift + 1) : 0);
		Clear();
	}

	void Clear()
	{
		memset(bucket, 0xFF, (sizeof(entry2) + (index ? sizeof(uint) : 0)) * (shift + 1));
		size = 0;
	}

	~FASTTABLE()
	{
		delete[] bucket;
		bucket = NULL;
		index = 0;
		size = 0;
		shift = 1;
	}

	entry2& GetEntry(int i)
	{
		return bucket[index[i]];
	}

	T2& operator()(int i)
	{
		return bucket[index[i]].val;
	}

	void Expand()
	{
		uint shift2 = ((shift + 1) << 1) - 1;
		int nlen = (sizeof(entry2) + (index ? sizeof(uint) : 0)) * (shift2 + 1);

		byte* buf;
		buf = new byte[nlen];

		memset(buf, 0xFF, nlen);
		entry2* nbucket = (entry2*)buf;
		auto nindex = (uint*)(index ? buf + sizeof(entry2) * (shift2 + 1) : 0);

		if (index)
		{
			for (uint i = 0; i < size; ++i)
			{
				uint st = bucket[index[i]].key & shift2;
				for (uint j = 0; j <= shift2; ++j)
					if (nbucket[(j + st) & shift2].key == (T1)-1)
					{
						nbucket[nindex[i] = ((j + st) & shift2)] = bucket[index[i]];
						break;
					}
			}
			index = nindex;
		}
		else for (uint i = 0; i <= shift; ++i)
		{
			T1 key = bucket[i].key;
			if (key == (T1)-1) continue;
			uint st = key & shift2;
			for (uint j = 0; j <= shift2; ++j)
				if (nbucket[(j + st) & shift2].key == (T1)-1)
				{
					nbucket[(j + st) & shift2] = bucket[i];
					break;
				}
		}
		delete[] bucket; bucket = nbucket;
		shift = shift2;
	}

	bool HasKey(T1 key)
	{
		//val is genotype or haplotype
		uint st = key & shift;
		for (uint i = 0; i <= shift; ++i)
		{
			uint idx = (i + st) & shift;
			T1 k = bucket[idx].key;
			if (k == (T1)-1) return false;
			if (k != key) continue;
			return true;
		}
		return true;
	}

	T2& operator[](T1 key)
	{
restart:
		//val is genotype or haplotype
		uint st = key & shift;
		for (uint i = 0; i <= shift; ++i)
		{
			uint idx = (i + st) & shift;
			T1 k = bucket[idx].key;
			if (k == (T1)-1)
			{
				if ((size << 1) >= shift) 
				{ 
					Expand();
					goto restart;
				}
				 //insert new key
				bucket[idx].key = key;
				if (index) index[size] = (ushort)idx;
				size++;
				return bucket[idx].val;
			}
			if (k == key)
				return bucket[idx].val;
		}
		return bucket[0].val;
	}
};

int main(int argc, char** argv);

void EXIT(char *a)
{
	printf(a);
	if (!iscommand)
	{
#ifdef WIN64
		fflush(stdin);
#else
		setbuf(stdin, NULL);
#endif

#ifdef WIN64
		system("pause");
#else
		printf("Press ENTER to continue...\r\n");
		getchar();
#endif
	}
	if (iscommand)
		exit(0);
	else
		main(-1, NULL);
}

void fpause(void)
{
#ifdef WIN64
		system("pause");
#else
		printf("Press ENTER to continue...\r\n");
		getchar();
#endif
}

void quickSort(double *s, int l, int r)  
{  
    if (l< r)  
    {        
        int i = l, j = r;
		double x = s[l];  
        while (i < j)  
        {  
            while (i < j && s[j]>= x) 
                j--;   
            if (i < j)  
                s[i++] = s[j];  
            while (i < j && s[i]< x)
                i++;   
            if (i < j)  
                s[j--] = s[i];  
        }  
        s[i] = x;  
        quickSort(s, l, i - 1);
        quickSort(s, i + 1, r);  
    }  
}

void init(FASTTABLE<uint, uint>* maps, uint64 **codes)
{
	//Reading genotype patterns for polyploid Maximum-likelihood estimator
	struct ts{
		uint64 a;
		unsigned int b;
	};
	int len[] = {2, 9, 31, 109, 339, 1043, 2998, 8405};
	FILE * f1 = fopen("Polyrelatedness_data.bin", "rb");
	if (!f1) 
	{
		iscommand = true;
		EXIT("Error: Can not open file Polyrelatedness_data.bin.\r\n");
	}
	ts* data = new ts[12936];
	fread(data, 1, 12 * 12936, f1);
	fclose(f1);
	int count = 0;
#ifdef linux
	lock_(&lock2);
#endif
	for (int p = 0; p < 8; ++p)
	{
		auto m = maps + p;
		uint64* c = codes[p];
		for (int i = 1; i <= len[p]; ++i)
		{
			c[i] = data[count].a;	
			(*m)[data[count].b] = i;
			count++;
		}
	}
#ifdef linux
	unlock_(&lock2);
#endif
	delete[] data;
}
int linecmp(const char *a, const char *b)
{
	for (int i = 0; ; ++i)
	{
		if (a[i] == '\r' || a[i] == '\n')
			break;
		if (a[i] == 0)
			break;
		if (a[i] != b[i])
			return 1;
	}
	return 0;
}
void StrLwr(char *a)
{
	while (*a)
	{
		if (*a >= 65 && *a <= 90)
			*a += 32;
		a++;
	}
}
int ReadInteger(char* data, int ndigits, int& re)
{
	re = 0;
	for (int i = 0; i < ndigits; ++i)
	{
		char b = *data++;
		if (b < '0' || b > '9') return -1;
		re = re * 10 + (b - '0');
	}
	return 0;
}
char *estimator_name[] = {"Huang et al. 2014 MOM", "Huang et al. 2015 ML", "Ritland 1996 corrected", "Loiselle et al. 1995 corrected", "Ritland 1996", "Loiselle et al. 1995", "Weir 1996", "Lynch & Ritland 1999", "Wang 2002", "Thomas 2010", "Thomas 2010 weighted by Wang 2002", "Li et al. 1993", "Queller & Goodnight 1989", "Huang 2016 diploid A", "Huang 2016 diploid B", "Anderson & Weir 2007", "Milligan 2003", "Milligan 2003 for inbreeding"};

class Relatedness
{
public:
	int L;//Number of Locus
	int N;//Number of Inds
	int nPops;//Number of Populations
	int method;
	bool rem;
	LOCUS *Locus;
	char *output;
	char *input;
	FASTTABLE<int, int> *allele;
	vector<POP> pops;
	vector<IND> inds;
	int outputdigits;
	double **freobs;
	double **frenull;
	double *r4;
	double FST;
	int PLOIDY;
	double *deltas;
	double *cdeltas;
	int bi[9][9];
	int nsim;
	
	int getcandidate_tempxx[MAXPLOIDY];
	int getcandidate_l;
	int getcandidate_xx_count;
	int getcandidate_xx_count2[MAXPLOIDY];
	int getcandidate_cx;
	int getcandidate_x[MAXPLOIDY];
	int* getcandidate_xx;
	double* getcandidate_p;
	int getcandidate_ploidy;
	int getcandidate_alignment;
	int *ncandidate;
	double **pcandidate;
	bool Huang2012ML_Initialized;
	double **Huang2012ML_Coef;
	FASTTABLE<uint,uint>* maps;
	uint64 **codes;
	bool R_Anderson_Initialized;
	bool L_Anderson_Coef_Calced;
	double **L_Anderson_Coef;
	int (*pp)[4];
	int *IBS2;
	bool issim;
	int maxallele;
	int ndigits;

	double nan;
	double r1[ESTIMATOR_NUM];//simulation r
	double r2[ESTIMATOR_NUM];//simulation r^2
	double* r3[ESTIMATOR_NUM];//simulation distributin of r
	int nthread;
	bool isreal;

	//Matrix operations and misc
	double maxdiag(double *a, int m, int n)
	{
		double re = a[0];
		int e = min(m, n);
		for (int i = 1; i < e; ++i)
			if (re < a[i * n + i])
				re = a[i * n + i];
		return re;
	}
	int max2(int a, int b)
	{
		return a > b ? a : b;
	}
	int min2(int a, int b)
	{
		return a > b ? b : a;
	}
	int mul(double *l, int lr, int lc, double *r, int rr, int rc, double *res)
	{
		if (lc != rr)
			return -1;
		int i, j, k;
		for (i = 0; i < lr; i++)
		{
			for (j = 0; j < rc; j++)
			{
				res[i * rc + j] = 0;
				for (k = 0; k < lc; k++)
					res[i * rc + j] += l[i * lc + k] * r[k * rc + j];
			}
		}
		return 0;
	}
	int inv(double *M, int m)
	{
		double *a = new double[m * m];
		int n = m;
		int *is, *js, i, j, k, l, u, v;
		double d, p;
		for (i = 0; i < m; i++)
			for (j = 0; j < m; j++)
				a[i * m + j] = M[i * m + j];
		is = new int[n];
		js = new int[n];
		for (k = 0; k <= n - 1; k++)
		{
			d = 0.0;
			for (i = k; i <= n - 1; i++)
				for (j = k; j <= n - 1; j++)
				{
					l = i * n + j;
					p = fabs(a[l]);
					if (p > d)
					{
						d = p;
						is[k] = i;
						js[k] = j;
					}
				}
			if (d < 2.220446049250313e-016)
			{
				delete[] a;
				delete[] is;
				delete[] js;
				return -1;
			}
			if (is[k] != k)
				for (j = 0; j <= n - 1; j++)
				{
					u = k * n + j;
					v = is[k] * n + j;
					p = a[u];
					a[u] = a[v];
					a[v] = p;
				}
			if (js[k] != k)
				for (i = 0; i <= n - 1; i++)
				{
					u = i * n + k;
					v = i * n + js[k];
					p = a[u];
					a[u] = a[v];
					a[v] = p;
				}
			l = k * n + k;
			a[l] = 1.0 / a[l];
			for (j = 0; j <= n - 1; j++)
				if (j != k)
				{
					u = k * n + j;
					a[u] = a[u] * a[l];
				}
			for (i = 0; i <= n - 1; i++)
				if (i != k)
					for (j = 0; j <= n - 1; j++)
						if (j != k)
						{
							u = i * n + j;
							a[u] = a[u] - a[i * n + k] * a[k * n + j];
						}
			for (i = 0; i <= n - 1; i++)
				if (i != k)
				{
					u = i * n + k;
					a[u] = -a[u] * a[l];
				}
		}
		for (k = n - 1; k >= 0; k--)
		{
			if (js[k] != k)
				for (j = 0; j <= n - 1; j++)
				{
					u = k * n + j;
					v = js[k] * n + j;
					p = a[u];
					a[u] = a[v];
					a[v] = p;
				}
			if (is[k] != k)
				for (i = 0; i <= n - 1; i++)
				{
					u = i * n + k;
					v = i * n + is[k];
					p = a[u];
					a[u] = a[v];
					a[v] = p;
				}
		}
		for (i = 0; i < m; i++)
			for (j = 0; j < m; j++)
				M[i * m + j] = a[i * m + j];
		delete[] a;
		delete[] is;
		delete[] js;
		return 0;
	}
	void S(double fg[2], double cs[2])
	{
		double r, d;
		if ((fabs(fg[0]) + fabs(fg[1])) < MIN_DOUBLE)
		{
			cs[0] = 1.0;
			cs[1] = 0.0;
			d = 0.0;
		}
		else
		{
			d = sqrt(fg[0] * fg[0] + fg[1] * fg[1]);
			if (fabs(fg[0]) > fabs(fg[1]))
			{
				d = fabs(d);
				if (fg[0] < 0.0)
					d = -d;
			}
			if (fabs(fg[1]) >= fabs(fg[0]))
			{
				d = fabs(d);
				if (fg[1] < 0.0)
					d = -d;
			}
			cs[0] = fg[0] / d;
			cs[1] = fg[1] / d;
		}
		r = 1.0;
		if (fabs(fg[0]) > fabs(fg[1]))
			r = cs[1];
		else
			if (fabs(cs[0]) > MIN_DOUBLE)
				r = 1.0 / cs[0];
		fg[0] = d;
		fg[1] = r;
		return;
	}
	void D(double *a, double *b, int m, int n, int k, double *c)
	{
		int i, j, l, u;
		for (i = 0; i <= m - 1; i++)
			for (j = 0; j <= k - 1; j++)
			{
				u = i * k + j;
				c[u] = 0;
				for (l = 0; l <= n - 1; l++)
					c[u] = c[u] + a[i * n + l] * b[l * k + j];
			}
		return;
	}
	void P(double *a, double *e, double *s, double *v, int m, int n)
	{
		int i, j, p, q;
		double d;
		if (m >= n)
			i = n;
		else
			i = m;
		for (j = 1; j <= i - 1; j++)
		{
			a[(j - 1)*n + j - 1] = s[j - 1];
			a[(j - 1)*n + j] = e[j - 1];
		}
		a[(i - 1)*n + i - 1] = s[i - 1];
		if (m < n)
			a[(i - 1)*n + i] = e[i - 1];
		for (i = 1; i <= n - 1; i++)
			for (j = i + 1; j <= n; j++)
			{
				p = (i - 1) * n + j - 1;
				q = (j - 1) * n + i - 1;
				d = v[p];
				v[p] = v[q];
				v[q] = d;
			}
		return;
	}
	int svd(double *a, int m, int n, double *u, double *v, double eps = MIN_DOUBLE)
	{
		int ka = max2(m, n) + 1;
		int i, j, k, l, it, ll, kk, ix, iy, mm, nn, iz, ml, ks;
		double d, dd, t, sm, sml, eml, sk, ek, b, c, shh, fg[2], cs[2];
		double *s, *e, *w;
		s = new double[ka];
		e = new double[ka];
		w = new double[ka];
		for (i = 1; i <= m; i++)
		{
			ix = (i - 1) * m + i - 1;
			u[ix] = 0;
		}
		for (i = 1; i <= n; i++)
		{
			iy = (i - 1) * n + i - 1;
			v[iy] = 0;
		}
		it = MAX_ITERA;
		k = n;
		if (m - 1 < n)
			k = m - 1;
		l = m;
		if (n - 2 < m) l = n - 2;
		if (l < 0) l = 0;
		ll = k;
		if (l > k) ll = l;
		if (ll >= 1)
		{
			for (kk = 1; kk <= ll; kk++)
			{
				if (kk <= k)
				{
					d = 0.0;
					for (i = kk; i <= m; i++)
					{
						ix = (i - 1) * n + kk - 1;
						d = d + a[ix] * a[ix];
					}
					s[kk - 1] = sqrt(d);
					if (fabs(s[kk - 1]) > MIN_DOUBLE)
					{
						ix = (kk - 1) * n + kk - 1;
						if (fabs(a[ix]) > MIN_DOUBLE)
						{
							s[kk - 1] = fabs(s[kk - 1]);
							if (a[ix] < 0.0) s[kk - 1] = -s[kk - 1];
						}
						for (i = kk; i <= m; i++)
						{
							iy = (i - 1) * n + kk - 1;
							a[iy] = a[iy] / s[kk - 1];
						}
						a[ix] = 1.0 + a[ix];
					}
					s[kk - 1] = -s[kk - 1];
				}
				if (n >= kk + 1)
				{
					for (j = kk + 1; j <= n; j++)
					{
						if ((kk <= k) && (fabs(s[kk - 1]) > MIN_DOUBLE))
						{
							d = 0.0;
							for (i = kk; i <= m; i++)
							{
								ix = (i - 1) * n + kk - 1;
								iy = (i - 1) * n + j - 1;
								d = d + a[ix] * a[iy];
							}
							d = -d / a[(kk - 1) * n + kk - 1];
							for (i = kk; i <= m; i++)
							{
								ix = (i - 1) * n + j - 1;
								iy = (i - 1) * n + kk - 1;
								a[ix] = a[ix] + d * a[iy];
							}
						}
						e[j - 1] = a[(kk - 1) * n + j - 1];
					}
				}
				if (kk <= k)
				{
					for (i = kk; i <= m; i++)
					{
						ix = (i - 1) * m + kk - 1;
						iy = (i - 1) * n + kk - 1;
						u[ix] = a[iy];
					}
				}
				if (kk <= l)
				{
					d = 0.0;
					for (i = kk + 1; i <= n; i++)
						d = d + e[i - 1] * e[i - 1];
					e[kk - 1] = sqrt(d);
					if (fabs(e[kk - 1]) > MIN_DOUBLE)
					{
						if (fabs(e[kk]) > MIN_DOUBLE)
						{
							e[kk - 1] = fabs(e[kk - 1]);
							if (e[kk] < 0.0)
								e[kk - 1] = -e[kk - 1];
						}
						for (i = kk + 1; i <= n; i++)
							e[i - 1] = e[i - 1] / e[kk - 1];
						e[kk] = 1.0 + e[kk];
					}
					e[kk - 1] = -e[kk - 1];
					//if ((kk+1<=m)&&(e[kk-1]!=0.0))
					if ((kk + 1 <= m) && (fabs(e[kk - 1]) > MIN_DOUBLE))
					{
						for (i = kk + 1; i <= m; i++) w[i - 1] = 0.0;
						for (j = kk + 1; j <= n; j++)
							for (i = kk + 1; i <= m; i++)
								w[i - 1] = w[i - 1] + e[j - 1] * a[(i - 1) * n + j - 1];
						for (j = kk + 1; j <= n; j++)
							for (i = kk + 1; i <= m; i++)
							{
								ix = (i - 1) * n + j - 1;
								a[ix] = a[ix] - w[i - 1] * e[j - 1] / e[kk];
							}
					}
					for (i = kk + 1; i <= n; i++)
						v[(i - 1)*n + kk - 1] = e[i - 1];
				}
			}
		}
		mm = n;
		if (m + 1 < n) mm = m + 1;
		if (k < n) s[k] = a[k * n + k];
		if (m < mm) s[mm - 1] = 0.0;
		if (l + 1 < mm) e[l] = a[l * n + mm - 1];
		e[mm - 1] = 0.0;
		nn = m;
		if (m > n) nn = n;
		if (nn >= k + 1)
		{
			for (j = k + 1; j <= nn; j++)
			{
				for (i = 1; i <= m; i++)
					u[(i - 1)*m + j - 1] = 0.0;
				u[(j - 1)*m + j - 1] = 1.0;
			}
		}
		if (k >= 1)
		{
			for (ll = 1; ll <= k; ll++)
			{
				kk = k - ll + 1;
				iz = (kk - 1) * m + kk - 1;
				if (fabs(s[kk - 1]) > MIN_DOUBLE)
				{
					if (nn >= kk + 1)
						for (j = kk + 1; j <= nn; j++)
						{
							d = 0.0;
							for (i = kk; i <= m; i++)
							{
								ix = (i - 1) * m + kk - 1;
								iy = (i - 1) * m + j - 1;
								d = d + u[ix] * u[iy] / u[iz];
							}
							d = -d;
							for (i = kk; i <= m; i++)
							{
								ix = (i - 1) * m + j - 1;
								iy = (i - 1) * m + kk - 1;
								u[ix] = u[ix] + d * u[iy];
							}
						}
					for (i = kk; i <= m; i++)
					{
						ix = (i - 1) * m + kk - 1;
						u[ix] = -u[ix];
					}
					u[iz] = 1.0 + u[iz];
					if (kk - 1 >= 1)
						for (i = 1; i <= kk - 1; i++)
							u[(i - 1)*m + kk - 1] = 0.0;
				}
				else
				{
					for (i = 1; i <= m; i++)
						u[(i - 1)*m + kk - 1] = 0.0;
					u[(kk - 1)*m + kk - 1] = 1.0;
				}
			}
		}
		for (ll = 1; ll <= n; ll++)
		{
			kk = n - ll + 1;
			iz = kk * n + kk - 1;
			if ((kk <= l) && (fabs(e[kk - 1]) > MIN_DOUBLE))
			{
				for (j = kk + 1; j <= n; j++)
				{
					d = 0.0;
					for (i = kk + 1; i <= n; i++)
					{
						ix = (i - 1) * n + kk - 1;
						iy = (i - 1) * n + j - 1;
						d = d + v[ix] * v[iy] / v[iz];
					}
					d = -d;
					for (i = kk + 1; i <= n; i++)
					{
						ix = (i - 1) * n + j - 1;
						iy = (i - 1) * n + kk - 1;
						v[ix] = v[ix] + d * v[iy];
					}
				}
			}
			for (i = 1; i <= n; i++)
				v[(i - 1)*n + kk - 1] = 0.0;
			v[iz - n] = 1.0;
		}
		for (i = 1; i <= m; i++)
			for (j = 1; j <= n; j++)
				a[(i - 1)*n + j - 1] = 0.0;
		ml = mm;
		it = MAX_ITERA;
		for (;;)
		{
			if (mm == 0)
			{
				P(a, e, s, v, m, n);
				delete[] s;
				delete[] e;
				delete[] w;
				return l;
			}
			if (it == 0)
			{
				P(a, e, s, v, m, n);
				delete[] s;
				delete[] e;
				delete[] w;
				return -1;
			}
			kk = mm - 1;
			while ((kk != 0) && (fabs(e[kk - 1]) > MIN_DOUBLE))
			{
				d = fabs(s[kk - 1]) + fabs(s[kk]);
				dd = fabs(e[kk - 1]);
				if (dd > eps * d)
					kk = kk - 1;
				else
					e[kk - 1] = 0.0;
			}
			if (kk == mm - 1)
			{
				kk = kk + 1;
				if (s[kk - 1] < 0.0)
				{
					s[kk - 1] = -s[kk - 1];
					for (i = 1; i <= n; i++)
					{
						ix = (i - 1) * n + kk - 1;
						v[ix] = -v[ix];
					}
				}
				while ((kk != ml) && (s[kk - 1] < s[kk]))
				{
					d = s[kk - 1];
					s[kk - 1] = s[kk];
					s[kk] = d;
					if (kk < n)
						for (i = 1; i <= n; i++)
						{
							ix = (i - 1) * n + kk - 1;
							iy = (i - 1) * n + kk;
							d = v[ix];
							v[ix] = v[iy];
							v[iy] = d;
						}
					if (kk < m)
						for (i = 1; i <= m; i++)
						{
							ix = (i - 1) * m + kk - 1;
							iy = (i - 1) * m + kk;
							d = u[ix];
							u[ix] = u[iy];
							u[iy] = d;
						}
					kk = kk + 1;
				}
				it = MAX_ITERA;
				mm = mm - 1;
			}
			else
			{
				ks = mm;
				while ((ks > kk) && (fabs(s[ks - 1]) > MIN_DOUBLE))
				{
					d = 0.0;
					if (ks != mm)
						d = d + fabs(e[ks - 1]);
					if (ks != kk + 1) d = d + fabs(e[ks - 2]);
					dd = fabs(s[ks - 1]);
					if (dd > eps * d)
						ks = ks - 1;
					else
						s[ks - 1] = 0.0;
				}
				if (ks == kk)
				{
					kk = kk + 1;
					d = fabs(s[mm - 1]);
					t = fabs(s[mm - 2]);
					if (t > d)
						d = t;
					t = fabs(e[mm - 2]);
					if (t > d)
						d = t;
					t = fabs(s[kk - 1]);
					if (t > d)
						d = t;
					t = fabs(e[kk - 1]);
					if (t > d)
						d = t;
					sm = s[mm - 1] / d;
					sml = s[mm - 2] / d;
					eml = e[mm - 2] / d;
					sk = s[kk - 1] / d;
					ek = e[kk - 1] / d;
					b = ((sml + sm) * (sml - sm) + eml * eml) / 2.0;
					c = sm * eml;
					c = c * c;
					shh = 0.0;
					if ((fabs(b) > MIN_DOUBLE) || (fabs(c) > MIN_DOUBLE))
					{
						shh = sqrt(b * b + c);
						if (b < 0.0)
							shh = -shh;
						shh = c / (b + shh);
					}
					fg[0] = (sk + sm) * (sk - sm) - shh;
					fg[1] = sk * ek;
					for (i = kk; i <= mm - 1; i++)
					{
						S(fg, cs);
						if (i != kk)
							e[i - 2] = fg[0];
						fg[0] = cs[0] * s[i - 1] + cs[1] * e[i - 1];
						e[i - 1] = cs[0] * e[i - 1] - cs[1] * s[i - 1];
						fg[1] = cs[1] * s[i];
						s[i] = cs[0] * s[i];
						if ((fabs(cs[0] - 1.0) > MIN_DOUBLE) || (fabs(cs[1]) > MIN_DOUBLE))
							for (j = 1; j <= n; j++)
							{
								ix = (j - 1) * n + i - 1;
								iy = (j - 1) * n + i;
								d = cs[0] * v[ix] + cs[1] * v[iy];
								v[iy] = -cs[1] * v[ix] + cs[0] * v[iy];
								v[ix] = d;
							}
						S(fg, cs);
						s[i - 1] = fg[0];
						fg[0] = cs[0] * e[i - 1] + cs[1] * s[i];
						s[i] = -cs[1] * e[i - 1] + cs[0] * s[i];
						fg[1] = cs[1] * e[i];
						e[i] = cs[0] * e[i];
						if (i < m)
							if ((fabs(cs[0] - 1.0) > MIN_DOUBLE) || (fabs(cs[1]) > MIN_DOUBLE))
								for (j = 1; j <= m; j++)
								{
									ix = (j - 1) * m + i - 1;
									iy = (j - 1) * m + i;
									d = cs[0] * u[ix] + cs[1] * u[iy];
									u[iy] = -cs[1] * u[ix] + cs[0] * u[iy];
									u[ix] = d;
								}
					}
					e[mm - 2] = fg[0];
					it = it - 1;
				}
				else
				{
					if (ks == mm)
					{
						kk = kk + 1;
						fg[1] = e[mm - 2];
						e[mm - 2] = 0.0;
						for (ll = kk; ll <= mm - 1; ll++)
						{
							i = mm + kk - ll - 1;
							fg[0] = s[i - 1];
							S(fg, cs);
							s[i - 1] = fg[0];
							if (i != kk)
							{
								fg[1] = -cs[1] * e[i - 2];
								e[i - 2] = cs[0] * e[i - 2];
							}
							if ((fabs(cs[0] - 1.0) > MIN_DOUBLE) || (fabs(cs[1]) > MIN_DOUBLE))
								for (j = 1; j <= n; j++)
								{
									ix = (j - 1) * n + i - 1;
									iy = (j - 1) * n + mm - 1;
									d = cs[0] * v[ix] + cs[1] * v[iy];
									v[iy] = -cs[1] * v[ix] + cs[0] * v[iy];
									v[ix] = d;
								}
						}
					}
					else
					{
						kk = ks + 1;
						fg[1] = e[kk - 2];
						e[kk - 2] = 0.0;
						for (i = kk; i <= mm; i++)
						{
							fg[0] = s[i - 1];
							S(fg, cs);
							s[i - 1] = fg[0];
							fg[1] = -cs[1] * e[i - 1];
							e[i - 1] = cs[0] * e[i - 1];
							if ((fabs(cs[0] - 1.0) > MIN_DOUBLE) || (fabs(cs[1]) > MIN_DOUBLE))
								for (j = 1; j <= m; j++)
								{
									ix = (j - 1) * m + i - 1;
									iy = (j - 1) * m + kk - 2;
									d = cs[0] * u[ix] + cs[1] * u[iy];
									u[iy] = -cs[1] * u[ix] + cs[0] * u[iy];
									u[ix] = d;
								}
						}
					}
				}
			}
		}
		delete[] s;
		delete[] e;
		delete[] w;
		return l;
	}
	double norm(double *a, int m, int n)
	{
		double *b = new double[m * n];
		memmove(b, a, m * n * sizeof(double));
		double *u = new double[m * m];
		double *v = new double[n * n];
		svd(b, m, n, u, v);
		double re = maxdiag(b, m, n);
		delete[] b;
		delete[] u;
		delete[] v;
		return re;
	}
	double cond(double *a, int m, int n)
	{
		double *b = new double[m * n];
		memmove(b, a, m * n * sizeof(double));
		inv(b, m);
		double re = norm(a, m, n) * norm(b, m, n);
		delete[] b;
		return re;
	}
	bool SolveEquation(double *A, double *B, double *x, int n)
	{
		if (inv(A, n) == -1) return false;
		mul(A, n, n, B, n, 1, x);
		double t = 0;
		switch (n)
		{
			case 1:
				t = x[0]; 
				break;
			case 2:
				t = x[0] + f12 * x[1]; 
				break;
			case 3:
				t = x[0] + f23 * x[1] + f13 * x[2]; 
				break;
			case 4:
				t = x[0] + f34 * x[1] + f24 * x[2] + f14 * x[3]; 
				break;
			case 5:
				t = x[0] + f45 * x[1] + f35 * x[2] + f25 * x[3] + f15 * x[4]; 
				break;
			case 6:
				t = x[0] + f56 * x[1] + f46 * x[2] + f36 * x[3] + f26 * x[4] + f16 * x[5]; 
				break;
			case 7:
				t = x[0] + f67 * x[1] + f57 * x[2] + f47 * x[3] + f37 * x[4] + f27 * x[5] + f17 * x[6]; 
				break;
			case 8:
				t = x[0] + f78 * x[1] + f68 * x[2] + f58 * x[3] + f48 * x[4] + f38 * x[5] + f28 * x[6] + f18 * x[7]; 
				break;
		}
		if (t > 1.001 || t < -16 || IsNaN(t))
			return false;
		return true;
	}

	double mylog10(double base)
	{
		if (base > 0)
			return log10(base);
		return MINLIKELIHOOD;
	}

	//Random number generator
	void xorshf96init()
	{
		srand((unsigned int)time(NULL));
		int t = rand() % 10000;
		for (int i = 0; i < t; ++i)
			xorshf96();
	}
	unsigned long xorshf96() 
	{
		static unsigned long x=123456789, y=362436069, z=521288629;
		unsigned long t;
		x ^= x << 16;
		x ^= x >> 5;
		x ^= x << 1;
		t = x;
		x = y;
		y = z;
		z = t ^ x ^ y;
	    return z;
	}
	double getrand()
	{
		return xorshf96() * 1.0 / 0xFFFFFFFF;
	}
	
	bool IsNaN(double number)
	{
		if (number < 0 == false && number >= 0 == false)
			return true;
		return false;
	}

	//Hash a genotype, to look up the correct genotype pattern quickly
	uint* cryptTable;
	void prepareCryptTable()
	{
		cryptTable = new uint[0x500];
		uint dwHih, dwLow, seed = 0x00100001, index1 = 0, index2 = 0, i;
		for (index1 = 0; index1 < 0x100; index1++)
		{
			for (index2 = index1, i = 0; i < 5; i++, index2 += 0x100)
			{
				seed = (seed * 125 + 3) % 0x2AAAAB;
				dwHih = (seed & 0xFFFF) << 0x10;
				seed = (seed * 125 + 3) % 0x2AAAAB;
				dwLow = (seed & 0xFFFF);
				cryptTable[index2] = (dwHih | dwLow);
			}
		}
	}
	uint HashString(char* s1, char* s2, char* s3)
	{
		if (cryptTable == NULL)
			prepareCryptTable();
		uint dwSeed1 = 0x7FED7FED;
		uint dwSeed2 = 0xEEEEEEEE;
		uint b1;
		for (int i = 0; s1[i]; ++i)
		{
			b1 = s1[i];
			dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
			dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
		}
		for (int i = 0; s2[i]; ++i)
		{
			b1 = s2[i];
			dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
			dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
		}
		for (int i = 0; s3[i]; ++i)
		{
			b1 = s3[i];
			dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
			dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
		}
		return dwSeed1;
	}
	uint gethash(int* x, int* y, int p)
	{
		//xibs + yibs + crosssame + crossfactors
		int crosssame = 0;
		int crfa[8], crfb[8], crfan = 0, crfbn = 0;
		for (int i = 0; i < p; ++i)
		{
			int c1 = 0, c2 = 0;
			for (int j = 0; j < p; ++j)
			{
				if (x[i] == y[j])
				{
					crosssame++;
					c1++;
				}
				if (x[j] == y[i])
					c2++;
			}
			if (c1) crfa[crfan++] = c1;
			if (c2) crfb[crfbn++] = c2;
		}

		for (int i = 0; i < crfan; ++i)
			for (int j = i + 1; j < crfan; ++j)
				if (crfa[i] > crfa[j])
				{
					int t = crfa[i];
					crfa[i] = crfa[j];
					crfa[j] = t;
				}

		for (int i = 0; i < crfbn; ++i)
			for (int j = i + 1; j < crfbn; ++j)
				if (crfb[i] > crfb[j])
				{
					int t = crfb[i];
					crfb[i] = crfb[j];
					crfb[j] = t;
				}
		char s1[20], s2[20], s3[20];
		s2[0] = 0;
		s3[0] = 0;
		uint sibsx = getsingleibs(x, p);
		uint sibsy = getsingleibs(y, p);
		sprintf(s1, "%d,%d,%d", sibsx, sibsy, crosssame);
		for (int i = 0; i < crfan; ++i)
		{
			s2[i * 2] = (char)('0' + crfa[i]);
			s2[i * 2 + 1] = ',';
		}
		if (crfan) s2[crfan * 2 - 1] = 0;
		for (int i = 0; i < crfbn; ++i)
		{
			s3[i * 2] = (char)('0' + crfb[i]);
			s3[i * 2 + 1] = ',';
		}
		if (crfbn) s3[crfbn * 2 - 1] = 0;
		return HashString(s1, s2, s3);
	}
	uint HashGenotype(int* allele, int nvis, int p)
	{
		//yaogai
		if (cryptTable == NULL)
			prepareCryptTable();
		uint dwSeed1 = 0x7FED7FED;
		uint dwSeed2 = 0xEEEEEEEE;
		
		byte b1 = (byte)p; 
		dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
		dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
		for (int i = 0; i <= nvis; ++i)
		{
			b1 = (byte)allele[i]; allele[i] >>= 8;
			dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
			dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
			b1 = (byte)allele[i]; allele[i] >>= 8;
			dwSeed1 = cryptTable[0x100 + b1] ^ (dwSeed1 + dwSeed2);
			dwSeed2 = b1 + dwSeed1 + dwSeed2 + (dwSeed2 << 5) + 3;
		}
		return dwSeed1;
	}

	//convert genotype pattern from a string like 'iiii-ijkl'
	uint64 getval(char *g)
	{
		int p = (int)strlen(g) - 1;
		uint64 re = 0;
		if (p == 8)
		{
			int xx[8] = {g[0] - 'i', g[1] - 'i', g[2] - 'i', g[3] - 'i', g[5] - 'i', g[6] - 'i', g[7] - 'i', g[8] - 'i'};
			for (int i = 0; i < p; ++i)
				re = (re << 4) | xx[i];
		}
		else if (p == 12)
		{
			int xx[12] = {g[0] - 'i', g[1] - 'i', g[2] - 'i', g[3] - 'i', g[4] - 'i', g[5] - 'i', g[7] - 'i', g[8] - 'i', g[9] - 'i', g[10] - 'i', g[11] - 'i', g[12] - 'i'};
			for (int i = 0; i < p; ++i)
				re = (re << 4) | xx[i];
		}
		else if (p == 16)
		{
			int xx[16] = {g[0] - 'i', g[1] - 'i', g[2] - 'i', g[3] - 'i', g[4] - 'i', g[5] - 'i', g[6] - 'i', g[7] - 'i', g[9] - 'i', g[10] - 'i', g[11] - 'i', g[12] - 'i', g[13] - 'i', g[14] - 'i', g[15] - 'i', g[16] - 'i'};
			for (int i = 0; i < p; ++i)
				re = (re << 4) | xx[i];
		}
		return re;
	}
	uint getsingleibs(int *x, int ploidy)
	{
		int n = 0, t[8], tt;
		for (int i = 0; i < ploidy; )
		{
			int j = i + 1;
			for (; j < ploidy && x[j] == x[i]; ++j);
			t[n++] = j - i;
			i = j;
		}
		for (int i = 0; i < n; ++i)
			for (int j = i + 1; j < n; ++j)
				if (t[j] < t[i])
				{
					tt = t[i];
					t[i] = t[j];
					t[j] = tt;
				}
		tt = 0;
		for (int i = 0; i < n; ++i)
			tt = tt * 10 + t[i];
		return tt;
	}

	//Generate a random genotype
	void randomtype(GENOTYPE &re, int c = -1)
	{
		if (method == 1)
		{
			double t;
			int j;
			for (int i = (c == -1 ? 0 : c); i < (c == -1 ? L : c + 1); ++i)
			{
				re.ploidy[i] = 2;
				j = 0;
				t = getrand();
				for (;;)
				{
					if (t < frenull[i][j])
					{
						re.a[i] = j;
						break;
					}
					t -= frenull[i][j++];
					if (j >= Locus[i].n)
					{
						re.a[i] = NULL_ALLELE;
						break;
					}
				}
				j = 0;
				t = getrand();
				for (;;)
				{
					if (t < frenull[i][j])
					{
						re.b[i] = j;
						break;
					}
					t -= frenull[i][j++];
					if (j >= Locus[i].n)
					{
						re.b[i] = NULL_ALLELE;;
						break;
					}
				}
			}
		}
		else
		{
			double t;
			int j;
			for (int i = (c == -1 ? 0 : c); i < (c == -1 ? L : c + 1); ++i)
			{
				//typed
				if (c == -1)
					re.ploidy[i] = cdeltas[PLOIDY] > 0 ? PLOIDY : PLOIDY / 2;
				if (getrand() <= Locus[i].rate)
				{
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.a[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 1)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.b[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 2)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.c[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 3)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.d[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 4)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.e[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 5)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.f[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 6)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.g[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
					if (re.ploidy[i] == 7)
						continue;
					j = 0;
					t = getrand();
					for (;;)
					{
						if (t <= freobs[i][j])
						{
							re.h[i] = j;
							break;
						}
						t -= freobs[i][j++];
						if (j >= Locus[i].n)
						{
							j = 0;
							t = getrand();
						}
					}
				}
				else
				{
					re.a[i] = -1;
					re.b[i] = -1;
					re.c[i] = -1;
					re.d[i] = -1;
					re.e[i] = -1;
					re.f[i] = -1;
					re.g[i] = -1;
					re.h[i] = -1;
				}
			}
		}
	}

	//Generate a random genotype conditioned on another genotype and their relationships
	void conditionaltype(GENOTYPE &x, GENOTYPE &re, int relationid)
	{
		if (method == 1)
		{
			double mode;
			static unsigned int count = 0;
			for (int i = 0; i < L; ++i)
			{
				re.ploidy[i] = 2;
				mode = getrand();
				if (mode <= cdeltas[0])
					randomtype(re, i);
				else if (mode <= cdeltas[1])
				{
					randomtype(re, i);
					re.a[i] = x.a[i];
				}
				else
				{
					re.a[i] = x.a[i];
					re.b[i] = x.b[i];
				}
			}
		}
		else
		{
			double mode;
			for (int i = 0; i < L; ++i)
			{
				if (relationid >= 5 && relationid <= 10)
					re.ploidy[i] = PLOIDY / 2; 
				else
					re.ploidy[i] = PLOIDY; 
				if (getrand() <= Locus[i].rate)
				{
					mode = getrand();
					switch (re.ploidy[i])
					{
						case 1:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else
								re.a[i] = x.a[i];
							break;
						case 2:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							break;
						case 3:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else 
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							break;
						case 4:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else if (mode <= cdeltas[3])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							else 
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
							}
							break;
						case 5:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else if (mode <= cdeltas[3])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							else if (mode <= cdeltas[4])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
							}
							else 
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
							}
							break;
						case 6:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else if (mode <= cdeltas[3])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							else if (mode <= cdeltas[4])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
							}
							else if (mode <= cdeltas[5])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
							}
							else
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
							}
							break;
						case 7:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else if (mode <= cdeltas[3])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							else if (mode <= cdeltas[4])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
							}
							else if (mode <= cdeltas[5])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
							}
							else if (mode <= cdeltas[6])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
							}
							else 
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
								re.g[i] = x.g[i];
							}
							break;
						case 8:
							if (mode <= cdeltas[0])
								randomtype(re, i);
							else if (mode <= cdeltas[1])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
							}
							else if (mode <= cdeltas[2])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
							}
							else if (mode <= cdeltas[3])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
							}
							else if (mode <= cdeltas[4])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
							}
							else if (mode <= cdeltas[5])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
							}
							else if (mode <= cdeltas[6])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
							}
							else if (mode <= cdeltas[7])
							{
								randomtype(re, i);
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
								re.g[i] = x.g[i];
							}
							else
							{
								re.a[i] = x.a[i];
								re.b[i] = x.b[i];
								re.c[i] = x.c[i];
								re.d[i] = x.d[i];
								re.e[i] = x.e[i];
								re.f[i] = x.f[i];
								re.g[i] = x.g[i];
								re.h[i] = x.h[i];
							}
							break;
					}
				}
				else
				{
					re.a[i] = -1;
					re.b[i] = -1;
					re.c[i] = -1;
					re.d[i] = -1;
				}
			}
		}
	}

	//Process ambiguous genotypes, create a set of candidate genotypes
	int sort_count(int *a, int ploidyx)
	{
		for (int i = 0; i < ploidyx; ++i)
			for (int j = i + 1; j < ploidyx; ++j)
			{
				if ((uint)a[i] > (uint)a[j])
				{
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
			}
		int re = a[0] != AMBIGUOUS_ALLELE;
		for (int i = 1; i < ploidyx; ++i)
			if (a[i] != a[i - 1] && a[i] != AMBIGUOUS_ALLELE)
				re++;
		
		return re;
	}
	void sortuint(unsigned int *a, int p)
	{
		for (int i = 0; i < p; ++i)
			for (int j = i + 1; j < p; ++j)
				if (a[i] > a[j])
				{
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	void sortint(int *a, int p)
	{
		for (int i = 0; i < p; ++i)
			for (int j = i + 1; j < p; ++j)
				if (a[i] > a[j])
				{
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
	}
	int maxsame(int *a)
	{
		if (a[1] == a[0])
		{
			if (a[2] == a[1])
			{
				if (a[3] == a[2])
					return 4;
				else
					return 3;
			}
			return 2;
		}
		else if (a[2] == a[1])
		{
			if (a[3] == a[2])
				return 3;
			else
				return 2;
		}
		else if (a[3] == a[2])
			return 2;
		return 1;
	}
	double S_Index(int *c, int *d, int ploidyx, int ploidyy)
	{
		int *a = new int[ploidyx];
		int *b = new int[ploidyy];
		memmove(a, c, ploidyx * sizeof(int));
		memmove(b, d, ploidyy * sizeof(int));
		int S = 0;
		for (int i = 0; i < ploidyx; ++i)
		{
			if (a[i] >= 0)
			{
				for (int j = 0; j < ploidyy; ++j)
				{
					if (a[i] == b[j])
					{
						a[i] = b[j] = -1;
						S++;
						break;
					}
				}
			}
		}
		delete [] a;
		delete [] b;
		return S * 1.0 / max2(ploidyx, ploidyy);
	}
	double factorial(int n)
	{
		switch (n)
		{
			case 0: return 1;
			case 1: return 1;
			case 2: return 2;
			case 3: return 6;
			case 4: return 24;
			case 5: return 120;
			case 6: return 720;
			case 7: return 5040;
			case 8: return 40320;
			case 9: return 362880;
			case 10: return 3628800;
			case 11: return 39916800;
			case 12: return 479001600;
			default: return -1;
		}
	}
	double binomial(int n, int r)
	{
		return factorial(n) / factorial(r) / factorial(n - r);
	}
	void getcandidatesub(int lay, double prod, int last)
	{
		if (lay == getcandidate_ploidy)
		{
			if (last == getcandidate_cx - 1)
			{
				memmove(getcandidate_xx + getcandidate_xx_count * getcandidate_alignment, getcandidate_tempxx, sizeof(int) * getcandidate_ploidy);
				double c2 = 1;
				int plast = 8;
				for (int i = 0; i < getcandidate_cx; ++i)
				{
					c2 *= binomial(plast, getcandidate_xx_count2[i]);
					plast -= getcandidate_xx_count2[i];
				}
				getcandidate_p[getcandidate_xx_count++] = c2 * prod;
			}
		}
		else if (lay == 0)
		{
			getcandidate_tempxx[lay] = getcandidate_x[last];
			getcandidate_xx_count2[last] = 1;
			getcandidatesub(lay + 1, prod * freobs[getcandidate_l][getcandidate_tempxx[lay]], last);
			getcandidate_xx_count2[last + 1] = 0;
		}
		else
		{
			if (getcandidate_ploidy - lay > getcandidate_cx - 1 - last)
			{
				//push last allele
				getcandidate_tempxx[lay] = getcandidate_x[last];
				getcandidate_xx_count2[last]++;
				getcandidatesub(lay + 1, prod * freobs[getcandidate_l][getcandidate_tempxx[lay]], last);
				getcandidate_xx_count2[last]--;
			}
			if (last < getcandidate_cx - 1)
			{
				//push next allele
				getcandidate_tempxx[lay] = getcandidate_x[last + 1];
				getcandidate_xx_count2[last + 1] = 1;
				getcandidatesub(lay + 1, prod * freobs[getcandidate_l][getcandidate_tempxx[lay]], last + 1);
				getcandidate_xx_count2[last + 1] = 0;
			}
		}
	}
	int getcandidate(int cx, int *x, int *xx, double *p, int l, int ploidy, int maxploidy, int alignment)
	{
		bool flag = false;
		for (int i = 0; i < ploidy; ++i)
		{
			if (x[i] == AMBIGUOUS_ALLELE)
			{
				flag = true;
				break;
			}
		}
		if (ploidy > 2 && (rem || flag))
		{
			getcandidate_xx_count = 0;
			getcandidate_cx = cx;
			int tc = 0;
			for (int j = 0; j < ploidy; ++j)
				if ((j == 0 || x[j] != x[j - 1]) && x[j] != AMBIGUOUS_ALLELE)
					getcandidate_x[tc++] = x[j];
			getcandidate_l = l;
			getcandidate_xx = xx;
			getcandidate_p = p;
			getcandidate_alignment = alignment;
			getcandidate_ploidy = ploidy;
			getcandidatesub(0, 1, 0);
			
			double sw = 0;
			for (int i = 0; i < getcandidate_xx_count; ++i)
				sw += p[i];
			for (int i = 0; i < getcandidate_xx_count; ++i)
				p[i] /= sw;
			
			return getcandidate_xx_count;
		}
		else
		{
			memmove(xx, x, sizeof(int) * maxploidy);
			p[0] = 1;
			return 1;
		}
	}

	//Down-Hill Simplex Algorithm Class, for estimating the frequency of null alleles
	class point3
	{
	public:
		double *image;
		double *real;
		double li;
		int dem;
		bool inited;
		point3()
		{
			inited = false;
		}
		void init(int de, double initimage = 0)
		{
			dem = de;
			if (!inited)
			{
				image = new double[dem + 2];
				real = new double[dem + 2];
			}
			for (int i = 0; i < dem; ++i)
				image[i] = initimage;
			memset(real,0, sizeof(double) * (dem + 2));
			image[dem] = image[dem + 1] = 0;
			real[dem] = real[dem + 1] = 0;
			for (int i = 0; i < de; ++i) 
				image[i] = real[i] = 0; 
			inited = true;
		}
		void uninit()
		{
			if (inited)
			{
				delete[] image;
				delete[] real;
				inited = false;
			}
		}
		/*
		void CloneFrom(point3 a)
		{
			//Create a new
			li = a.li;
			dem = a.dem;
			if (!inited)
			{
				image = new double[dem + 2];
				real = new double[dem + 2];
				inited = true;
			}
			memmove(image, a.image, sizeof(double) * dem);
			memmove(real, a.real, sizeof(double) * dem);
		}
		*/
		point3 operator =(point3 a)
		{
			//Create a new
			li = a.li;
			dem = a.dem;
			if (!inited)
			{
				image = new double[dem + 2];
				real = new double[dem + 2];
				inited = true;
			}
			memmove(image, a.image, sizeof(double) * dem);
			memmove(real, a.real, sizeof(double) * dem);
			return *this;

			//image
			memmove(this, &a, sizeof(point3));
		}
		bool operator >(point3 a)
		{
			return li > a.li;
		}
		bool operator >=(point3 a)
		{
			return li >= a.li;
		}
		bool operator <(point3 a)
		{
			return li < a.li;
		}
		bool operator <=(point3 a)
		{
			return li <= a.li;
		}
		bool operator ==(point3 a)
		{
			return li == a.li;
		}
		bool operator !=(point3 a)
		{
			return li != a.li;
		}
		point3 operator +=(point3 a)
		{
			for (int i = 0; i < dem; ++i) 
				image[i] += a.image[i];
			return *this;
		}
		point3 operator -=(point3 a)
		{
			for (int i = 0; i < dem; ++i) 
				image[i] -= a.image[i];
			return *this;
		}
		point3 operator *=(double a)
		{
			for (int i = 0; i < dem; ++i) 
				image[i] *= a;
			return *this;
		}
		point3 operator /=(double a)
		{
			for (int i = 0; i < dem; ++i) 
				image[i] /= a;
			return *this;
		}
		double distancer(point3 a)
		{
			i2r();
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (real[i] - a.real[i]) * (real[i] - a.real[i]);
			return sqrt(s);
		}
		double distance(point3 a)
		{
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (image[i] - a.image[i]) * (image[i] - a.image[i]);
			return sqrt(s);
		}
		void i2r()
		{
			for (int i = 0; i < dem; ++i)
				real[i] = 1 / (1 + exp(- image[i]));
		}
		bool friend isbreak(point3* xx, double eps = 0)
		{
			return xx[0].distancer(xx[xx[0].dem]) < eps;
		}
		void friend order(point3* xx)
		{
			int dem = xx[0].dem;
			point3 t;
			for (int i = 0; i <= dem; ++i)
				for (int j = i + 1; j <= dem; ++j)
					if (xx[i] < xx[j]) 
					{
						t = xx[i];
						xx[i] = xx[j];
						xx[j] = t;
						/*
						t.CloneFrom(xx[i]);
						xx[i].CloneFrom(xx[j]);
						xx[j].CloneFrom(t);
						*/
					}
		}
	};

	//Down-Hill Simplex Algorithm Class, for polyploids
	class point4
	{
	public:
		double image[8];
		double real[9];
		double li;
		int dem;
		bool confine;
		int diff;
		point4(int de = 4)
		{
			diff = 0;
			dem = de;
			for (int i = 0; i < 9; ++i) 
				image[i] = 0; 
		}
		bool operator >(point4 a)
		{
			return li > a.li;
		}
		bool operator >=(point4 a)
		{
			return li >= a.li;
		}
		bool operator <(point4 a)
		{
			return li < a.li;
		}
		bool operator <=(point4 a)
		{
			return li <= a.li;
		}
		bool operator ==(point4 a)
		{
			return li == a.li;
		}
		bool operator !=(point4 a)
		{
			return li != a.li;
		}
		point4 operator =(point4 a)
		{
			memmove(this, &a, sizeof(point4));
			return *this;
		}
		friend point4 operator +(point4 a, point4 b)
		{
			point4 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] + b.image[i];
			return re;
		}
		friend point4 operator -(point4 a, point4 b)
		{
			point4 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] - b.image[i];
			return re;
		}
		friend point4 operator *(point4 a, double b)
		{
			point4 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] * b;
			return re;
		}
		friend point4 operator /(point4 a, double b)
		{
			point4 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] / b;
			return re;
		}
		point4 operator +=(point4 a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] += a.image[i];
			return *this;
		}
		point4 operator -=(point4 a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] -= a.image[i];
			return *this;
		}
		point4 operator *=(double a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] *= a;
			return *this;
		}
		point4 operator /=(double a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] /= a;
			return *this;
		}
		double distancer(point4 a)
		{
			i2r();
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (real[i] - a.real[i]) * (real[i] - a.real[i]);
			return sqrt(s);
		}
		double distance(point4 a)
		{
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (image[i] - a.image[i]) * (image[i] - a.image[i]);
			return sqrt(s);
		}
		void i2r()
		{
			if (confine && !diff && dem % 2 == 0)
			{
				if (dem == 1)
				{
					real[0] = 1 / (1 + exp(- image[0]));
					real[1] = 1 - real[0];
				}
				else if (dem == 2)
				{
					double p1 = 1 / (1 + exp(- image[0]));
					double q1 = 1 / (1 + exp(- image[1]));
					double p0 = 1 - p1;
					double q0 = 1 - q1;
					real[0] = p1 * q1;
					real[1] = p0 * q1 + p1 * q0;
					real[2] = p0 * q0;
				}
				else if (dem == 4)
				{
					double p2 = 1 / (1 + exp(- image[0]));
					double p1 = (1 - p2) / (1 + exp(- image[1]));
					double q2 = 1 / (1 + exp(- image[2]));
					double q1 = (1 - q2) / (1 + exp(- image[3]));
					double p0 = 1 - p2 - p1;
					double q0 = 1 - q2 - q1;
					real[0] = p2 * q2;
					real[1] = p2 * q1 + p1 * q2;
					real[2] = p2 * q0 + p0 * q2 + p1 * q1;
					real[3] = p0 * q1 + p1 * q0;
					real[4] = p0 * q0;
				}
				else if (dem == 6)
				{
					double p3 = 1 / (1 + exp(- image[0]));
					double p2 = (1 - p3) / (1 + exp(- image[1]));
					double p1 = (1 - p3 - p2) / (1 + exp(- image[2]));
					double q3 = 1 / (1 + exp(- image[3]));
					double q2 = (1 - q3) / (1 + exp(- image[4]));
					double q1 = (1 - q3 - q2) / (1 + exp(- image[5]));
					double p0 = 1 - p3 - p2 - p1;
					double q0 = 1 - q3 - q2 - q1;
					real[0] = p3 * q3;
					real[1] = p3 * q2 + p2 * q3;
					real[2] = p3 * q1 + p2 * q2 * p1 * q3;
					real[3] = p3 * q0 + p2 * q1 + p1 * q2 + p0 * q3;
					real[4] = p2 * q0 + p1 * q1 + p0 * q2;
					real[5] = p1 * q0 + p0 * q1;
					real[6] = p0 * q0;
				}
				else if (dem == 8)
				{
					double p4 = 1 / (1 + exp(- image[0]));
					double p3 = (1 - p4) / (1 + exp(- image[1]));
					double p2 = (1 - p4 - p3) / (1 + exp(- image[2]));
					double p1 = (1 - p4 - p3 - p2) / (1 + exp(- image[3]));
					double q4 = 1 / (1 + exp(- image[4]));
					double q3 = (1 - q4) / (1 + exp(- image[5]));
					double q2 = (1 - q4 - q3) / (1 + exp(- image[6]));
					double q1 = (1 - q4 - q3 - q2) / (1 + exp(- image[7]));
					double p0 = 1 - p4 - p3 - p2 - p1;
					double q0 = 1 - q4 - q3 - q2 - q1;
					real[0] = p4 * q4;
					real[1] = p4 * q3 + p3 * q4;
					real[2] = p4 * q2 + p3 * q3 * p2 * q4;
					real[3] = p4 * q1 + p3 * q2 + p2 * q3 + p1 * q4;
					real[4] = p4 * q0 + p3 * q1 + p2 * q2 + p1 * q3 + p0 * q4;
					real[5] = p3 * q0 + p2 * q1 + p1 * q2 + p0 * q3;
					real[6] = p2 * q0 + p1 * q1 + p0 * q2;
					real[7] = p1 * q0 + p0 * q1;
					real[8] = p0 * q0;
				}
			}
			else
			{
				real[dem] = 1;
				for (int i = 0; i < dem; ++i)
				{
					real[i] = real[dem] / (1 + exp(- image[i]));
					real[dem] -= real[i];
				}
			}
		}
		bool friend isbreak(point4 xx[9], double eps = 0)
		{
			return xx[0].distancer(xx[xx[0].dem]) < eps;
		}
		void friend order(point4 xx[9])
		{
			int dem = xx[0].dem;
			point4 t(dem);
			for (int i = 0; i <= dem; ++i)
				for (int j = i + 1; j <= dem; ++j)
					if (xx[i] < xx[j]) 
					{
						t = xx[i];
						xx[i] = xx[j];
						xx[j] = t;
					}
		}
	};

	//Down-Hill Simplex Algorithm Class, for diploids
	class point8
	{
	public:
		double image[8];
		double real[9];
		double li;
		int dem; // 8 or 2 or 3 or 1
		bool confine;
		point8(int de = 8)
		{
			dem = de;
			for (int i = 0; i < de; ++i) image[i] = 0; 
		}
		bool operator >(point8 a)
		{
			return li > a.li;
		}
		bool operator >=(point8 a)
		{
			return li >= a.li;
		}
		bool operator <(point8 a)
		{
			return li < a.li;
		}
		bool operator <=(point8 a)
		{
			return li <= a.li;
		}
		bool operator ==(point8 a)
		{
			return li == a.li;
		}
		bool operator !=(point8 a)
		{
			return li != a.li;
		}
		point8 operator =(point8 a)
		{
			memmove(this, &a, sizeof(point8));
			return *this;
		}
		friend point8 operator +(point8 a, point8 b)
		{
			point8 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] + b.image[i];
			return re;
		}
		point8 operator +=(point8 a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] += a.image[i];
			return *this;
		}
		friend point8 operator -(point8 a, point8 b)
		{
			point8 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] - b.image[i];
			return re;
		}
		point8 operator -=(point8 a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] -= a.image[i];
			return *this;
		}
		friend point8 operator *(point8 a, double b)
		{
			point8 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] * b;
			return re;
		}
		point8 operator *=(double a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] *= a;
			return *this;
		}
		friend point8 operator /(point8 a, double b)
		{
			point8 re = a;
			for (int i = 0; i < a.dem; ++i) 
				re.image[i] = a.image[i] / b;
			return re;
		}
		point8 operator /=(double a)
		{
			for (int i = 0; i < dem; ++i)
				image[i] /= a;
			return *this;
		}
		double distancer(point8 a)
		{
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (real[i] - a.real[i]) * (real[i] - a.real[i]);
			return sqrt(s);
		}
		double distance(point8 a)
		{
			double s = 0;
			for (int i = 0; i < dem; ++i) 
				s += (image[i] - a.image[i]) * (image[i] - a.image[i]);
			return sqrt(s);
		}
		void i2r()
		{
			//image to real
			if (dem == 2 || dem == 8)
			{
				real[dem] = 1;
				for (int i = 0; i < dem; ++i)
				{
					real[i] = real[dem] / (1 + exp(- image[i]));
					real[dem] -= real[i];
				}
				if (confine)//only for dem == 2
				{
					double p1 = 1 / (1 + exp(- image[0]));
					double q1 = 1 / (1 + exp(- image[1]));
					double p0 = 1 - p1;
					double q0 = 1 - q1;
					real[0] = p1 * q1;
					real[1] = p0 * q1 + p1 * q0;
					real[2] = p0 * q0;
				}
			}
			else
			{
				real[dem] = 1;
				for (int i = 0; i < dem; ++i)
				{
					real[i] = real[dem] / (1 + exp(- image[i]));
					real[dem] -= real[i];
				}
			}
		}
		bool friend isbreak(point8 xx[9], double eps = 0)
		{
			return xx[0].distancer(xx[xx[0].dem]) < eps;
		}
		void friend order(point8 xx[9])
		{
			point8 t;
			int dem = xx[0].dem;
			for (int i = 0; i < dem + 1; ++i)
				for (int j = i + 1; j < dem + 1; ++j)
					if (xx[i] < xx[j]) 
					{
						t = xx[i];
						xx[i] = xx[j];
						xx[j] = t;
					}
		}
	};

	bool IsMissingGenotype(GENOTYPE x, int i)
	{
		switch (x.ploidy[i])
		{
			case 8: if (x.h[i] == MISSING_ALLELE) return true;
			case 7: if (x.g[i] == MISSING_ALLELE) return true;
			case 6: if (x.f[i] == MISSING_ALLELE) return true;
			case 5: if (x.e[i] == MISSING_ALLELE) return true;
			case 4: if (x.d[i] == MISSING_ALLELE) return true;
			case 3: if (x.c[i] == MISSING_ALLELE) return true;
			case 2: if (x.b[i] == MISSING_ALLELE) return true;
			case 1: if (x.a[i] == MISSING_ALLELE) return true;
		}
		return false;
	}

	bool IsMissingGenotype(GENOTYPE x, GENOTYPE y, int i)
	{
		switch (x.ploidy[i])
		{
			case 8: if (x.h[i] == MISSING_ALLELE) return true;
			case 7: if (x.g[i] == MISSING_ALLELE) return true;
			case 6: if (x.f[i] == MISSING_ALLELE) return true;
			case 5: if (x.e[i] == MISSING_ALLELE) return true;
			case 4: if (x.d[i] == MISSING_ALLELE) return true;
			case 3: if (x.c[i] == MISSING_ALLELE) return true;
			case 2: if (x.b[i] == MISSING_ALLELE) return true;
			case 1: if (x.a[i] == MISSING_ALLELE) return true;
		}
			
		switch (y.ploidy[i])
		{
			case 8: if (y.h[i] == MISSING_ALLELE) return true;
			case 7: if (y.g[i] == MISSING_ALLELE) return true;
			case 6: if (y.f[i] == MISSING_ALLELE) return true;
			case 5: if (y.e[i] == MISSING_ALLELE) return true;
			case 4: if (y.d[i] == MISSING_ALLELE) return true;
			case 3: if (y.c[i] == MISSING_ALLELE) return true;
			case 2: if (y.b[i] == MISSING_ALLELE) return true;
			case 1: if (y.a[i] == MISSING_ALLELE) return true;
		}

		return false;
	}

	bool IsAllAmbiguousGenotype(GENOTYPE x, int i)
	{
		switch (x.ploidy[i])
		{
			case 8: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE && x.h[i] == AMBIGUOUS_ALLELE) return true; break;
			case 7: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE) return true; break;
			case 6: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE) return true; break;
			case 5: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE) return true; break;
			case 4: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE) return true; break;
			case 3: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE) return true; break;
			case 2: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE) return true; break;
			case 1: if (x.a[i] == AMBIGUOUS_ALLELE) return true; break;
		}

		return false;
	}

	bool IsAllAmbiguousGenotype(GENOTYPE x, GENOTYPE y, int i)
	{
		switch (x.ploidy[i])
		{
			case 8: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE && x.h[i] == AMBIGUOUS_ALLELE) return true; break;
			case 7: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE) return true; break;
			case 6: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE) return true; break;
			case 5: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE) return true; break;
			case 4: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE) return true; break;
			case 3: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE) return true; break;
			case 2: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE) return true; break;
			case 1: if (x.a[i] == AMBIGUOUS_ALLELE) return true; break;
		}
			
		switch (y.ploidy[i])
		{
			case 8: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE && y.d[i] == AMBIGUOUS_ALLELE && y.e[i] == AMBIGUOUS_ALLELE && y.f[i] == AMBIGUOUS_ALLELE && y.g[i] == AMBIGUOUS_ALLELE && y.h[i] == AMBIGUOUS_ALLELE) return true; break;
			case 7: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE && y.d[i] == AMBIGUOUS_ALLELE && y.e[i] == AMBIGUOUS_ALLELE && y.f[i] == AMBIGUOUS_ALLELE && y.g[i] == AMBIGUOUS_ALLELE) return true; break;
			case 6: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE && y.d[i] == AMBIGUOUS_ALLELE && y.e[i] == AMBIGUOUS_ALLELE && y.f[i] == AMBIGUOUS_ALLELE) return true; break;
			case 5: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE && y.d[i] == AMBIGUOUS_ALLELE && y.e[i] == AMBIGUOUS_ALLELE) return true; break;
			case 4: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE && y.d[i] == AMBIGUOUS_ALLELE) return true; break;
			case 3: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE && y.c[i] == AMBIGUOUS_ALLELE) return true; break;
			case 2: if (y.a[i] == AMBIGUOUS_ALLELE && y.b[i] == AMBIGUOUS_ALLELE) return true; break;
			case 1: if (y.a[i] == AMBIGUOUS_ALLELE) return true; break;
		}

		return false;
	}

	//initialize polyploid maximum-likelihood estimator, allocate memory, read genotype pattern tables, etc
	void Huang2012ML_Initialize()
	{
		if (Huang2012ML_Initialized)
			return;
		Huang2012ML_Coef = new double*[L];
		pcandidate = new double*[L];
		ncandidate = new int[L];
		int ncan[] = {0, 1, 1, 2, 3, 6, 10, 20, 35 };
		for (int l = 0; l < L; ++l)
		{
			int ncan2 = ncan[Locus[l].maxploidy] * ncan[Locus[l].maxploidy];
			Huang2012ML_Coef[l] = new double[ncan2 * 9];
			pcandidate[l] = new double[ncan2];
		}

		maps = new FASTTABLE<uint, uint>[8];
		codes = new uint64*[8];
		codes[0] = new uint64[2 + 1];
		codes[1] = new uint64[9 + 1];
		codes[2] = new uint64[31 + 1];
		codes[3] = new uint64[109 + 1];
		codes[4] = new uint64[339 + 1];
		codes[5] = new uint64[1043 + 1];
		codes[6] = new uint64[2998 + 1];
		codes[7] = new uint64[8405 + 1];
		init(maps, codes);
		Huang2012ML_Initialized = true;
	}
	void Huang2012ML_Uninitialize()
	{
		if (!Huang2012ML_Initialized)
			return;
		
		for (int l = 0; l < L; ++l)
		{
			delete[] Huang2012ML_Coef[l];
			delete[] pcandidate[l];
		}
		delete[] Huang2012ML_Coef;
		delete[] pcandidate;
		delete[] ncandidate;
		delete[] codes[0];
		delete[] codes[1];
		delete[] codes[2];
		delete[] codes[3];
		delete[] codes[4];
		delete[] codes[5];
		delete[] codes[6];
		delete[] codes[7];
		delete[] codes;
		delete[] maps;
		Huang2012ML_Initialized = false;
	}

	//assign the allele of true genotype by standard genotye pattern
	void Huang2012ML_MatchAllele(uint64 code, int *gx, int * gy, int *alleles, int p)
	{
		for (int i = 0; i < 16; ++i)
			alleles[i] = 0;
		int n = max2(code & 0xF, (code >> (p * 4)) & 0xF) + 1;
		int a1[16], a2[16], a22[16], a22n = 0;
		int cx[8], cy[8];
		for (int i = p - 1; i >= 0; --i)
		{
			cy[i] = code & 0xF;
			code >>= 4;
		}
		for (int i = p - 1; i >= 0; --i)
		{
			cx[i] = code & 0xF;
			code >>= 4;
		}
		for (int i = 0; i < n; ++i)
		{
			int a = 0, b = 0;
			for (int j = 0; j < p; ++j)
			{
				if (cx[j] == i)
					a++;
				if (cy[j] == i)
					b++;
			}
			a1[i] = (a << 20) | (b << 16) | i;
		}
		
		for (int i = 0; i < p + p; ++i)
		{
			int ta = i >= p ? gy[i - p] : gx[i];
			//find is ta in a22
			bool flag = false;
			for (int j = 0; j < a22n; ++j)
				if (a22[j] == ta)
					flag = true;
			if (flag)
				continue;
			a22[a22n] = ta;
			int a = 0, b = 0;
			for (int j = 0; j < p; ++j)
			{
				if (gx[j] == ta)
					a++;
				if (gy[j] == ta)
					b++;
			}
			a2[a22n++] = (a << 20) | (b << 16) | ta;
		}
		
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
			{
				if (a1[j] < a1[i])
				{
					int t = a1[i];
					a1[i] = a1[j];
					a1[j] = t;
				}
				if (a2[j] < a2[i])
				{
					int t = a2[i];
					a2[i] = a2[j];
					a2[j] = t;
				}
			}

		for (int i = 0; i < n; ++i)
			alleles[a1[i] & 0xF] = a2[i] & 0xFFFF;
	}

	bool Huang2012ML_GetIBS(GENOTYPE &x, GENOTYPE &y)
	{
		int px = x.ploidy[0], py = y.ploidy[0];
		int maxv = px > py ? px : py;

		for (int l = 0; l < L; ++l)
		{
			if (x.ploidy[l] != px || y.ploidy[l] != py)
			{
				ncandidate[l] = 0;
				return false;
			}
			
			int xx1[8] = {x.a[l], x.b[l], x.c[l], x.d[l], x.e[l], x.f[l], x.g[l], x.h[l]};
			int yy1[8] = {y.a[l], y.b[l], y.c[l], y.d[l], y.e[l], y.f[l], y.g[l], y.h[l]};
			
			int maxploidy = px > py ? px : py;
			for (int i = px; i < maxploidy; ++i)
				xx1[i] = Locus[l].n;
			for (int i = py; i < maxploidy; ++i)
				yy1[i] = Locus[l].n;
			
			if (IsMissingGenotype(x, y, l) || IsAllAmbiguousGenotype(x, y, l) || Locus[l].n <= 1)
			{
				ncandidate[l] = 0;
				continue;
			}

			//remove repeat allele
			if (rem)
			{
				for (int i2 = 0; i2 < px; ++i2)
					for (int i3 = i2 + 1; i3 < px; ++i3)
						if (xx1[i2] == xx1[i3])
							xx1[i3] = AMBIGUOUS_ALLELE;
				for (int i2 = 0; i2 < py; ++i2)
					for (int i3 = i2 + 1; i3 < py; ++i3)
						if (yy1[i2] == yy1[i3])
							yy1[i3] = AMBIGUOUS_ALLELE;
			}

			int xx[35][8], xxn;
			int yy[35][8], yyn;
			int alleles[16];

			int nn = -1;
			double xxp[35] = {0};
			double yyp[35] = {0};
			int cx = sort_count(xx1, px);
			int cy = sort_count(yy1, py);
			
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, l, maxploidy, maxploidy, 8);
			yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, l, maxploidy, maxploidy, 8);
			ncandidate[l] = xxn * yyn;
			
			for (int l1 = 0; l1 < xxn; l1++)
			for (int l2 = 0; l2 < yyn; l2++)
			{
				nn++;
				pcandidate[l][nn] = xxp[l1] * yyp[l2];
				int* gx = xx[l1];
				for (int i = 0; i < px; ++i)
					for (int j = i + 1; j < px; ++j)
						if (gx[i] > gx[j])
						{
							int t1 = gx[i];
							gx[i] = gx[j];
							gx[j] = t1;
						}
					
				int* gy = yy[l2];
				for (int i = 0; i < py; ++i)
					for (int j = i + 1; j < py; ++j)
						if (gy[i] > gy[j])
						{
							int t1 = gy[i];
							gy[i] = gy[j];
							gy[j] = t1;
						}

				auto ibs = maps[maxploidy - 1][gethash(gx, gy, maxploidy)];
				if (ibs == 0) return false;
				Huang2012ML_MatchAllele(codes[maxploidy - 1][ibs], gx, gy, alleles, maxploidy);
				ml_assign(maxv, freobs[l], alleles, Huang2012ML_Coef[l] + nn * 9, ibs);
			}
		}
		return true;
	}
	/*weighted*/double Huang2015ML(GENOTYPE x, GENOTYPE y)
	{
		if (!Huang2012ML_Initialized) Huang2012ML_Initialize();
		//bool confine = true;
		int px = x.ploidy[0];
		int py = y.ploidy[0];
		int ploidy = px > py ? py : px;
		if (!Huang2012ML_GetIBS(x, y)) return nan;
		point4 xx[9] = {0};
		for (int i = 0; i <= ploidy; ++i) 
		{
			xx[i].dem = ploidy;
			xx[i].diff = abs(px - py);
			xx[i].confine = !(px == py && px != PLOIDY);
			if (i) xx[i].image[i - 1] = 0.1;
			xx[i].li = Huang2012ML_Likelihood(xx[i]);
		}
		double sep = 0.1;
		double likestop = LIKESTOP1;
		for (int kk = 0; kk < 10; ++kk)
		{
			//Order
			order(xx);
			int searchcount;

			searchcount = 0;
			//downhill simplex method
			while (!isbreak(xx, LIKESTOP1) && searchcount < MAX_ITER_ML)
			{
				searchcount++;
				//Reflect
				point4 x0 = xx[0];
				for (int i = 1; i < ploidy; ++i)
					x0 += xx[i];
				x0 /= ploidy;
				point4 xr = x0 + (x0 - xx[ploidy]);
				xr.li = Huang2012ML_Likelihood(xr);

				//Expansion
				//best
				if (xr > xx[0])
				{
					point4 xe = x0 + (x0 - xx[ploidy]) * 2;
					xe.li = Huang2012ML_Likelihood(xe);
					memmove(xx + 1, xx, sizeof(point4) * ploidy);
					xx[0] = xe > xr ? xe : xr;
					continue;
				}
				//better than second worst
				if (xr > xx[ploidy - 1])
				{
					xx[ploidy] = xr;
					order(xx);
					continue;
				}
				//worse than second worst
				//Contraction
				point4 xc = xx[ploidy] + (x0 - xx[ploidy]) * 0.5;
				xc.li = Huang2012ML_Likelihood(xc);
				if (xc > xx[ploidy])
				{
					xx[ploidy] = xc;
					order(xx);
					continue;
				}
			
				//Reduction
				for (int i = 1; i <= ploidy; ++i)
				{
					xx[i] = (xx[0] + xx[i]) / 2;
					xx[i].li = Huang2012ML_Likelihood(xx[i]);
				}
				order(xx);
				continue;
			}
		
			//step 2
			for (int i = 1; i <= ploidy; ++i) 
			{
				xx[i] = xx[0];
				xx[i].image[i - 1] *= (1 - sep);
				xx[i].li = Huang2012ML_Likelihood(xx[i]);
			}
			//Order
			sep /= 2;
			likestop /= 2;
		}
		order(xx);
		xx[0].i2r();
		int maxploidy = px > py ? px : py;
		int minploidy = px > py ? py : px;
		double re = 0;
		for (int i = 0; i < minploidy; ++i)
			re += xx[0].real[i] * (minploidy - i) / maxploidy;
		return re;
		/*
		if (xx[0].li < xx2.li)
		{
			double diffr = fabs(re - xx2.image[0]);
			if (diffr > 0.00001)
				diffr = diffr;
		}
		*/
	}
	/*weighted*/double Huang2012ML_Likelihood(point4& xx)
	{
		//calc coef
		
		double re = 0;
		xx.i2r();
		for (int i = 0; i < L; ++i)
			for (int j = 0; j < ncandidate[i]; ++j)
			{
				double lt = 0;
				for (int k = 0; k <= xx.dem; ++k)
					lt += Huang2012ML_Coef[i][j * 9 + k + xx.diff] * xx.real[k] / bi[xx.diff + k][xx.diff];
				re += Locus[i].weight * pcandidate[i][j] * mylog10(lt);
			}
		xx.li = re < MINLIKELIHOOD ? MINLIKELIHOOD : re;
		return xx.li;
	}

	//get the mode of reference genotype
	int GetRefMode(int *a, int ploidy)
	{
		int score = 0;
		for (int i = 0; i < ploidy; ++i)
			for (int j = i + 1; j < ploidy; ++j)
				if (a[i] == a[j])
					score++;
		int kind = 1;
		int last = 0;
		vector<int> tkind;
		vector<int> tkind2;
		for (int i = 1; i < ploidy; ++i)
			if (a[i] != a[i - 1])
			{
				kind++;
				tkind.push_back(i - last);
				tkind2.push_back(a[last]);
				last = i;
			}
		tkind.push_back(ploidy - last);
		tkind2.push_back(a[last]);
		for (int i = 0; i < kind; ++i)
		{
			for (int j = i + 1; j < kind; ++j)
			{
				if (tkind[i] < tkind[j])
				{
					int tt = tkind[i];
					tkind[i] = tkind[j];
					tkind[j] = tt;
					tt = tkind2[i];
					tkind2[i] = tkind2[j];
					tkind2[j] = tt;
				}
			}
		}
		int tc = 0;
		for (int i = 0; i < kind; ++i)
			for (int j = 0; j < tkind[i]; ++j)
				a[tc++] = tkind2[i];
		
		vector<int>().swap(tkind); 
		vector<int>().swap(tkind2); 

		switch (ploidy)
		{
			case 1: switch (score)
			{
				case 0: return 1;
				default: return 0;
			}
			case 2: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				default: return 0;
			}
			case 3: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 3: return 3;
				default: return 0;
			}
			case 4: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 2: return 3;
				case 3: return 4;
				case 6: return 5;
				default: return 0;
			}
			case 5: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 2: return 3;
				case 3: return 4;
				case 4: return 5;
				case 6: return 6;
				case 10: return 7;
				default: return 0;
			}
			case 6: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 2: return 3;
				case 3: return kind == 3 ? 4 : 5;
				case 4: return 6;
				case 6: return kind == 2 ? 7 : 8;
				case 7: return 9;
				case 10: return 10;
				case 15: return 11;
				default: return 0;
			}
			case 7: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 2: return 3;
				case 3: return kind == 4 ? 4 : 5;
				case 4: return 6;
				case 5: return 7;
				case 6: return kind == 3 ? 8 : 9;
				case 7: return 10;
				case 9: return 11;
				case 10: return 12;
				case 11: return 13;
				case 15: return 14;
				case 21: return 15;
				default: return 0;
			}
			case 8: switch (score)
			{
				case 0: return 1;
				case 1: return 2;
				case 2: return 3;
				case 3: return kind == 5 ? 4 : 6;
				case 4: return kind == 4 ? 5 : 7;
				case 5: return 8;
				case 6: return kind == 4 ? 9 : 11;
				case 7: return kind == 3 ? 10 : 12;
				case 8: return 13;
				case 9: return 14;
				case 10: return 16;
				case 11: return 17;
				case 12: return 15;
				case 13: return 18;
				case 15: return 19;
				case 16: return 20;
				case 21: return 21;
				case 28: return 22;
				default: return 0;
			}
			default: return 0;
		}
	}
	double (*sx)[35];
	double (*sy)[35];
	/*weighted*/double R_Ritland1(GENOTYPE x, int LL = -1)
	{
		//per locus
		//double FST = 0;
		double sw = 0, sr = 0;
		int v = x.ploidy[0];
		for (int i = (LL == -1 ? 0 : LL); i < (LL == -1 ? L : LL + 1); ++i)
		{
			if (IsMissingGenotype(x, x, i) || IsAllAmbiguousGenotype(x, x, i) || Locus[i].n <= 1) continue;
			int ploidy = x.ploidy[i];
			if (ploidy != v)
			{
				delete[] sx;
				return nan;
			}
			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int xx[35][CPM8], xxn;
			double xxp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			
			for (int j = 0; j < Locus[i].n; ++j)
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i);
			
			double t1 = 0;
			for (int a = 0; a < xxn; ++a)
			{
				for (int j = 0; j < Locus[i].n; ++j)
				{
					if (freobs[i][j] == 0)
						continue;
					t1 += xxp[a] * sx[j][a] * sx[j][a] / freobs[i][j];
				}
			}

			sr += Locus[i].weight * ploidy * (t1 - 1);
			sw += Locus[i].weight * (Locus[i].n - 1);
		}
		return sr / sw;
	}
	/*weighted*/double R_Ritland(GENOTYPE x, GENOTYPE y, bool iscorrect)
	{
		//per locus
		//double FST = 0;
		double sw = 0, sr = 0;
		for (int i = 0; i < L; ++i)
		{
			if (IsMissingGenotype(x, y, i) || IsAllAmbiguousGenotype(x, y, i) || Locus[i].n <= 1) continue;
			int ploidy = max2(x.ploidy[i], y.ploidy[i]);
			int minploidy = min2(x.ploidy[i], y.ploidy[i]);

			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int yy1[CPM8] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i], y.g[i], y.h[i]};
			int xx[35][CPM8], xxn;
			int yy[35][CPM8], yyn;
			double xxp[35] = {0};	
			double yyp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int ploidyy = y.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			int cy = sort_count(yy1, ploidyy);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, ploidyy, MAXPLOIDY);
			
			for (int j = 0; j < Locus[i].n; ++j)
			{
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i);
				for (int b = 0; b < yyn; ++b)
					sy[j][b] = GetSI(yy[b], ploidyy, j, ploidy, i);
			}
			
			double t1 = 0, t2 = 0, t3 = 0;
			for (int a = 0; a < xxn; ++a)
			{
				for (int b = 0; b < yyn; ++b)
					for (int j = 0; j < Locus[i].n; ++j)
					{
						if (freobs[i][j] == 0)
							continue;
						t1 += xxp[a] * yyp[b] * sx[j][a] * sy[j][b] / freobs[i][j];
					}
			}
			
			for (int a = 0; a < xxn; ++a)
				for (int j = 0; j < Locus[i].n; ++j)
				{
					if (freobs[i][j] == 0) continue;
					t2 += xxp[a] * sx[j][a] * sx[j][a] / freobs[i][j];
				}
			
			for (int a = 0; a < yyn; ++a)
				for (int j = 0; j < Locus[i].n; ++j)
				{
					if (freobs[i][j] == 0) continue;
					t3 += yyp[a] * sy[j][a] * sy[j][a] / freobs[i][j];
				}

			t1 -= 1;
			t2 -= 1;
			t3 -= 1;
			double r = t1 / (2 / (1 / t2 + 1 / t3));
			if (r > 1e100 || r < -1e100 || r >= 0 == false && r < 0 == false) continue;
			sr += iscorrect ? Locus[i].weight * Locus[i].AR * r * 2 * minploidy / (minploidy + ploidy) : 
							  Locus[i].weight * minploidy * t1;

			sw += iscorrect ? Locus[i].weight * Locus[i].AR : 
				              Locus[i].weight * (Locus[i].n - 1);
		}
		return sr / sw;
	}
	/*weighted*/double R_Loiselle1(GENOTYPE x, int LL = -1)
	{
		//double FST = 0;
		double sw = 0, sr1 = 0, sr2 = 0;
		int v = x.ploidy[0];
		for (int i = (LL == -1 ? 0 : LL); i < (LL == -1 ? L : LL + 1); ++i)
		{
			if (IsMissingGenotype(x, x, i) || IsAllAmbiguousGenotype(x, x, i) || Locus[i].n <= 1) continue;
			int ploidy = x.ploidy[i];
			if (ploidy != v) return nan;
			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int xx[35][CPM8], xxn;	
			double xxp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			
			for (int j = 0; j < Locus[i].n; ++j)
			{
				sw  += Locus[i].weight * freobs[i][j] * (1 - freobs[i][j]);
				sr2 += ploidy * 0;//Locus[i].weight * freobs[i][a] * (1 - freobs[i][a]) / (Count_allele - 1);
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i) - freobs[i][j];
			}
			
			for (int a = 0; a < xxn; ++a)
				for (int j = 0; j < Locus[i].n; ++j)
					sr1 += Locus[i].weight * ploidy * xxp[a] * sx[j][a] * sx[j][a];
			
		}
		return (sr1 + sr2) / sw;
	}
	/*weighted*/double R_Loiselle(GENOTYPE x, GENOTYPE y, bool iscorrect)
	{
		//double FST = 0;
		double sw = 0, sr1 = 0, sr2 = 0;
		for (int i = 0; i < L; ++i)
		{
			if (IsMissingGenotype(x, y, i) || IsAllAmbiguousGenotype(x, y, i) || Locus[i].n <= 1) continue;
			int ploidy = max2(x.ploidy[i], y.ploidy[i]);
			int minploidy = min2(x.ploidy[i], y.ploidy[i]);
			
			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int yy1[CPM8] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i], y.g[i], y.h[i]};
			int xx[35][CPM8], xxn;	
			int yy[35][CPM8], yyn;	
			double xxp[35] = {0};	
			double yyp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int ploidyy = y.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			int cy = sort_count(yy1, ploidyy);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, ploidyy, MAXPLOIDY);
			
			double sw1 = 0;
			double t1 = 0, t2 = 0, t3 = 0;
			for (int j = 0; j < Locus[i].n; ++j)
			{
				sw1 += freobs[i][j] * (1 - freobs[i][j]);
				sr2 += ploidy * 0;//Locus[i].weight * freobs[i][a] * (1 - freobs[i][a]) / (Count_allele - 1);
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i) - freobs[i][j];
				for (int b = 0; b < yyn; ++b)
					sy[j][b] = GetSI(yy[b], ploidyy, j, ploidy, i) - freobs[i][j];
			}
			
			for (int a = 0; a < xxn; ++a)
				for (int b = 0; b < yyn; ++b)
					for (int j = 0; j < Locus[i].n; ++j)
						t1 += xxp[a] * yyp[b] * sx[j][a] * sy[j][b];
			
			for (int a = 0; a < xxn; ++a)
				for (int j = 0; j < Locus[i].n; ++j)
                    t2 += xxp[a] * sx[j][a] * sx[j][a];
			
			for (int b = 0; b < yyn; ++b)
				for (int j = 0; j < Locus[i].n; ++j)
                    t3 += yyp[b] * sy[j][b] * sy[j][b];
			
			if (t2 < 1e-3 || t3 < 1e-3) continue;
			double r = t1 / (2 / (1 / t2 + 1 / t3));

            sr1 += iscorrect ? Locus[i].weight * Locus[i].AR * 2 * minploidy / (minploidy + ploidy) * r : 
				               Locus[i].weight * minploidy * t1;
			sw +=  iscorrect ? Locus[i].weight * Locus[i].AR : 
							   Locus[i].weight * sw1;
		}
		return (sr1 + sr2) / sw;
	}
	/*weighted*/double R_Weir1(GENOTYPE x, int LL = -1)
	{
		//double FST = 0;
		double J1 = 0, J2 = 0, S = 0;
		double N = 0;
		int v = x.ploidy[0];
		for (int i = (LL == -1 ? 0 : LL); i < (LL == -1 ? L : LL + 1); ++i)
		{
			if (IsMissingGenotype(x, x, i) || IsAllAmbiguousGenotype(x, x, i) || Locus[i].n <= 1) continue;
			int ploidy = x.ploidy[i];
			if (ploidy != v)
			{
				delete[] sx;
				return nan;
			}
			N += Locus[i].weight;
			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int xx[35][CPM8], xxn;	
			double xxp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			
			for (int j = 0; j < Locus[i].n; ++j)
			{
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i);
				J1 += Locus[i].weight * ploidy * freobs[i][j] * freobs[i][j];
				J2 += Locus[i].weight * freobs[i][j] * freobs[i][j];
			}
			
			for (int a = 0; a < xxn; ++a)
				for (int j = 0; j < Locus[i].n; ++j)
					S += Locus[i].weight * ploidy * xxp[a] * sx[j][a] * sx[j][a];
			
		}
		return (S - J1) / (N - J2);
	}
	/*weighted*/double R_Weir(GENOTYPE x, GENOTYPE y)
	{
		//double FST = 0;
		double J1 = 0, J2 = 0, S = 0;
		double N = 0;
		for (int i = 0; i < L; ++i)
		{
			if (IsMissingGenotype(x, y, i) || IsAllAmbiguousGenotype(x, y, i) || Locus[i].n <= 1) continue;
			int ploidy = max2(x.ploidy[i], y.ploidy[i]);
			int minploidy = min2(x.ploidy[i], y.ploidy[i]);
			
			N += Locus[i].weight;
			int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
			int yy1[CPM8] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i], y.g[i], y.h[i]};
			int xx[35][CPM8], xxn;	
			int yy[35][CPM8], yyn;	
			double xxp[35] = {0};	
			double yyp[35] = {0};	
			int ploidyx = x.ploidy[i];
			int ploidyy = y.ploidy[i];
			int cx = sort_count(xx1, ploidyx);
			int cy = sort_count(yy1, ploidyy);
			xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, ploidyy, MAXPLOIDY);
			
			for (int j = 0; j < Locus[i].n; ++j)
			{
				for (int a = 0; a < xxn; ++a)
					sx[j][a] = GetSI(xx[a], ploidyx, j, ploidy, i);
				for (int b = 0; b < yyn; ++b)
					sy[j][b] = GetSI(yy[b], ploidyy, j, ploidy, i);
				J1 += Locus[i].weight * minploidy * freobs[i][j] * freobs[i][j];
				J2 += Locus[i].weight * freobs[i][j] * freobs[i][j];
			}
			
			for (int a = 0; a < xxn; ++a)
				for (int b = 0; b < yyn; ++b)
					for (int j = 0; j < Locus[i].n; ++j)
						S += Locus[i].weight * minploidy * xxp[a] * yyp[b] * sx[j][a] * sy[j][b];
		}
		return (S - J1) / (N - J2);
	}

	//calculate the similarity index
	double GetSI(int *x, int ploidy, int j, int maxploidy, int i)
	{
		int re = 0;
		for (int k = 0; k < ploidy; ++k)
			if (x[k] == j)
				re++;
		return (re + (maxploidy - ploidy) * freobs[i][j]) / (double)maxploidy;
	}

	//Polyploid moment estimator
	/*weighted*/double Huang2014Moment(GENOTYPE x, GENOTYPE y)
	{
		double sumr1 = 0, sumw1 = 0, sumr2 = 0, sumw2 = 0, tw = 0, tr = 0;
		for (int i = 0; i < L; ++i)
		{
			if (IsMissingGenotype(x, y, i) || IsAllAmbiguousGenotype(x, y, i) || Locus[i].n <= 1) continue;
			switch (max2(x.ploidy[i], y.ploidy[i]))
			{
				case 1: tr = Huang2013Moment1(x, y, i, tw); break; 
				case 2: tr = Huang2013Moment2(x, y, i, tw); break; 
				case 3: tr = Huang2013Moment3(x, y, i, tw); break; 
				case 4: tr = Huang2013Moment4(x, y, i, tw); break; 
				case 5: tr = Huang2013Moment5(x, y, i, tw); break; 
				case 6: tr = Huang2013Moment6(x, y, i, tw); break; 
				case 7: tr = Huang2013Moment7(x, y, i, tw); break; 
				case 8: tr = Huang2013Moment8(x, y, i, tw); break; 
			}
			sumr1 += Locus[i].weight * tr * tw;
			sumw1 += Locus[i].weight * tw;
			
			switch (max2(x.ploidy[i], y.ploidy[i]))
			{
				case 1: tr = Huang2013Moment1(y, x, i, tw); break; 
				case 2: tr = Huang2013Moment2(y, x, i, tw); break; 
				case 3: tr = Huang2013Moment3(y, x, i, tw); break; 
				case 4: tr = Huang2013Moment4(y, x, i, tw); break; 
				case 5: tr = Huang2013Moment5(y, x, i, tw); break; 
				case 6: tr = Huang2013Moment6(y, x, i, tw); break; 
				case 7: tr = Huang2013Moment7(y, x, i, tw); break; 
				case 8: tr = Huang2013Moment8(y, x, i, tw); break; 
			}
			sumr2 += Locus[i].weight * tr * tw;
			sumw2 += Locus[i].weight * tw;
		}
		return (sumr1 / sumw1 + sumr2 / sumw2) / 2;
	}
	double Huang2013Moment1(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM1] = {x.a[i]};
		int yy1[CPM1] = {y.a[i]};
		int xx[1][CPM1], xxn;	
		int yy[1][CPM1], yyn;	
		double xxp[1] = {0};	
		double yyp[1] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM1 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM1, CPM1);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM1, CPM1);
		double M[CPM1][CPM1] = {0};
		double A[CPM1] = {0};
		double PEvent[CPM1P] = {0};
		double SI[CPM1] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM1P][CPM1P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM1; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign1(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM1P; ++j1)
				for (int j2 = 0; j2 < CPM1; ++j2)
					e[j1][j2] -= e[j1][CPM1];
			
			double tma[CPM1] = {1};
			double tmb[CPM1] = {1};
			
			for (int j1 = 0; j1 < CPM1; ++j1)
			{
				for (int j2 = 0; j2 < CPM1; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM1; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM1; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM1] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM1; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM1];
		}
		double Delta[CPM1P] = {0};
		double Difference[CPM1P] = {0};
		for (int j1 = 0; j1 < CPM1; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM1; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM1; ++j2)
				M[j1][j2] = M[j2][CPM1 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM1; ++j1)
			M[j1][CPM1 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM1))
			return 0;
		Delta[CPM1] = Delta[0];
		double Similarity[CPM1P] = {1};
		double E1 = 0, E2 = 0;
		double Sol[CPM1P] = {0};
		for (int j1 = start; j1 < CPM1P; ++j1)
		{
			double Difference[CPM1];
			for (int j2 = 0; j2 < CPM1; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM1; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM1, CPM1, (double *)Difference, CPM1, 1, (double *)Sol);
			Sol[CPM1] = Sol[0];
			E1 += PEvent[j1] * Sol[CPM1];
			E2 += PEvent[j1] * Sol[CPM1] * Sol[CPM1];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM1];
	}
	double Huang2013Moment2(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM2] = {x.a[i], x.b[i]};
		int yy1[CPM2] = {y.a[i], y.b[i]};
		int xx[1][CPM2], xxn;	
		int yy[1][CPM2], yyn;	
		double xxp[1] = {0};	
		double yyp[1] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM2 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM2, CPM2);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM2, CPM2);
		double M[CPM2][CPM2] = {0};
		double A[CPM2] = {0};
		double PEvent[CPM2P] = {0};
		double SI[CPM2] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM2P][CPM2P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM2; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign2(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM2P; ++j1)
				for (int j2 = 0; j2 < CPM2; ++j2)
					e[j1][j2] -= e[j1][CPM2];
			
			double tma[CPM2] = {1, f12};
			double tmb[CPM2] = {1, 1};
			
			for (int j1 = 0; j1 < CPM2; ++j1)
			{
				for (int j2 = 0; j2 < CPM2; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM2; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM2; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM2] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM2; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM2];
		}
		double Delta[CPM2P] = {0};
		double Difference[CPM2P] = {0};
		for (int j1 = 0; j1 < CPM2; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM2; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM2; ++j2)
				M[j1][j2] = M[j2][CPM2 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM2; ++j1)
			M[j1][CPM2 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM2))
			return 0;
		Delta[CPM2] = Delta[0] + f12 * Delta[1];
		double Similarity[CPM2P] = {1, f12, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM2P] = {0};
		for (int j1 = start; j1 < CPM2P; ++j1)
		{
			double Difference[CPM2];
			for (int j2 = 0; j2 < CPM2; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM2; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM2, CPM2, (double *)Difference, CPM2, 1, (double *)Sol);
			Sol[CPM2] = Sol[0] + f12 * Sol[1];
			E1 += PEvent[j1] * Sol[CPM2];
			E2 += PEvent[j1] * Sol[CPM2] * Sol[CPM2];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM2];
	}
	double Huang2013Moment3(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM3] = {x.a[i], x.b[i], x.c[i]};
		int yy1[CPM3] = {y.a[i], y.b[i], y.c[i]};
		int xx[2][CPM3], xxn;	
		int yy[2][CPM3], yyn;	
		double xxp[2] = {0};	
		double yyp[2] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM3 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM3, CPM3);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM3, CPM3);
		double M[CPM3][CPM3] = {0};
		double A[CPM3] = {0};
		double PEvent[CPM3P] = {0};
		double SI[CPM3] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM3P][CPM3P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM3; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign3(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM3P; ++j1)
				for (int j2 = 0; j2 < CPM3; ++j2)
					e[j1][j2] -= e[j1][CPM3];
			
			double tma[CPM3] = {1, f23, f13};
			double tmb[CPM3] = {1, 1, 1};
			
			for (int j1 = 0; j1 < CPM3; ++j1)
			{
				for (int j2 = 0; j2 < CPM3; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM3; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM3; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM3] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM3; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM3];
		}
		double Delta[CPM3P] = {0};
		double Difference[CPM3P] = {0};
		for (int j1 = 0; j1 < CPM3; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM3; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM3; ++j2)
				M[j1][j2] = M[j2][CPM3 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM3; ++j1)
			M[j1][CPM3 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM3))
			return 0;
		Delta[CPM3] = Delta[0] + f23 * Delta[1] + f13 * Delta[2];
		double Similarity[CPM3P] = {1, f23, f13, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM3P] = {0};
		for (int j1 = start; j1 < CPM3P; ++j1)
		{
			double Difference[CPM3];
			for (int j2 = 0; j2 < CPM3; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM3; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM3, CPM3, (double *)Difference, CPM3, 1, (double *)Sol);
			Sol[CPM3] = Sol[0] + f23 * Sol[1] + f13 * Sol[2];
			E1 += PEvent[j1] * Sol[CPM3];
			E2 += PEvent[j1] * Sol[CPM3] * Sol[CPM3];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM3];
	}
	double Huang2013Moment4(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM4] = {x.a[i], x.b[i], x.c[i], x.d[i]};
		int yy1[CPM4] = {y.a[i], y.b[i], y.c[i], y.d[i]};
		int xx[3][CPM4], xxn;	
		int yy[3][CPM4], yyn;	
		double xxp[3] = {0};	
		double yyp[3] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM4 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM4, CPM4);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM4, CPM4);
		double M[CPM4][CPM4] = {0};
		double A[CPM4] = {0};
		double PEvent[CPM4P] = {0};
		double SI[CPM4] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM4P][CPM4P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM4; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign4(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM4P; ++j1)
				for (int j2 = 0; j2 < CPM4; ++j2)
					e[j1][j2] -= e[j1][CPM4];
			
			double tma[CPM4] = {1, f34, f24, f14};
			double tmb[CPM4] = {1, 1, 1, 1};
			
			for (int j1 = 0; j1 < CPM4; ++j1)
			{
				for (int j2 = 0; j2 < CPM4; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM4; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM4; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM4] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM4; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM4];
		}
		double Delta[CPM4P] = {0};
		double Difference[CPM4P] = {0};
		for (int j1 = 0; j1 < CPM4; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM4; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM4; ++j2)
				M[j1][j2] = M[j2][CPM4 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM4; ++j1)
			M[j1][CPM4 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM4))
			return 0;
		Delta[CPM4] = Delta[0] + f34 * Delta[1] + f24 * Delta[2] + f14 * Delta[3];
		double Similarity[CPM4P] = {1, f34, f24, f14, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM4P] = {0};
		for (int j1 = start; j1 < CPM4P; ++j1)
		{
			double Difference[CPM4];
			for (int j2 = 0; j2 < CPM4; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM4; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM4, CPM4, (double *)Difference, CPM4, 1, (double *)Sol);
			Sol[CPM4] = Sol[0] + f34 * Sol[1] + f24 * Sol[2] + f14 * Sol[3];
			E1 += PEvent[j1] * Sol[CPM4];
			E2 += PEvent[j1] * Sol[CPM4] * Sol[CPM4];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM4];
	}
	double Huang2013Moment5(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM5] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i]};
		int yy1[CPM5] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i]};
		int xx[10][CPM5], xxn;	
		int yy[10][CPM5], yyn;	
		double xxp[10] = {0};	
		double yyp[10] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM5 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM5, CPM5);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM5, CPM5);
		double M[CPM5][CPM5] = {0};
		double A[CPM5] = {0};
		double PEvent[CPM5P] = {0};
		double SI[CPM5] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM5P][CPM5P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM5; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign5(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM5P; ++j1)
				for (int j2 = 0; j2 < CPM5; ++j2)
					e[j1][j2] -= e[j1][CPM5];
			
			double tma[CPM5] = {1, f45, f35, f25, f15};
			double tmb[CPM5] = {1, 1, 1, 1, 1};
			
			for (int j1 = 0; j1 < CPM5; ++j1)
			{
				for (int j2 = 0; j2 < CPM5; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM5; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM5; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM5] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM5; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM5];
		}
		double Delta[CPM5P] = {0};
		double Difference[CPM5P] = {0};
		for (int j1 = 0; j1 < CPM5; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM5; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM5; ++j2)
				M[j1][j2] = M[j2][CPM5 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM5; ++j1)
			M[j1][CPM5 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM5))
			return 0;
		Delta[CPM5] = Delta[0] + f45 * Delta[1] + f35 * Delta[2] + f25 * Delta[3] + f15 * Delta[4];
		double Similarity[CPM5P] = {1, f45, f35, f25, f15, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM5P] = {0};
		for (int j1 = start; j1 < CPM5P; ++j1)
		{
			double Difference[CPM5];
			for (int j2 = 0; j2 < CPM5; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM5; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM5, CPM5, (double *)Difference, CPM5, 1, (double *)Sol);
			Sol[CPM5] = Sol[0] + f45 * Sol[1] + f35 * Sol[2] + f25 * Sol[3] + f15 * Sol[4];
			E1 += PEvent[j1] * Sol[CPM5];
			E2 += PEvent[j1] * Sol[CPM5] * Sol[CPM5];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM5];
	}
	double Huang2013Moment6(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM6] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i]};
		int yy1[CPM6] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i]};
		int xx[18][CPM6], xxn;	
		int yy[18][CPM6], yyn;	
		double xxp[18] = {0};	
		double yyp[18] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM6 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM6, CPM6);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM6, CPM6);
		double M[CPM6][CPM6] = {0};
		double A[CPM6] = {0};
		double PEvent[CPM6P] = {0};
		double SI[CPM6] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM6P][CPM6P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM6; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign6(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM6P; ++j1)
				for (int j2 = 0; j2 < CPM6; ++j2)
					e[j1][j2] -= e[j1][CPM6];
			
			double tma[CPM6] = {1, f56, f46, f36, f26, f16};
			double tmb[CPM6] = {1, 1, 1, 1, 1, 1};
			
			for (int j1 = 0; j1 < CPM6; ++j1)
			{
				for (int j2 = 0; j2 < CPM6; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM6; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM6; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM6] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM6; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM6];
		}
		double Delta[CPM6P] = {0};
		double Difference[CPM6P] = {0};
		for (int j1 = 0; j1 < CPM6; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM6; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM6; ++j2)
				M[j1][j2] = M[j2][CPM6 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM6; ++j1)
			M[j1][CPM6 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM6))
			return 0;
		Delta[CPM6] = Delta[0] + f56 * Delta[1] + f46 * Delta[2] + f36 * Delta[3] + f26 * Delta[4] + f16 * Delta[5];
		double Similarity[CPM6P] = {1, f56, f46, f36, f26, f16, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM6P] = {0};
		for (int j1 = start; j1 < CPM6P; ++j1)
		{
			double Difference[CPM6];
			for (int j2 = 0; j2 < CPM6; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM6; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM6, CPM6, (double *)Difference, CPM6, 1, (double *)Sol);
			Sol[CPM6] = Sol[0] + f56 * Sol[1] + f46 * Sol[2] + f36 * Sol[3] + f26 * Sol[4] + f16 * Sol[5];
			E1 += PEvent[j1] * Sol[CPM6];
			E2 += PEvent[j1] * Sol[CPM6] * Sol[CPM6];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		if (weight < EPS)
			weight = EPS;
		return Delta[CPM6];
	}
	double Huang2013Moment7(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM7] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i]};
		int yy1[CPM7] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i], y.g[i]};
		int xx[28][CPM7], xxn;	
		int yy[28][CPM7], yyn;	
		double xxp[28] = {0};	
		double yyp[28] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM7 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM7, CPM7);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM7, CPM7);
		double M[CPM7][CPM7] = {0};
		double A[CPM7] = {0};
		double PEvent[CPM7P] = {0};
		double SI[CPM7] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM7P][CPM7P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM7; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign7(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM7P; ++j1)
				for (int j2 = 0; j2 < CPM7; ++j2)
					e[j1][j2] -= e[j1][CPM7];
			
			double tma[CPM7] = {1, f67, f57, f47, f37, f27, f17};
			double tmb[CPM7] = {1, 1, 1, 1, 1, 1, 1};
			
			for (int j1 = 0; j1 < CPM7; ++j1)
			{
				for (int j2 = 0; j2 < CPM7; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM7; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM7; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM7] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM7; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM7];
		}
		double Delta[CPM7P] = {0};
		double Difference[CPM7P] = {0};
		for (int j1 = 0; j1 < CPM7; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM7; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM7; ++j2)
				M[j1][j2] = M[j2][CPM7 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM7; ++j1)
			M[j1][CPM7 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM7))
			return 0;
		Delta[CPM7] = Delta[0] + f67 * Delta[1] + f57 * Delta[2] + f47 * Delta[3] + f37 * Delta[4] + f27 * Delta[5] + f17 * Delta[6];
		double Similarity[CPM7P] = {1, f67, f57, f47, f37, f27, f17, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM7P] = {0};
		for (int j1 = start; j1 < CPM7P; ++j1)
		{
			double Difference[CPM7];
			for (int j2 = 0; j2 < CPM7; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM7; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM7, CPM7, (double *)Difference, CPM7, 1, (double *)Sol);
			Sol[CPM7] = Sol[0] + f67 * Sol[1] + f57 * Sol[2] + f47 * Sol[3] + f37 * Sol[4] + f27 * Sol[5] + f17 * Sol[6];
			E1 += PEvent[j1] * Sol[CPM7];
			E2 += PEvent[j1] * Sol[CPM7] * Sol[CPM7];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM7];
	}
	double Huang2013Moment8(GENOTYPE x, GENOTYPE y, int i, double & weight)
	{
		weight = EPS;
		int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
		int yy1[CPM8] = {y.a[i], y.b[i], y.c[i], y.d[i], y.e[i], y.f[i], y.g[i], y.h[i]};
		
		int xx[35][CPM8], xxn;	
		int yy[35][CPM8], yyn;	
		double xxp[35] = {0};	
		double yyp[35] = {0};	
		int ploidyx = x.ploidy[i];
		int ploidyy = y.ploidy[i];
		int minploidy = min(ploidyx, ploidyy);
		int start = CPM8 - minploidy; 
		int cx = sort_count(xx1, ploidyx);
		int cy = sort_count(yy1, ploidyy);
		xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, CPM8, CPM8);
		yyn = getcandidate(cy, yy1, (int *)&yy[0][0], yyp, i, ploidyy, CPM8, CPM8);
		double M[CPM8][CPM8] = {0};
		double A[CPM8] = {0};
		double PEvent[CPM8P] = {0};
		double SI[CPM8] = {0};
		for (int i2 = 0; i2 < xxn; ++i2)
		{
			//iterate possible genotype of individual X
			double e[CPM8P][CPM8P] = {0};
			
			//weighting Similary index
			int refmode = 10000 * ploidyy + 100 * ploidyx + GetRefMode(xx[i2], ploidyx);
			for (int i3 = 0; i3 < yyn; ++i3)
			{
				double Si = S_Index(xx[i2], yy[i3], ploidyx, ploidyy);
				double p = xxp[i2] * yyp[i3];
				for (int i4 = 0; i4 < CPM8; ++i4)
					SI[i4] += mp(Si, i4 + 1) * p;
			}
			
			mom_assign8(refmode, e, freobs[i], xx[i2]);
			
			for (int j1 = 0; j1 < CPM8P; ++j1)
				for (int j2 = 0; j2 < CPM8; ++j2)
					e[j1][j2] -= e[j1][CPM8];
			
			double tma[CPM8] = {1, f78, f68, f58, f48, f38, f28, f18};
			double tmb[CPM8] = {1, 1, 1, 1, 1, 1, 1, 1};
			
			for (int j1 = 0; j1 < CPM8; ++j1)
			{
				for (int j2 = 0; j2 < CPM8; ++j2)
					tmb[j2] *= tma[j2];
				
				double t1 = 0;
				for (int j2 = 0; j2 < CPM8; ++j2)
				{
					double t = 0;
					for (int j3 = 0; j3 < CPM8; ++j3)
						t += e[j3][j2] * tmb[j3];
					M[j1][j2] += xxp[i2] * t;
					t1 += e[j2][CPM8] * tmb[j2];
				}
				A[j1]    += xxp[i2] * t1;
			}
			for (int j1 = 0; j1 <= CPM8; ++j1)
				PEvent[j1] += xxp[i2] * e[j1][CPM8];
		}
		double Delta[CPM8P] = {0};
		double Difference[CPM8P] = {0};
		for (int j1 = 0; j1 < CPM8; ++j1)
			Difference[j1] = SI[j1] - A[j1];
		for (int j1 = minploidy; j1 < CPM8; ++j1)
		{
			Difference[j1] = 0;
			for (int j2 = 0; j2 < CPM8; ++j2)
				M[j1][j2] = M[j2][CPM8 - 1 - j1] = 0;
		}
		for (int j1 = minploidy; j1 < CPM8; ++j1)
			M[j1][CPM8 - 1 - j1] = 1;
		if (!SolveEquation((double *)M, Difference, Delta, CPM8))
			return 0;
		Delta[CPM8] = Delta[0] + f78 * Delta[1] + f68 * Delta[2] + f58 * Delta[3] + f48 * Delta[4] + f38 * Delta[5] + f28 * Delta[6] + f18 * Delta[7];
		double Similarity[CPM8P] = {1, f78, f68, f58, f48, f38, f28, f18, 0};
		double E1 = 0, E2 = 0;
		double Sol[CPM8P] = {0};
		for (int j1 = start; j1 < CPM8P; ++j1)
		{
			double Difference[CPM8];
			for (int j2 = 0; j2 < CPM8; ++j2)
				Difference[j2] = mp(Similarity[j1], j2 + 1) - A[j2];
			for (int j2 = minploidy; j2 < CPM8; ++j2)
				Difference[j2] = 0;
			mul((double *)M, CPM8, CPM8, (double *)Difference, CPM8, 1, (double *)Sol);
			Sol[CPM8] = Sol[0] + f78 * Sol[1] + f68 * Sol[2] + f58 * Sol[3] + f48 * Sol[4] + f38 * Sol[5] + f28 * Sol[6] + f18 * Sol[7];
			E1 += PEvent[j1] * Sol[CPM8];
			E2 += PEvent[j1] * Sol[CPM8] * Sol[CPM8];
		}
		weight = 1 / (E2 - E1 * E1);
		if (weight > MAX_WEIGHT)
			weight = MAX_WEIGHT;
		return Delta[CPM8];
	}
	
	//correction if the allele frequency is calculated from genotypes, but I did not applied it because the few estimator have this correction and it would make software in a mess
	//#define iscurrent false 

	//Lynch & Ritland (1999) estimator, with null alleles correction, FST correction is not applied in this software
	double R_LynchSub(GENOTYPE x, GENOTYPE y)
	{
		double swr = 0, swd = 0, sr = 0, sd = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			if (x.a[i] == x.b[i])
			{
				//Homo
				int PW;
				if (y.a[i] == x.a[i] && y.b[i] == x.a[i]) PW = 1;
				else if (y.a[i] == x.a[i] || y.b[i] == x.a[i]) PW = 2;
				else  PW = 3;
				double pi = frenull[i][x.a[i]];
				double py = Locus[i].py;
				double px = 1 - pi - py;
				double r1 = 0, r2 = 0, d2 = 0, d1 = 0, r, d;
				for (int pw = 1; pw <= 3; ++pw)
				{
					double pt = 0;
					r = R_LynchCHomo(pi, py, pw, d);
					
					switch (pw)
					{
					case 1: pt = (pi * pi + 2 * pi * py) / (1 - py * py); break;
					case 2: pt = (2 * pi * px) / (1 - py * py); break;
					case 3: pt = (px * px + 2 * px * py) / (1 - py * py); break;
					}
					r1 += pt * r;
					r2 += pt * r * r;
					d1 += pt * d;
					d2 += pt * d * d;
				}
				double wr = Locus[i].weight / (r2 - r1 * r1);
				double wd = Locus[i].weight / (d2 - d1 * d1);
				swr += wr;
				swd += wd;
				r = R_LynchCHomo(pi, py, PW, d);
				sr += wr * r;
				sd += wd * d;
			}
			else
			{
				//Hetero
				int PW;
				if (y.a[i] == x.a[i] && y.b[i] == x.a[i]) PW = 1;
				else if (y.a[i] == x.b[i] && y.b[i] == x.b[i]) PW = 2;
				else if ((y.a[i] == x.a[i] && y.b[i] == x.b[i]) || (y.a[i] == x.b[i] && y.b[i] == x.a[i])) PW = 3;
				else if (y.a[i] == x.a[i] || y.b[i] == x.a[i]) PW = 4;
				else if (y.a[i] == x.b[i] || y.b[i] == x.b[i]) PW = 5;
				else PW = 6;
				double pi = frenull[i][x.a[i]];
				double pj = frenull[i][x.b[i]];
				double py = Locus[i].py;
				double px = 1 - pi - pj - py;
				double r1 = 0, r2 = 0, d2 = 0, d1 = 0, r, d;
				for (int pw = 1; pw <= 6; ++pw)
				{
					double pt = 0;
					r = R_LynchCHeter(pi, pj, py, pw, d);
					
					switch (pw)
					{
					case 1: pt = (pi * pi + 2 * pi * py) / (1 - py * py); break;
					case 2: pt = (pj * pj + 2 * pj * py) / (1 - py * py); break;
					case 3: pt = (2 * pi * pj) / (1 - py * py); break;
					case 4: pt = (2 * pi * px) / (1 - py * py); break;
					case 5: pt = (2 * pj * px) / (1 - py * py); break;
					case 6: pt = (px * px + 2 * px * py) / (1 - py * py); break;
					}
					r1 += pt * r;
					r2 += pt * r * r;
					d1 += pt * d;
					d2 += pt * d * d;
				}
				double wr = Locus[i].weight / (r2 - r1 * r1);
				double wd = Locus[i].weight / (d2 - d1 * d1);
				swr += wr;
				swd += wd;
				r = R_LynchCHeter(pi, pj, py, PW, d);
				sr += wr * r;
				sd += wd * d;
			}
		}
		sd /= swd;
		sr /= swr;
		return sr;
	}
	double R_LynchCHomo(double pi, double py, int PW, double &delta)
	{
		double P1 = 0, P2 = 0;
		switch (PW)
		{
		case 1: P1 = 1; break;
		case 2: P2 = 1; break;
		}
		double py2 = py * py, py3 = py2 * py;
		double pi2 = pi * pi;
		delta=-(2*pi2*(-P2+pi)+(P2-pi)*(-6+pi)*pi*py+P2*(-2+pi)*py2+P2*(-2+pi)*py3+P1*(2*pi2*(-2+py)+2*py-2*py3+pi*(2+py*(-9+py*(2+py)))))/((-1+pi+py)*(pi2*(-2+py)+2*py*(1+py)-pi*(-2+py*(5+py))));
		double phi=((-2+py)*(pi+2*py)*(2*(-1+P1)*pi+P2*(1+pi+py)))/((-1+pi+py)*(pi2*(-2+py)+2*py*(1+py)-pi*(-2+py*(5+py))));
		return delta + phi / 2;
	}
	double R_LynchCHeter(double pi, double pj, double py, int PW, double &delta)
	{
		double P1 = 0, P2 = 0, P3 = 0, P4 = 0, P5 = 0;
		switch (PW)
		{
		case 1: P1 = 1; break;
		case 2: P2 = 1; break;
		case 3: P3 = 1; break;
		case 4: P4 = 1; break;
		case 5: P5 = 1; break;
		}
		double py2 = py * py, py3 = py2 * py, py4 = py3 * py;
		double pi2 = pi * pi, pi3 = pi2 * pi;
		double pj2 = pj * pj, pj3 = pj2 * pj;
		delta=(2*P2*pi*(pj+py)*(pi+2*py)*(pj*(-1+py2)+pi*(-1+4*pj+py2))+P5*pi*(pi+2*py)*(pj+2*py)*(pj*(-1+py2)+pi*(-1+4*pj+py2))+pj*(2*P1*(pi+py)*(pj+2*py)*(pj*(-1+py2)+pi*(-1+4*pj+py2))+P4*(pi+2*py)*(pj+2*py)*(pj*(-1+py2)+pi*(-1+4*pj+py2))+2*pi*(2*pj*py*(pj+2*py)+pi2*(pj-4*pj2+2*py-7*pj*py)+pi*(pj2*(1-7*py)+4*pj*(1-3*py)*py+4*py2)))+P3*(2*(-1+pj)*pj*py*(pj+2*py)*(-1+py2)+pi3*(pj+2*py)*(-1+4*pj+py2)+pi2*(4*pj3+2*(-1+py)*py*(1+py)*(-1+2*py)-pj*(-1+py)*(1+(-14+py)*py)-2*pj2*(3+(-8+py)*py))+pi*(-pj2*(-1+py)*(1+(-14+py)*py)-4*py2*(-1+py2)+pj3*(-1+py*(8+py))-4*pj*py*(-1+py*(7+py+py2)))))/(2*(-1+pj)*pj*py*(pj+2*py)*(-1+py2)+pi2*(pj*(1+6*(-1+pj)*pj)+2*py+pj*(-15+2*(12-7*pj)*pj)*py+(-4+(23-26*pj)*pj)*py2-(2+pj)*py3+4*py4)+pi*(-(-1+pj)*pj2+pj*(4+3*pj*(-5+4*pj))*py+(-1+pj)*(-4+pj*(24+pj))*py2-pj*(4+pj)*py3-4*(1+pj)*py4)+pi3*(-8*pj3+2*pj2*(3-7*py)+2*py*(-1+py2)+pj*(-1+py*(12+py))));
		double phi=(2*(2*P2*pi*(pj+py)*(pi+2*py)*(-1+2*pi*pj+py2)+(pj+2*py)*(P5*pi*(pi+2*py)*(-1+2*pi*pj+py2)+pj*(2*P1*(pi+py)*(-1+2*pi*pj+py2)+(pi+2*py)*(2*(-1+P3)*pi*(-2+pi+pj)+P4*(-1+2*pi*pj+py2))))))/(-2*(-1+pj)*pj*py*(pj+2*py)*(-1+py2)+pi3*(8*pj3+2*py-2*py3+2*pj2*(-3+7*py)-pj*(-1+py*(12+py)))+pi2*(2*pj3*(-3+7*py)+pj2*(6-24*py+26*py2)+pj*(-1+py*(15+(-23+py)*py))+2*py*(-1+py*(2+py-2*py2)))+pi*(4*py2*(-1+py2)-pj3*(-1+py*(12+py))+pj2*(-1+py*(15+(-23+py)*py))+4*pj*py*(-1+py*(7+py+py2))));
		return delta + phi / 2;
	}
	/*Null*//*weighted*/double R_Lynch(GENOTYPE x, GENOTYPE y)
	{
		return (R_LynchSub(x, y) + R_LynchSub(y, x)) / 2;
	}
	
	//Queller & Goodnight (1989) estimator
	/*weighted*/double R_Queller(GENOTYPE x, GENOTYPE y)
	{
		return (R_QuellerSub(x, y) + R_QuellerSub(y, x)) / 2;
	}
	double R_QuellerSub(GENOTYPE x, GENOTYPE y)
	{
		double sumweight = 0, re = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 2 || x.ploidy[i] != 2 || y.ploidy[i] != 2) continue;
			double tr = ((0.5 * ((x.a[i] == y.a[i]) + (x.a[i] == y.b[i]) + (x.b[i] == y.a[i]) + (x.b[i] == y.b[i])) - freobs[i][x.a[i]] - freobs[i][x.b[i]]) / (1 + (x.a[i] == x.b[i]) - freobs[i][x.a[i]] - freobs[i][x.b[i]]));
			if (!IsNaN(tr))
			{
				re += Locus[i].weight * tr;
				sumweight += Locus[i].weight;
			}
		}
		return (1 + FST) / (1 - FST) * re / sumweight - 2 * FST / (1 - FST);
	}
	
	//Li (1993) estimator
	/*weighted*/double R_Li(GENOTYPE x, GENOTYPE y)
	{
		double sumweight = 0, re = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			
			double S0 = 0;
			double a2 = 0, a3 = 0;
			for (int j = 0; j < Locus[i].n; ++j)
			{
				a2 += freobs[i][j] * freobs[i][j];
				a3 += freobs[i][j] * freobs[i][j] * freobs[i][j];
			}
			/*
			if (iscurrent)
			{
				// correcting by sample size
				a2 = (Locus[i].typed * a2 - 1) / (Locus[i].typed - 1);
				a3 = (Locus[i].typed * Locus[i].typed * a3 - 3 * (Locus[i].typed - 1) * a2 - 1) / ((Locus[i].typed - 1) * (Locus[i].typed - 2));
			}
			*/
			S0 = 2 * a2 - a3;
			double Sxy;
			if ((x.a[i] == y.a[i] && x.b[i] == y.b[i]) || (x.a[i] == y.b[i] && x.b[i] == y.a[i])) Sxy = 1;
			else if ((x.a[i] == x.b[i] || y.a[i] == y.b[i]) && (x.a[i] == y.a[i] || x.b[i] == y.b[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i])) Sxy = 0.75;
			else if (x.a[i] == y.a[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i] || x.b[i] == y.b[i]) Sxy = 0.5;
			else Sxy = 0;
			
			//double R = (Sxy - S0) / (1 - S0);
			re +=  Locus[i].weight * (1 - (1 + FST) * (1 - Sxy) / ((1 - FST) * (1 - (2 - FST) * a2 + (1 - FST) * a3)));
			sumweight += Locus[i].weight;
		}
		return re / sumweight;
	}
	
	//Wang (2002) estimator
	/*Null*//*weighted*/double R_Wang(GENOTYPE x, GENOTYPE y)
	{
		double phi = 0, delta = 0;
		//calc U
		double U = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			U += Locus[i].weight / Locus[i].Au;
		}
		double P1 = 0, P2 = 0, P3 = 0;
		double a0 = 0, a02 = 0, a1 = 0, a12 = 0, a13 = 0, a2 = 0, a22 = 0, a3 = 0, a4 = 0;
		double sw = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			double weight = Locus[i].weight / (U * Locus[i].Au);
			if ((x.a[i] == y.a[i] && x.b[i] == y.b[i]) || (x.a[i] == y.b[i] && x.b[i] == y.a[i])) P1 += weight;
			else if ((x.a[i] == x.b[i] || y.a[i] == y.b[i]) && (x.a[i] == y.a[i] || x.b[i] == y.b[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i])) P2 += weight;
			else if (x.a[i] == y.a[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i] || x.b[i] == y.b[i]) P3 += weight;
				
			a0 += weight * Locus[i].A0;
			a02 += weight * Locus[i].A02;
			a1 += weight * Locus[i].A1;
			a12 += weight * Locus[i].A12;
			a13 += weight * Locus[i].A13;
			a2 += weight * Locus[i].A2;
			a22 += weight * Locus[i].A22;
			a3 += weight * Locus[i].A3;
			a4 += weight * Locus[i].A4;
			sw += weight;
		}
		double b, d, f, c, e, g;
		b = (4 * a02 * a2 + 4 * a0 * a3 + 2 * a22 - a4) / (1 - a02) / (1 - a02);
		d = (8 * a0 * (a1 * a2 - a3) + 4 * (a1 * a3 - a4)) / (1 - a02) / (1 - a02);
		f = (8 * (a4 - a1 * a3) + 4 *(a12 * a2 - a22)) / (1 - a02) / (1 - a02);
		c = (a1 * a2 + a02 * a1 + 3 * a0 * a2) / (1 - a02 * (2 - a0)) - b;
		e = (2 * a1 * a2 - 2 * a3 + 2 * a0 * a12 - 2 * a0 * a2) / (1 - a02 * (2 - a0)) - d;
		g = (a13 - 3 * a1 * a2 + 2 * a3) / (1 - a02 * (2 - a0)) - f;
		double V = (1 - b) * (1 - b) * (e * e * f + d * g * g) - (1 - b) * (e * f - d * g) * (e * f - d * g) + 2 * c * d * f * (1 - b) * (g + e) + c * c * d * f * (d + f);
		phi = ( (d * f * ((e + g) * (1 - b) + c * (d + f)) * (P1 - 1) + d * (1 - b) * (g * (1 - b - d) + f * (c + e)) * P3 + f * (1 - b) * (e * (1 - b - f) + d * (c + g)) * P2) / V );
		delta = ( (c * d * f * (e + g) * (P1 + 1 - 2 * b) + ((1 - b) * (f * e * e + d * g * g) - (e * f - d * g) * (e * f - d * g)) * (P1 - b) +  c * (d * g - e * f) * (d * P3 - f * P2) - c * c * d * f * (P3 + P2 - d - f) - c * (1 - b) * (d * g * P3 + e * f * P2)) / V);
		return phi / 2 + delta;
	}

	//Huang Diploid A estimator
	/*Null*//*weighted*/double R_Huang2016DiploidA(GENOTYPE x, GENOTYPE y)
	{
		//A rev, weighting c first
		double phi = 0, delta = 0;
		double c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0;
		double S = 0, S2 = 0;
		//calc U
		double U = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			U += Locus[i].weight / Locus[i].Au;
		}
		if (U == 0) return nan;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			double weight = Locus[i].weight / (U * Locus[i].Au);
			double s;
			if ((x.a[i] == y.a[i] && x.b[i] == y.b[i]) || (x.a[i] == y.b[i] && x.b[i] == y.a[i]))
				s = 1;
			else if ((x.a[i] == x.b[i] || y.a[i] == y.b[i]) && (x.a[i] == y.a[i] || x.b[i] == y.b[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i]))
				s = 0.75;
			else if (x.a[i] == y.a[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i] || x.b[i] == y.b[i])
				s = 0.5;
			else
				s = 0;
			S += weight * s;
			S2 += weight * s * s;
			c1 += weight * Locus[i].C1;
			c2 += weight * Locus[i].C2;
			c3 += weight * Locus[i].C3;
			c4 += weight * Locus[i].C4;
			c5 += weight * Locus[i].C5;
			c6 += weight * Locus[i].C6;
		}
		delta = (c5 * S - c2 * S2 + c2 * c6 - c3 * c5) / (c1 * c5 - c2 * c4);
		phi   = (- c4 * S + c1 * S2 - c1 * c6 + c3 * c4) / (c1 * c5 - c2 * c4);
		return phi / 2 + delta;
	}

	//Huang Diploid B estimator
	/*Null*//*weighted*/double R_Huang2016DiploidB(GENOTYPE x, GENOTYPE y)
	{
		return (R_Huang2016DiploidBSub(x, y) + R_Huang2016DiploidBSub(y, x)) / 2;
	}
	/*weighted*/double R_Huang2016DiploidBSub(GENOTYPE x, GENOTYPE y)
	{
#define DELTA(X) ((c5 * ((X) - c3) - c2 * ((X)*(X) - c6)) / (c1 * c5 - c2 * c4))
#define RELAT(X) (((2 * c5 - c4) * ((X) - c3) - (2 * c2 - c1) * ((X)*(X) - c6)) / (c1 * c5 - c2 * c4) / 2)
		double r = 0, delta = 0;
		double swr = 0, swd = 0, wr, wd, S;
		double c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, c6 = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			if ((x.a[i] == y.a[i] && x.b[i] == y.b[i]) || (x.a[i] == y.b[i] && x.b[i] == y.a[i])) S = 1;
			else if ((x.a[i] == x.b[i] || y.a[i] == y.b[i]) && (x.a[i] == y.a[i] || x.b[i] == y.b[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i])) S = 0.75;
			else if (x.a[i] == y.a[i] || x.a[i] == y.b[i] || x.b[i] == y.a[i] || x.b[i] == y.b[i]) S = 0.5;
			else S = 0;
			
			double pi, pj;
			double X = 0, X2 = 0;
			if (x.a[i] != x.b[i])
			{
				pi = frenull[i][x.a[i]];
				pj = frenull[i][x.b[i]];
				double py = Locus[i].py;
				double px = 1 - pi - pj - py;
				double b = 2 * pi * pj / (1 - py * py);
				double d = (pj * (pj + 2 * py) + pi * (pi + 2 * py)) / (1 - py * py);
				double f = 2 * px * (pi + pj) / (1 - py * py);
				double c = (pi + pj) / 2;
				double e = c + py;
				double g = px;

				c1 = 1 - b - 0.75 * d - 0.5 * f;
				c4 = 1 - b - 0.5625 * d - 0.25 * f;
				c2 = c - b + 0.75 * (e - d) + 0.5 * (g - f);
				c5 = c - b + 0.5625 * (e - d) + 0.25 * (g - f);
				c3 = b + 0.75 * d + 0.5 * f;
				c6 = b + 0.5625 * d + 0.25 * f;
					

				double x1, x2, x3, x4;
				x1 = DELTA(1);
				x2 = DELTA(0.75);
				x3 = DELTA(0.5);
				x4 = DELTA(0);
				X = x1 * b + x2 * d + x3 * f + x4 * (1 - b - d - f);
				X2 = x1 * x1 * b + x2 * x2 * d + x3 * x3 * f + x4 * x4 * (1 - b - d - f);
				wd = Locus[i].weight / (X2 - X*X);
				x1 = RELAT(1);
				x2 = RELAT(0.75);
				x3 = RELAT(0.5);
				x4 = RELAT(0);
				X = x1 * b + x2 * d + x3 * f + x4 * (1 - b - d - f);
				X2 = x1 * x1 * b + x2 * x2 * d + x3 * x3 * f + x4 * x4 * (1 - b - d - f);
				wr = Locus[i].weight / (X2 - X*X);
			}
			else
			{
				pi = frenull[i][x.a[i]];
				double py = Locus[i].py;
				double px = 1 - pi - py;
				double b = pi * (pi + 2 * py) / (1 - py * py);
				double d = 2 * pi * px / (1 - py * py);
				double c = (pi * (pi + py) * ( 2 - py) + 2 * py * (py + 2 * pi)) / (pi + 2 * py) / (2 - py);
				double e = (pi * px * (2 - py) + 2 * px * py) / (pi + 2 * py) / (2 - py);
				c1 = 1 - b - 0.75 * d;
				c4 = 1 - b - 0.5625 * d;
				c2 = c - b + 0.75 * (e - d);
				c5 = c - b + 0.5625 * (e - d);
				c3 = b + 0.75 * d;
				c6 = b + 0.5625 * d;
				double x1, x2, x3;
				x1 = DELTA(1);
				x2 = DELTA(0.75);
				x3 = DELTA(0);
				X = x1 * b + x2 * d + x3 * (1 - b - d);
				X2 = x1 * x1 * b + x2 * x2 * d + x3 * x3 * (1 - b - d);
				wd = Locus[i].weight / (X2 - X*X);
				x1 = RELAT(1);
				x2 = RELAT(0.75);
				x3 = RELAT(0);
				X = x1 * b + x2 * d + x3 * (1 - b - d);
				X2 = x1 * x1 * b + x2 * x2 * d + x3 * x3 * (1 - b - d);
				wr = Locus[i].weight / (X2 - X*X);
			}

			double tr = wr * RELAT(S);
			if (!IsNaN(tr) && fabs(X) < 1e-10)
			{
				delta += wd * DELTA(S);
				r += tr;
				swr += wr;
				swd += wd;
			}

		}
		delta /= swd;
		r /= swr;
		return r;
	}
	
	//Thomas (2010) estimator
	/*Null*//*weighted*/double R_Thomas(GENOTYPE x, GENOTYPE y, bool iswang)
	{
		double D = 0;
		double r = 0;
		//calc U
		double U = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			U += 1.0 / Locus[i].Au;
		}
		double P[3] = {0};
		int t1, t2;
		double weight = 0, w4 = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1) continue;
			t1 = (x.a[i] == y.a[i]) + (x.b[i] == y.b[i]);
			t2 = (x.a[i] == y.b[i]) + (x.b[i] == y.a[i]);
			P[0] = P[1] = P[2] = 0;
			P[t1 >= t2 ? 2 - t1 : 2 - t2] = 1;
			double b, c, d, e;
			b = (2 * Locus[i].A22 - Locus[i].A4 + 4 * Locus[i].A02 * Locus[i].A2 + 4 * Locus[i].A0 * Locus[i].A3) / (1 - Locus[i].A02) / (1 - Locus[i].A02);
			d = (8 * Locus[i].A0 * (Locus[i].A1 * Locus[i].A2 - Locus[i].A3) + 4 * (Locus[i].A12 * Locus[i].A2 - Locus[i].A1 * Locus[i].A3 - Locus[i].A22 + Locus[i].A4)) / (1 - Locus[i].A02) / (1 - Locus[i].A02);
			c = (Locus[i].A1 * Locus[i].A2 + Locus[i].A02 * Locus[i].A1 + 3 * Locus[i].A0 * Locus[i].A2) / (1 - Locus[i].A02 * (2 - Locus[i].A0)) - b;
			e = (2 * Locus[i].A0 * (Locus[i].A12 - Locus[i].A2) - Locus[i].A1 * Locus[i].A2 + Locus[i].A13) / (1 - Locus[i].A02 * (2 - Locus[i].A0)) - d;
			double div = c * d + (1 - b) * e;
			double vr, v4;
			if (iswang)
			{
				//inverse of similarity index
				v4 = Locus[i].Au;
				vr = Locus[i].Au;
			}
			else
			{
				//inverse of variance
				v4 = (d * c * c + b * e * e - (c * d - e * b) * (c * d - e * b)) / (div * div);
				vr = (4 * b * e * e - 4 * (c * d - b * e) * (c * d - b * e) - 4 * c * d * e + d * (1 - b) * (1 - b) - d * d * (1 - b)) / (4 * div * div);
			}
			w4 += Locus[i].weight / v4;
			weight += Locus[i].weight / vr;
			r += Locus[i].weight * ((P[0] - b) * (d * 0.5 + e) + (P[1] - d) * (0.5 - 0.5 * b - c)) / vr / div;
			D += Locus[i].weight * (e * (P[0] - b) - c * (P[1] - d)) / v4 / div;
		}
		D /= w4;
		return r / weight;
	}
	double R_Thomas_Original(GENOTYPE x, GENOTYPE y)
	{
		return R_Thomas(x, y, false);
	}
	double R_Thomas_Wang(GENOTYPE x, GENOTYPE y)
	{
		return R_Thomas(x, y, true);
	}
	
	//Diploid Maximum-likelihood estimators: Anderson & Weir (2007) and Milligan (2003)
	bool GetIBS(GENOTYPE &x, GENOTYPE &y)
	{ 
		int s = 0;
		for (int i = 0; i < L; ++i)
		{
			if (x.ploidy[i] != 2 || y.ploidy[i] != 2 || x.a[i] < 0 || x.b[i] < 0 || y.a[i] < 0 || y.b[i] < 0 || Locus[i].n <= 1)
			{
				IBS2[i] = -1;
				continue;
			}
			s++;
			//calc IBS2
			if (x.a[i] == x.b[i])
			{
				if (y.a[i] == y.b[i])
				{
					if (y.a[i] == x.a[i])
					{
						IBS2[i] = 1;
						pp[i][0] = x.a[i];
					}
					else 
					{
						IBS2[i] = 2;
						pp[i][0] = x.a[i];
						pp[i][1] = y.a[i];
					}
				}
				else
				{
					if (y.a[i] == x.a[i])
					{
						IBS2[i] = 3;
						pp[i][0] = x.a[i];
						pp[i][1] = y.b[i];
					}
					else if (y.b[i] == x.a[i])
					{
						IBS2[i] = 3;
						pp[i][0] = x.a[i];
						pp[i][1] = y.a[i];
					}
					else 
					{
						IBS2[i] = 4;
						pp[i][0] = x.a[i];
						pp[i][1] = y.a[i];
						pp[i][2] = y.b[i];
					}
				}
			}
			else if (y.a[i] == y.b[i])
			{
				if (y.a[i] == x.a[i])
				{
					IBS2[i] = 5;
					pp[i][0] = y.a[i];
					pp[i][1] = x.b[i];
				}
				else if (y.a[i] == x.b[i])
				{
					IBS2[i] = 5;
					pp[i][0] = y.a[i];
					pp[i][1] = x.a[i];
				}
				else 
				{
					IBS2[i] = 6;
					pp[i][0] = y.a[i];
					pp[i][1] = x.a[i];
					pp[i][2] = x.b[i];
				}
			}
			else
			{
				if ( (x.a[i] == y.a[i] && x.b[i] == y.b[i]) || (x.a[i] == y.b[i] && x.b[i] == y.a[i]) )
				{
					IBS2[i] = 7;
					pp[i][0] = x.a[i];
					pp[i][1] = x.b[i];
				}
				else if (x.a[i] == y.a[i])
				{
					IBS2[i] = 8;
					pp[i][0] = x.a[i];
					pp[i][1] = x.b[i];
					pp[i][2] = y.b[i];
				}
				else if (x.b[i] == y.b[i])
				{
					IBS2[i] = 8;
					pp[i][0] = x.b[i];
					pp[i][1] = x.a[i];
					pp[i][2] = y.a[i];
				}
				else if (x.a[i] == y.b[i])
				{
					IBS2[i] = 8;
					pp[i][0] = x.a[i];
					pp[i][1] = x.b[i];
					pp[i][2] = y.a[i];
				}
				else if (x.b[i] == y.a[i])
				{
					IBS2[i] = 8;
					pp[i][0] = x.b[i];
					pp[i][1] = x.a[i];
					pp[i][2] = y.b[i];
				}
				else
				{
					IBS2[i] = 9;
					pp[i][0] = x.a[i];
					pp[i][1] = x.b[i];
					pp[i][2] = y.a[i];
					pp[i][3] = y.b[i];
				}
			}
		}
		return s > 0;
	}
	double R_Anderson2D(GENOTYPE x, GENOTYPE y)
	{
		return R_Anderson(x, y, 2, true);
	}
	double R_Milligan2D(GENOTYPE x, GENOTYPE y)
	{
		return R_Anderson(x, y, 2, false);
	}
	double R_Milligan8D(GENOTYPE x, GENOTYPE y)
	{
		return R_Anderson(x, y, 8, false);
	}
	void R_AndersonInitialize()
	{
		if (!R_Anderson_Initialized)
		{
			pp = new int[L][4];
			IBS2 = new int[L];
			R_Anderson_Initialized = true;
			L_Anderson_Coef = new double*[L];
			for (int i = 0; i < L; ++i)
				L_Anderson_Coef[i] = new double[15];
		}
	}
	void R_AndersonUninitialize()
	{
		if (R_Anderson_Initialized)
		{
			delete[] pp;
			delete[] IBS2;
			R_Anderson_Initialized = false;
			for (int i = 0; i < L; ++i)
				delete[] L_Anderson_Coef[i];
			delete[] L_Anderson_Coef;
		}
	}
	/*weighted*/double R_Anderson(GENOTYPE x, GENOTYPE y, int dem, bool confine)
	{
		if (!R_Anderson_Initialized)
			R_AndersonInitialize();
		if (!GetIBS(x, y))
			return nan;
		L_Anderson_Coef_Calced = false;
		point8 xx[9];
		for (int i = 0; i <= dem; ++i) 
		{
			xx[i].confine = confine;
			xx[i].dem = dem;
			if (i) xx[i].image[i - 1] = 0.1; 
			L_AndersonS9(xx[i]);
		}
		double sep = 0.1;
		double likestop = LIKESTOP1;
		for (int kk = 0; kk < 10; ++kk)
		{
			//Order
			order(xx);
			int searchcount;

			searchcount = 0;
			//downhill simplex method
			while (!isbreak(xx, LIKESTOP1) && searchcount < MAX_ITER_ML)
			{
				searchcount++;
				//Reflect
				point8 x0 = xx[0];
				for (int i = 1; i < dem; ++i)
					x0 += xx[i];
				x0 /= dem;
				point8 xr = x0 + (x0 - xx[dem]);
				L_AndersonS9(xr);
			
				//Expansion
				//best
				if (xr > xx[0])
				{
					point8 xe = x0 + (x0 - xx[dem]) * 2;
					L_AndersonS9(xe);
					memmove(xx + 1, xx, sizeof(point8) * dem);
					xx[0] = xe > xr ? xe : xr;
					continue;
				}
				//better than second worst
				if (xr > xx[dem - 1])
				{
					xx[dem] = xr;
					order(xx);
					continue;
				}
				//worse than second worst
				//Contraction
				point8 xc = xx[dem] + (x0 - xx[dem]) * 0.5;
				L_AndersonS9(xc);
				if (xc > xx[dem])
				{
					xx[dem] = xc;
					order(xx);
					continue;
				}
			
				//Reduction
				for (int i = 1; i <= dem; ++i)
				{
					xx[i] = (xx[0] + xx[i]) / 2;
					L_AndersonS9(xx[i]);
				}
				order(xx);
				continue;
			}
		
			//step 2
			for (int i = 1; i <= dem; ++i) 
			{
				xx[i] = xx[0];
				xx[i].image[i - 1] *= (1 - sep);
				L_AndersonS9(xx[i]);
			}
			//Order
			sep /= 2;
			likestop /= 2;
		}
		order(xx);
		xx[0].i2r();

		double re;
		switch (dem)
		{
		case 1: re = confine ? xx[0].real[0] : 0.5 * xx[0].real[0]; break; 
		case 2: re = xx[0].real[0] + xx[0].real[1] / 2; break; 
		case 3: re = xx[0].real[0] + 0.5 * xx[0].real[1]; break; 
		case 8: re = 2 * xx[0].real[0] + xx[0].real[2] + xx[0].real[4] + xx[0].real[6] + xx[0].real[7] / 2; break; 
		default: re = nan; break; 
		}
		return re;
		/*
		point8 xx2 = R_Andersonold(x, y, dem, confine);
		if (xx2.li > xx[0].li)
		{
			double diffr = fabs(re - xx[0].image[0]);
			if (diffr > 0.00001)
				diffr = diffr;
		}
		return re;
		*/
	}
	
	/*Null*//*weighted*/double L_AndersonS9(point8 &xx)
	{
#define M(m,n) (a1 * frenull[i][pp[i][m]] + (n) * FST)
		double re = 0;
		xx.i2r();
		double *S = &xx.real[0];
		if (!L_Anderson_Coef_Calced)
		{
			L_Anderson_Coef_Calced = true;
			if (xx.dem == 8) for (int i = 0; i < L; ++i)
			{
				if (IBS2[i] == -1)
					continue;
				double py = 0, pi = 0, pj = 0, pk = 0, pl = 0;
				py = Locus[i].py;
				if (pp[i][0] >= 0 && pp[i][0] < Locus[i].n)
					pi = frenull[i][pp[i][0]];
				if (pp[i][1] >= 0 && pp[i][1] < Locus[i].n)
					pj = frenull[i][pp[i][1]];
				if (pp[i][2] >= 0 && pp[i][2] < Locus[i].n)
					pk = frenull[i][pp[i][2]];
				if (pp[i][3] >= 0 && pp[i][3] < Locus[i].n)
					pl = frenull[i][pp[i][3]];
				L_Anderson_Coef[i][9] = (1 - py);
				L_Anderson_Coef[i][10] = L_Anderson_Coef[i][9] * L_Anderson_Coef[i][9];
				L_Anderson_Coef[i][11] = (1 - py) * (1 - py * py);
				L_Anderson_Coef[i][12] = (1 - py * py);
				L_Anderson_Coef[i][13] = (1 - 2 * py * py + py * py * py);
				L_Anderson_Coef[i][14] = (1 - py * py) * (1 - py * py);
				double y4 = pi + py;
				double y5 = pi + 2 * py;
				double y6 = pj + 2 * py;
				switch (IBS2[i])
				{
					case 1: 
						L_Anderson_Coef[i][0] = pi;
						L_Anderson_Coef[i][1] = pi * pi;
						L_Anderson_Coef[i][2] = pi * y4;
						L_Anderson_Coef[i][3] = pi * pi * y4 * y5;
						L_Anderson_Coef[i][4] = pi * y4;
						L_Anderson_Coef[i][5] = pi * pi * y5;
						L_Anderson_Coef[i][6] = pi * y5;
						L_Anderson_Coef[i][7] = pi * (pi * pi + 3 * pi * py + py * py);
						L_Anderson_Coef[i][8] = y5 * y5 * pi * pi;
						break;
					case 2: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = pi * pj;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = y6 * pi * pj;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = y5 * pi * pj;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = pi * pj * py;
						L_Anderson_Coef[i][8] = y5 * y6 * pi * pj;
						break;
					case 3: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = pi * pj;
						L_Anderson_Coef[i][3] = 2 * pi * pi * pj;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 0;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = y4 * pi * pj;
						L_Anderson_Coef[i][8] = 2 * y5 * pi * pi * pj;
						break;
					case 4: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 2 * pi * pj * pk;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 0;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = 0;
						L_Anderson_Coef[i][8] = 2 * y5 * pi * pj * pk;
						break;
					case 5: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 0;
						L_Anderson_Coef[i][4] = pi * pj;
						L_Anderson_Coef[i][5] = 2 * pi * pi * pj;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = y4 * pi * pj;
						L_Anderson_Coef[i][8] = 2 * y5 * pi * pi * pj;
						break;
					case 6: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 0;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 2 * pi * pj * pk;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = 0;
						L_Anderson_Coef[i][8] = 2 * y5 * pi * pj * pk;
						break;
					case 7: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 0;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 0;
						L_Anderson_Coef[i][6] = 2 * pi * pj;
						L_Anderson_Coef[i][7] = pi * pj * (pi + pj);
						L_Anderson_Coef[i][8] = 4 * pi * pi * pj * pj;
						break;
					case 8: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 0;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 0;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = pi * pj * pk;
						L_Anderson_Coef[i][8] = 4 * pi * pi * pj * pk;
						break;
					case 9: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 0;
						L_Anderson_Coef[i][3] = 0;
						L_Anderson_Coef[i][4] = 0;
						L_Anderson_Coef[i][5] = 0;
						L_Anderson_Coef[i][6] = 0;
						L_Anderson_Coef[i][7] = 0;
						L_Anderson_Coef[i][8] = 4 * pi * pj * pk * pl;
						break;
					default: break;
				}
			}
			else for (int i = 0; i < L; ++i)
			{
				if (IBS2[i] == -1)
					continue;
				double py = 0, pi = 0, pj = 0, pk = 0, pl = 0;
				py = Locus[i].py;
				if (pp[i][0] >= 0 && pp[i][0] < Locus[i].n)
					pi = frenull[i][pp[i][0]];
				if (pp[i][1] >= 0 && pp[i][1] < Locus[i].n)
					pj = frenull[i][pp[i][1]];
				if (pp[i][2] >= 0 && pp[i][2] < Locus[i].n)
					pk = frenull[i][pp[i][2]];
				if (pp[i][3] >= 0 && pp[i][3] < Locus[i].n)
					pl = frenull[i][pp[i][3]];
				double y4 = pi + py;
				double y5 = pi + 2 * py;
				double y6 = pj + 2 * py;
				L_Anderson_Coef[i][3] = (1 - py * py);
				L_Anderson_Coef[i][4] = (1 - 2 * py * py + py * py * py);
				L_Anderson_Coef[i][5] = (1 - py * py) * (1 - py * py);
				switch (IBS2[i])
				{
					case 1: 
						L_Anderson_Coef[i][0] = pi * y5;
						L_Anderson_Coef[i][1] = pi * (pi * pi + 3 * pi * py + py * py);
						L_Anderson_Coef[i][2] = y5 * y5 * pi * pi;
						break;
					case 2: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = pi * pj * py ;
						L_Anderson_Coef[i][2] = y5 * y6 * pi * pj;
						break;
					case 3: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = y4 * pi * pj;
						L_Anderson_Coef[i][2] = 2 * y5 * pi * pi * pj;
						break;
					case 4:
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 2 * y5 * pi * pj * pk;
						break;
					case 5: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = y4 * pi * pj;
						L_Anderson_Coef[i][2] = 2 * y5 * pi * pi * pj;
						break;
					case 6: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 2 * y5 * pi * pj * pk;
						break;
					case 7: 
						L_Anderson_Coef[i][0] = 2 * pi * pj;
						L_Anderson_Coef[i][1] = pi * pj * (pi + pj);
						L_Anderson_Coef[i][2] = 4 * pi * pi * pj * pj;
						break;
					case 8: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = pi * pj * pk;
						L_Anderson_Coef[i][2] = 4 * pi * pi * pj * pk;
						break;
					case 9: 
						L_Anderson_Coef[i][0] = 0;
						L_Anderson_Coef[i][1] = 0;
						L_Anderson_Coef[i][2] = 4 * pi * pj * pk * pl;
					default: break;
				}
            }
		}
		if (xx.dem == 8) for (int i = 0; i < L; ++i)
		{
			if (IBS2[i] == -1)
				continue;
			double L = 0;
			for (int j = 0; j <= xx.dem; ++j)
				L += L_Anderson_Coef[i][j] * S[j];
			L /= (S[0] + S[2] + S[4]) * L_Anderson_Coef[i][9] + S[1] * L_Anderson_Coef[i][10] + (S[3] + S[5]) * L_Anderson_Coef[i][11] + S[6] * L_Anderson_Coef[i][12] + S[7] * L_Anderson_Coef[i][13] + S[8] * L_Anderson_Coef[i][14];
			re += Locus[i].weight * mylog10(L);
		}
		else for (int i = 0; i < L; ++i)
		{
			if (IBS2[i] == -1)
				continue;
			double L = 0;
			for (int j = 0; j <= xx.dem; ++j)
				L += L_Anderson_Coef[i][j] * S[j];
			L /= S[0] * L_Anderson_Coef[i][3] + S[1] * L_Anderson_Coef[i][4] + S[2] * L_Anderson_Coef[i][5];
			re += Locus[i].weight * mylog10(L);
		}
		xx.li = re < MINLIKELIHOOD ? MINLIKELIHOOD : re;
		return xx.li;
	}

	//function controls
	void calc()
	{
		//Relatdness between Individual 
		r4 = new double[N * N];
		N_t = N * (N - 1) / 2 + N;
		N_o = 0;
		N_c = 0;
		char* od[16] = {"\t%0.0lf","\t%0.1lf","\t%0.2lf","\t%0.3lf","\t%0.4lf","\t%0.5lf","\t%0.6lf","\t%0.7lf","\t%0.8lf","\t%0.9lf","\t%0.10lf","\t%0.11lf","\t%0.12lf","\t%0.13lf","\t%0.14lf","\t%0.15lf"};
		printf("Progress: \r\n");
		
		HANDLE* hThread = new HANDLE[nthread];
		ThreadPar* par = new ThreadPar[nthread];
		for (int i = 0; i < nthread; ++i)
		{
			ThreadPar tpar = {this, i, nthread, 0, 0};
			memmove(par + i, &tpar, sizeof(ThreadPar));
#ifdef WIN64
			unsigned int threadID;
			hThread[i] = (HANDLE)_beginthreadex(NULL, 0, &ThreadFunc, par + i, 0, &threadID);
#else
			pthread_t threadID;
			pthread_attr_init(hThread + i);
			pthread_create(&threadID, hThread + i, &ThreadFunc, (void*)(par + i)); 
#endif
		}
		
		while (N_c != N_t && thread_count != N_t)
		{
			while (N_c * 80 / N_t > N_o)
			{
				N_o++;
				cout << "|";
				fflush(stdout);
			}
			SLEEP(SLEEP_TIME);
		}
		
		while (N_o < 80)
		{
			N_o++;
			cout << "|";
			fflush(stdout);
		}
		/*
		 for (int i = 0; i < nthread; ++i)
		 {
		 #ifdef WIN64
		 TerminateThread(hThread[i], NULL);
		 #else
		 pthread_attr_destroy(hThread + i);
		 #endif
		 }
		 */
		printf("\r\n");
		FILE *f1 = fopen(output, "wb");
		if (!f1)  EXIT("Error: Can not open output file.\r\n");
		fprintf(f1, "Relatedness coefficient calculated by PolyRelatedness V%s\r\n", VERSION);
		fprintf(f1, "    Estimator: %s\r\n", estimator_name[method]);
		fprintf(f1, "    Type: between all individuals\r\n");
		fprintf(f1, "    Input: %s\r\n", input);
		fprintf(f1, "    Output: %s\r\n", output);
		struct tm *t1;
		time_t tt1;
		time(&tt1);
		t1 = localtime(&tt1);
		fprintf(f1, "    Time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", t1->tm_year+1900, t1->tm_mon+1, t1->tm_mday, t1->tm_hour, t1->tm_min, t1->tm_sec); 
		
		for (int i = 0; i < N; ++i)
			fprintf(f1, "\t%s", inds[i].name);
		for (int i = 0; i < N; ++i)
		{
			fprintf(f1, "\r\n%s", inds[i].name);
			for (int j = 0; j < N; ++j)
				fprintf(f1, od[outputdigits], r4[N * i + j]);
		}
		fclose(f1);
		delete[] r4;
		delete[] hThread;
		delete[] par;
	}
	bool calcind()
	{
		//Individual inbreeding coefficient
		r4 = new double[N * 3 * (L + 1)];
		N_t = N;
		N_o = 0;
		N_c = 0;
		char* od[16] = {"\t%0.0lf","\t%0.1lf","\t%0.2lf","\t%0.3lf","\t%0.4lf","\t%0.5lf","\t%0.6lf","\t%0.7lf","\t%0.8lf","\t%0.9lf","\t%0.10lf","\t%0.11lf","\t%0.12lf","\t%0.13lf","\t%0.14lf","\t%0.15lf"};
		printf("Progress: \r\n");
		
		HANDLE* hThread = new HANDLE[nthread];
		ThreadPar* par = new ThreadPar[nthread];
		for (int i = 0; i < nthread; ++i)
		{
			ThreadPar tpar = {this, i, nthread, 3, 0};
			memmove(par + i, &tpar, sizeof(ThreadPar));
#ifdef WIN64
			unsigned int threadID;
			hThread[i] = (HANDLE)_beginthreadex(NULL, 0, &ThreadFunc, par + i, 0, &threadID);
#else
			pthread_t threadID;
			pthread_attr_init(hThread + i);
			pthread_create(&threadID, hThread + i, &ThreadFunc, (void*)(par + i)); 
#endif
		}
		
		while (N_c != N_t && thread_count != N_t)
		{
			while (N_c * 80 / N_t > N_o)
			{
				N_o++;
				cout << "|";
				fflush(stdout);
			}
			SLEEP(SLEEP_TIME);
		}
		
		while (N_o < 80)
		{
			N_o++;
			cout << "|";
			fflush(stdout);
		}
		/*
		 for (int i = 0; i < nthread; ++i)
		 {
		 #ifdef WIN64
		 TerminateThread(hThread[i], NULL);
		 #else
		 pthread_attr_destroy(hThread + i);
		 #endif
		 }
		 */
		printf("\r\n");
		FILE *f1 = fopen(output, "wb");
		if (!f1)  EXIT("Error: Can not open output file.\r\n");
		fprintf(f1, "Individual inbreeding coefficient calculated by PolyRelatedness V%s\r\n", VERSION);
		fprintf(f1, "    Input: %s\r\n", input);
		fprintf(f1, "    Output: %s\r\n", output);
		struct tm *t1;
		time_t tt1;
		time(&tt1);
		t1 = localtime(&tt1);
		fprintf(f1, "    Time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", t1->tm_year+1900, t1->tm_mon+1, t1->tm_mday, t1->tm_hour, t1->tm_min, t1->tm_sec); 
		{
			fprintf(f1, "\tInd");

			fprintf(f1, "\t%s", estimator_name[4]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, "\t%s", Locus[j].name);

			fprintf(f1, "\t%s", estimator_name[5]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, "\t%s", Locus[j].name);

			fprintf(f1, "\t%s", estimator_name[6]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, "\t%s", Locus[j].name);

			fprintf(f1, "\r\n");
		}

		int line = 3 * (L + 1);
		double* sum = new double[line];
		double* sum2 = new double[line];
		int* sumn = new int[line];
		memset(sum, 0, sizeof(double) * line);
		memset(sum2, 0, sizeof(double) * line);
		memset(sumn, 0, sizeof(int) * line);
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j < line; ++j)
			{
				if (!IsNaN(r4[i * line + j]))
				{
					sum[j] += r4[i * line + j];
					sum2[j] += r4[i * line + j] * r4[i * line + j];
					sumn[j]++;
				}
			}
		}
		
		for (int j = 0; j < line; ++j)
		{
			sum[j] /= sumn[j];
			sum2[j] /= sumn[j];
			sum2[j] -= sum[j] * sum[j];
		}
		
		fprintf(f1, "\tMean");
		for (int j = 0; j < line; ++j)
			fprintf(f1, od[outputdigits], sum[j]);
		fprintf(f1, "\r\n");

		fprintf(f1, "\tVariance");
		for (int j = 0; j < line; ++j)
			fprintf(f1, od[outputdigits], sum2[j]);
		fprintf(f1, "\r\n");

		for (int i = 0; i < N; ++i)
		{
			fprintf(f1, "\t%s", inds[i].name);

			fprintf(f1, od[outputdigits], r4[i * line]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, od[outputdigits], r4[i * line + j + 1]);

			fprintf(f1, od[outputdigits], r4[i * line + (L + 1)]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, od[outputdigits], r4[i * line + (L + 1) + j + 1]);

			fprintf(f1, od[outputdigits], r4[i * line + (L + 1) + (L + 1)]);
			for (int j = 0; j < L; ++j)
				fprintf(f1, od[outputdigits], r4[i * line + (L + 1) + (L + 1) + j + 1]);

			fprintf(f1, "\r\n");
		}
		fclose(f1);
		delete[] r4;
		delete[] hThread;
		delete[] par;
		return true;
	}
	void calcpop()
	{
		//Relatdness between Individual in same pops
		N_t = 0;
		N_o = 0;
		N_c = 0;
		char* od[16] = {"\t%0.0lf","\t%0.1lf","\t%0.2lf","\t%0.3lf","\t%0.4lf","\t%0.5lf","\t%0.6lf","\t%0.7lf","\t%0.8lf","\t%0.9lf","\t%0.10lf","\t%0.11lf","\t%0.12lf","\t%0.13lf","\t%0.14lf","\t%0.15lf"};
		
		for (int i = 0; i < (int)pops.size(); ++i)
		{
			int nn = (int)pops[i].inds.size();
			N_t += nn * (nn - 1) / 2 + nn;
		}
		printf("Progress: \r\n");
		
		
		FILE *f1 = fopen(output, "wb");
		if (!f1)  EXIT("Error: Can not open output file.\r\n");
		fprintf(f1, "Relatedness coefficient calculated by PolyRelatedness V%s\r\n", VERSION);
		fprintf(f1, "    Estimator: %s\r\n", estimator_name[method]);
		fprintf(f1, "    Type: within populations\r\n");
		fprintf(f1, "    Input: %s\r\n", input);
		fprintf(f1, "    Output: %s\r\n", output);
		struct tm *t1;
		time_t tt1;
		time(&tt1);
		t1 = localtime(&tt1);
		fprintf(f1, "    Time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", t1->tm_year+1900, t1->tm_mon+1, t1->tm_mday, t1->tm_hour, t1->tm_min, t1->tm_sec); 
		
		int t2 = 0;
		for (int k = 0; k < (int)pops.size(); ++k)
		{
			int n = (int)pops[k].inds.size();
			t2 += n * (n - 1) / 2 + n;
			r4 = new double[n * n];
			HANDLE* hThread = new HANDLE[nthread];
			ThreadPar* par = new ThreadPar[nthread];
			for (int i = 0; i < nthread; ++i)
			{
				ThreadPar tpar = {this, i, nthread, 1, k};
				memmove(par + i, &tpar, sizeof(ThreadPar));
#ifdef WIN64
				unsigned int threadID;
				hThread[i] = (HANDLE)_beginthreadex(NULL, 0, &ThreadFunc, par + i, 0, &threadID);
#else
				pthread_t threadID;
				pthread_attr_init(hThread + i);
				pthread_create(&threadID, hThread + i, &ThreadFunc, (void*)(par + i)); 
#endif
			}
			while (N_c != t2 && thread_count != t2)
			{
				while (N_c * 80 / N_t > N_o)
				{
					N_o++;
					cout << "|";
					fflush(stdout);
				}	
				SLEEP(SLEEP_TIME);
			}
			
			/*
			 for (int i = 0; i < nthread; ++i)
			 {
			 #ifdef WIN64
			 TerminateThread(hThread[i], NULL);
			 #else
			 pthread_attr_destroy(hThread + i);
			 #endif
			 }
			 */
			fprintf(f1, "\r\n\r\nPop: %s\r\n", pops[k].name);
			for (int i = 0; i < n; ++i)
				fprintf(f1, "\t%s", pops[k].inds[i].name);
			for (int i = 0; i < n; ++i)
			{
				fprintf(f1, "\r\n%s", pops[k].inds[i].name);
				for (int j = 0; j < n; ++j)
					fprintf(f1, od[outputdigits], r4[n * i + j]);
			}
			delete[] r4;
			delete[] hThread;
			delete[] par;
		}
		while (N_o < 80)
		{
			N_o++;
			cout << "|";
			fflush(stdout);
		}
		printf("\r\n");
		fclose(f1);
	}
	void CheckProcessBar()
	{
		N_c++;
		while (N_c * 80 / N_t > N_o)
		{
			N_o++;
			cout << "|";
			fflush(stdout);
		}
	}

	//Null allele frequency estimators
	double *N_Summer1997()
	{
		double* pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			int *n = new int[Locus[l].n];
			int *nn = new int[Locus[l].n];
			memset(n, 0, Locus[l].n * sizeof(int));
			memset(nn, 0, Locus[l].n * sizeof(int));
			double *p = new double[Locus[l].n];
			double p0 = 0;
			double N = (double)inds.size();
			double N1 = N;
			int nhetero = 0;
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				if (inds[i].genotype.a[l] == inds[i].genotype.b[l])
				{
					n[inds[i].genotype.b[l]]++;
					nn[inds[i].genotype.b[l]]++;
				}
				else
				{
					n[inds[i].genotype.a[l]]++;
					n[inds[i].genotype.b[l]]++;
					nhetero += (inds[i].genotype.a[l] != inds[i].genotype.b[l]);
				}
			}
			for (int j = 0; j < 100; ++j)
			{
				double n1 = 0;
				for (int i = 0; i < Locus[l].n; ++i)
				{
					p[i] = 1 - sqrt(1 - n[i] / (double)N);
					n1 += nn[i] - N * p[i] * p[i];//nix
				}
				double n2 = N - n1;
				p0 = n1 / (double)(2 * n2 + n1);
				N = N1 / (1 - p0 * p0);
			}
			delete[] n;
			delete[] p;
			pn[l] = p0;
			CheckProcessBar();
		}
		return pn;
	}
	double *N_Chakraborty1992(bool processbar = true)
	{
		double* pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			double he = 1, ho = 0;
			int ntot = 0, nhetero = 0;
			int *n = new int[Locus[l].n];
			memset(n, 0, Locus[l].n * sizeof(int));
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				ntot++;
				nhetero += (inds[i].genotype.a[l] != inds[i].genotype.b[l]);
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
			}
			ho = nhetero / (double)ntot;

			for (int i = 0; i < Locus[l].n; ++i)
				he -= n[i] * n[i] / (2.0 * ntot) / (2.0 * ntot);
			pn[l] = (he - ho) / (he + ho);
			delete[] n;
			if (processbar) CheckProcessBar();
		}
		return pn;
	}
	double *N_Brookfield19962()
	{
		double* pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			double he = 1, ho = 0;
			int ntot = 0, nhetero = 0;
			int *n = new int[Locus[l].n];
			memset(n, 0, Locus[l].n * sizeof(int));
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				ntot++;
				nhetero += (inds[i].genotype.a[l] != inds[i].genotype.b[l]);
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
			}
			ho = nhetero / (double)ntot;

			for (int i = 0; i < Locus[l].n; ++i)
				he -= n[i] * n[i] / (2.0 * ntot) / (2.0 * ntot);

			double N = (inds.size() - ntot) / (double)inds.size();
			double A = he * (1 + N) - ho;
			double B = 4 * N * (1 - he * he);
			pn[l] = A + sqrt((A * A + B) / (2 * (1 + he)));
			delete[] n;
			CheckProcessBar();
		}
		return pn;
	}
	double *N_Brookfield19961()
	{
		double* pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			double he = 1, ho = 0;
			int ntot = 0, nhetero = 0;
			int *n = new int[Locus[l].n];
			memset(n, 0, Locus[l].n * sizeof(int));
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				ntot++;
				nhetero += (inds[i].genotype.a[l] != inds[i].genotype.b[l]);
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
			}
			ho = nhetero / (double)ntot;

			for (int i = 0; i < Locus[l].n; ++i)
				he -= n[i] * n[i] / (2.0 * ntot) / (2.0 * ntot);

			pn[l] = (he - ho) / (he + 1);
			delete[] n;
			CheckProcessBar();
		}
		return pn;
	}
	double *N_Oosterhout2004()
	{
		double* pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			int ntot = 0;
			int *n = new int[Locus[l].n];
			memset(n, 0, Locus[l].n * sizeof(int));
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				ntot++;
				if (inds[i].genotype.a[l] == inds[i].genotype.b[l])
				{
					n[inds[i].genotype.a[l]]++;
				}
				else
				{
					n[inds[i].genotype.a[l]]++;
					n[inds[i].genotype.b[l]]++;
				}
			}
			pn[l] = 1;
			for (int i = 0; i < Locus[l].n; ++i)
				pn[l] -= 1 - sqrt(1 - n[i] / (double) inds.size());
			delete[] n;
			CheckProcessBar();
		}
		return pn;
	}
	double *N_Oosterhout2006(double& f)
	{
		double* fis = new double[L];
		double **n2 = new double*[L];
		int ninds = (int)inds.size();
		N_t = L * 2 * (int)pops.size() + (int)pops.size() * L;
		N_o = 100;
		f = 0;
		int fiscount = 0;
		for (int l = 0; l < L; ++l)
		{
			double he = 1, ho = 0;
			int ntot = 0, nhetero = 0;
			n2[l] = new double[Locus[l].n];
			double *p = new double[Locus[l].n];
			memset(p, 0, Locus[l].n * sizeof(double));
			memset(n2[l], 0, Locus[l].n * sizeof(double));
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] == MISSING_ALLELE || inds[i].genotype.b[l] == MISSING_ALLELE 
					|| inds[i].genotype.a[l] == AMBIGUOUS_ALLELE || inds[i].genotype.b[l] == AMBIGUOUS_ALLELE)
					continue;
				ntot++;
				if (inds[i].genotype.a[l] != inds[i].genotype.b[l])
					nhetero++;
				else
					n2[l][inds[i].genotype.b[l]] += 1;
				p[inds[i].genotype.a[l]]++;
				p[inds[i].genotype.b[l]]++;
			}
			ho = nhetero / (double)ntot;

			for (int i = 0; i < Locus[l].n; ++i)
			{
				p[i] /= 2 * ntot;
				n2[l][i] /= ninds;
				he -= p[i] * p[i];
			}
			if (ho == 1 || ntot == 0)
				fis[l] = nan;
			else
			{
				fis[l] = 1 - ho / he;
				fiscount++;
				f += fis[l];
			}
			delete[] p;
			CheckProcessBar();
		}

		f /= fiscount;
		if (f < 0) f = 0;
		else if (f > 1) f = 1;
		double *pn = new double[L];
		for (int l = 0; l < L; ++l)
		{
			if (IsNaN(fis[l]))
			{
				pn[l] = 0;
				continue;
			}
			double rnew = 1;
			double r = 0.9;

			//step 0, r = 0, rnew decrease, divergent
			double rbottom = 0;

			//step 1, find a value make r increase, convergent
			double rtop = 1;
			for (;;)
			{
				r = rtop;
				rnew = 1;
				double t = 2 * f * r - f - 2 * r;
				for (int i = 0; i < Locus[l].n; ++i)
					rnew -= (t + sqrt(t * t + 4 * n2[l][i] * (1 - f))) / (2 * (1 - f));
				if (rnew > rtop)
					break;
				else if (rtop < 0)
					break;
				else
					rtop -= 0.01;
			}
			if (rtop < 0) rtop = r = 0;

			//step 2, find a value make r keep the same
			while (fabs(rtop - rbottom) > 1e-10)
			{
				r = (rtop + rbottom) / 2;
				rnew = 1;
				double t = 2 * f * r - f - 2 * r;
				for (int i = 0; i < Locus[l].n; ++i)
					rnew -= (t + sqrt(t * t + 4 * n2[l][i] * (1 - f))) / (2 * (1 - f));
				if (rnew > r)
					rtop = r;
				else
					rbottom = r;
			}
			pn[l] = r;
			CheckProcessBar();
			delete[] n2[l];
		}

		delete[] fis;
		delete[] n2;
		return pn;
	}
    double* N_Chybicki2008(double & fbest)
    {
		double vf[] = {1e-3, 1e-1, 3e-1};
		int count = 0;
		int nf = 3;
		int **na = new int*[L];
		double *pn = N_Chakraborty1992();
		double *pnbest = new double[L];
		double *pnnew = new double[L];
		double **pf = new double*[L];
		double **pfnew = new double*[L];
		double **pfbak = new double*[L];
		double tdouble;
		int *nmm = new int[L];
		memset(nmm, 0, sizeof(int) * L);

		//Locus information
		double bestpnli = -1e100;
		int nInds = (int)inds.size();
		for (int l = 0; l < L; ++l)
		{
			pf[l] = new double[Locus[l].n];
			pfnew[l] = new double[Locus[l].n];
			pfbak[l] = new double[Locus[l].n];
			na[l] = new int[Locus[l].n * Locus[l].n];
			int *n = new int[Locus[l].n];
			memset(pf[l], 0, sizeof(double) * Locus[l].n);
			memset(n, 0, sizeof(int) * Locus[l].n);
			memset(na[l], 0, sizeof(int) * Locus[l].n * Locus[l].n);
			int ntot = 0;
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] < 0 || inds[i].genotype.b[l] < 0)
				{
					nmm[l]++;
					continue;
				}
				ntot++;
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
				if (inds[i].genotype.a[l] == inds[i].genotype.b[l])
					na[l][inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
				else
				{
					na[l][inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
					na[l][inds[i].genotype.b[l] * Locus[l].n + inds[i].genotype.a[l]]++;
				}
			}
			for (int i = 0; i < Locus[l].n; ++i)
				pf[l][i] = n[i] / (2.0 * ntot);

			bool flag = false;
			for (int i = 0; i < Locus[l].n; ++i)
			{
				if (n[i] == 2.0 * ntot)
					flag = true;
				pf[l][i] = n[i] / (2.0 * ntot);
			}
			if (flag || nmm[l] == nInds)
			{
				nmm[l] = nInds;
				pnbest[l] = nan;
			}
			delete[] n;
			memmove(pfbak[l], pf[l], sizeof(double) * Locus[l].n);
		}
		for (int l1 = 0; l1 < nf; ++l1)
		{
			double f = vf[l1];
			for (int l = 0; l < L; ++l)
			{
				if (nmm[l] == nInds) 
				{
					pn[l] = nan; 
					continue;
				}
				memmove(pf[l], pfbak[l], sizeof(double) * Locus[l].n);
				pn[l] = pn[l] > 0.01 ? pn[l] : 0.01;
				for (int i = 0; i < Locus[l].n; ++i)
					pf[l][i] *= 1 - pn[l];
			}
			for (;;)
			{
				double fnew = 0;
				for (int l = 0; l < L; ++l)
				{
					if (nmm[l] == nInds) continue;
					int k1 = Locus[l].n;
					for (int i = 0; i < k1; ++i)
					{
						pfnew[l][i] = 0;
						if (pf[l][i] == 0) continue;
						tdouble = (na[l][i * k1 + i] * ((1 - f) * pf[l][i] * (pf[l][i] + pn[l]) + f * pf[l][i])) / (nInds * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) pfnew[l][i] += tdouble;
						for (int j = 0; j < k1; ++j)
							if (j != i && pf[l][j] > 0)
								pfnew[l][i] += na[l][j * k1 + i] / 2.0 / nInds;
					}
					pnnew[l] = 0;
					for (int i = 0; i < k1; ++i)
					{
						if (pf[l][i] == 0) continue;
						tdouble = (na[l][i * k1 + i] * pf[l][i] * pn[l] * (1 - f)) / (nInds * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) pnnew[l] += tdouble;
					}
					tdouble = (nmm[l] * ((1 - f) * pn[l] * pn[l] + f * pn[l])) / (nInds * ((1 - f) * pn[l] * pn[l] + f * pn[l]));
					if (tdouble > 0) pnnew[l] += tdouble;

					double fnewt  = 0;
					for (int i = 0; i < k1; i++)
					{
						if (pf[l][i] == 0) 
							continue;
						tdouble = (na[l][i * k1 + i] * f * pf[l][i]) /  (nInds * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) fnewt += tdouble;
					}
					tdouble = (nmm[l] * f * pn[l]) / (nInds * ((1 - f) * pn[l] * pn[l] + f * pn[l]));
					if (tdouble > 0) fnewt += tdouble;
					fnew += fnewt;
				}
				
				//assign new value and calculate the likelihood
				f = fnew / L;
				double diff = 0.0;
				for (int l = 0; l < L; ++l)
				{
					if (nmm[l] == nInds) continue;
					int k1 = Locus[l].n;
					for (int i = 0; i < k1; i++)
					{
						if (pf[l][i] == 0) continue;
						diff += fabs((double)(pf[l][i] - pfnew[l][i]));
						pf[l][i] = pfnew[l][i];
					}
					diff += fabs(pn[l] - pnnew[l]);
					diff += fabs(f - fnew);
					//if (IsNaN(pnnew[l]) || IsNaN(fnew))
						//count = count;
					pn[l] = pnnew[l];
					memmove(pf[l], pfnew[l], k1 * sizeof(double));
				}
				//if (IsNaN(diff))
					//count = count;
				if (diff < 1e-8 || count++ > 2000)
					break;
			}
			double li = 0;
			for (int l = 0; l < L; ++l)
			{
				if (nmm[l] == nInds) continue;
				int k1 = Locus[l].n;
				if (nmm[l]) li += nmm[l] * mylog10((1 - f) * pn[l] * pn[l] + f * pn[l]);
				for (int i = 0; i < k1; ++i)
				{
					if (pf[l][i] == 0)
						continue;
					li += na[l][i * k1 + i] * mylog10((1 - f) * (pf[l][i] * pf[l][i] + 2 * pf[l][i] * pn[l]) + f * pf[l][i]);
					for (int j = 0; j < i; ++j)
					{
						if (pf[l][j] == 0 || j == i)
							continue;
						li += na[l][i * k1 + j] * mylog10(2 * pf[l][i] * pf[l][j] * (1 - f));
					}
				}
			}

			
			if (li > bestpnli)
			{
				bestpnli = li;
				memmove(pnbest, pn, L * sizeof(double));
				fbest = f;
			}
		}
		for (int l = 0; l < L; ++l)
		{
			delete[] pf[l];
			delete[] pfnew[l];
			delete[] pfbak[l];
			delete[] na[l];
		}
		delete[] na;
		delete[] pf;
		delete[] pfnew;
		delete[] pfbak;
		delete[] pn;
		delete[] pnnew;
		delete[] nmm;
		return pnbest;
    }

	struct P1
	{
		double coef;
		vector<int> a;//hwe
	};
	
	struct P2//ploidy, vis
	{
		int count;
		vector<P1> a;
	};
	
	class IDCOUNT
	{
	public:
		int id;
		int count;
		
		IDCOUNT(int a = -1, int b = -1)
		{
			id = a;
			count = b;
		}
	};

	void unify(FASTTABLE<int, double> &f1)
	{
		double s = 0;
		for (uint i = 0; i < f1.size; ++i)
			s += f1(i);
		
		for (uint i = 0; i < f1.size; ++i)
			f1(i) /= s;
	}

	P2** p2;
	int tp2g[MAXPLOIDY];

	void p2g()
	{
		p2 = new P2*[MAXPLOIDY + 1];
		for (int p = 1; p <= MAXPLOIDY; ++p)
		{
			p2[p] = new P2[p + 1];

			for (int nvis = 1; nvis <= p; ++nvis)
			{
				p2[p][nvis].count = 0;
				memset(tp2g, 0, sizeof(int) * (MAXPLOIDY + 1));
				for (int i = 0; i < nvis - 1; ++i) tp2g[i] = 1;
				p2g1(p, nvis, p - nvis, 0);
			}
		}
	}

	void p2g1(int p, int nvis, int rest, int lay)
	{
		if (lay == nvis - 1) 
		{
			int p1 = p;
			tp2g[lay] = rest + 1;
			P1 tp1;
			tp1.coef = 1;
			for (int i = 0; i < nvis; ++i)
			{
				tp1.a.push_back(tp2g[i]);
				tp1.coef *= bi[p][tp2g[i]];
				p -= tp1.a[i];
			}
			p2[p1][nvis].a.push_back(tp1);
			p2[p1][nvis].count++;
			return;
		}
		for (int i = 0; i <= rest; ++i)
		{
			tp2g[lay] = i + 1;
			p2g1(p, nvis, rest - i, lay + 1);
		}
	}

	void AlleleFrequencyNoNull()
	{
		printf("Estimating allele frequency by EM algorithm");
		p2g();
		freobs = new double*[L];
		int* nvis = new int[inds.size()];
		double* buf = new double[BUFLEN];
		FASTTABLE<uint, IDCOUNT> pheno;
		FASTTABLE<int, double> ff;
		FASTTABLE<int, double> f2;
		for (int l = 0; l < L; ++l)
		{
			printf(".");
			pheno.Clear();
			ff.Clear();
			f2.Clear();
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (IsMissingGenotype(inds[i].genotype, l)) 
				{
					nvis[i] = 0; 
					continue; 
				}
				int p = inds[i].genotype.ploidy[l], namb = 0;

				int tal[] = {inds[i].genotype.a[l], inds[i].genotype.b[l], inds[i].genotype.c[l], inds[i].genotype.d[l], inds[i].genotype.e[l], inds[i].genotype.f[l], inds[i].genotype.g[l]};
				for (int j = 0; j < p; ++j)
				{
					if (tal[j] == AMBIGUOUS_ALLELE) namb++;
					else if (!ff.HasKey(tal[j])) 
						ff[tal[j]] = 0; 
				}
				/*
				if (namb > 0)
				{
					for (int j = 0; j < p; ++j)
						for (int k = j + 1; k < p; ++k)
							if (tal[j] == tal[k] && tal[k] != AMBIGUOUS_ALLELE)
							{
								tal[k] = AMBIGUOUS_ALLELE;
								namb++;
							}
				}
				*/
				nvis[i] = p - namb;
				sortuint((unsigned int *)&tal[0], p);
				inds[i].genotype.a[l] = tal[0];
				inds[i].genotype.b[l] = tal[1];
				inds[i].genotype.c[l] = tal[2];
				inds[i].genotype.d[l] = tal[3];
				inds[i].genotype.e[l] = tal[4];
				inds[i].genotype.f[l] = tal[5];
				inds[i].genotype.g[l] = tal[6];
				inds[i].genotype.h[l] = tal[7];

				switch (nvis[i])
				{
				case 8:  ff[inds[i].genotype.h[l]] += p / (double)nvis[i];
				case 7:  ff[inds[i].genotype.g[l]] += p / (double)nvis[i];
				case 6:  ff[inds[i].genotype.f[l]] += p / (double)nvis[i];
				case 5:  ff[inds[i].genotype.e[l]] += p / (double)nvis[i];
				case 4:  ff[inds[i].genotype.d[l]] += p / (double)nvis[i];
				case 3:  ff[inds[i].genotype.c[l]] += p / (double)nvis[i];
				case 2:  ff[inds[i].genotype.b[l]] += p / (double)nvis[i];
				case 1:  ff[inds[i].genotype.a[l]] += p / (double)nvis[i];
				}
				uint hash = HashGenotype(tal, nvis[i], p);
				if (!pheno.HasKey(hash)) 
					pheno[hash] = IDCOUNT(i, 0);
				pheno[hash].count++;
			}

			unify(ff);
			
			//printf("%0.6lf %0.6lf %0.6lf %0.6lf\r\n", ff[0], ff[1], ff[2], ff[3]);
			//fpause();
			for (int j = 0; j < 2000; ++j)
			{
				for (uint i = 0; i < ff.size; ++i)
					f2[ff.GetEntry(i).key] = 0;

				for (uint j = 0; j < pheno.size; ++j)
				{
					IDCOUNT* idc = &pheno(j);
					int i = idc->id;
					int count = idc->count;
					int p = inds[i].genotype.ploidy[l];
					double spr = 0;

					if (nvis[i] == 0) continue;

					for (int j = 0; j < p2[p][nvis[i]].count; ++j)
					{
						double pr = p2[p][nvis[i]].a[j].coef;
						switch (nvis[i])
						{
						case 8: pr *= pow(ff[inds[i].genotype.h[l]], p2[p][nvis[i]].a[j].a[7]); 
						case 7: pr *= pow(ff[inds[i].genotype.g[l]], p2[p][nvis[i]].a[j].a[6]); 
						case 6: pr *= pow(ff[inds[i].genotype.f[l]], p2[p][nvis[i]].a[j].a[5]); 
						case 5: pr *= pow(ff[inds[i].genotype.e[l]], p2[p][nvis[i]].a[j].a[4]); 
						case 4: pr *= pow(ff[inds[i].genotype.d[l]], p2[p][nvis[i]].a[j].a[3]); 
						case 3: pr *= pow(ff[inds[i].genotype.c[l]], p2[p][nvis[i]].a[j].a[2]); 
						case 2: pr *= pow(ff[inds[i].genotype.b[l]], p2[p][nvis[i]].a[j].a[1]); 
						case 1: pr *= pow(ff[inds[i].genotype.a[l]], p2[p][nvis[i]].a[j].a[0]); 
						}
					
						buf[j] = pr;
						spr += pr;
					}
					
					for (int j = 0; j < p2[p][nvis[i]].count; ++j)
					{
						for (int k = 0; k < nvis[i]; ++k)
						{
							switch (k)
							{
							case 0: f2[inds[i].genotype.a[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 1: f2[inds[i].genotype.b[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 2: f2[inds[i].genotype.c[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 3: f2[inds[i].genotype.d[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 4: f2[inds[i].genotype.e[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 5: f2[inds[i].genotype.f[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 6: f2[inds[i].genotype.g[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							case 7: f2[inds[i].genotype.h[l]] += p2[p][nvis[i]].a[j].a[k] * count * buf[j] / spr; break;
							}
						}
					}
				}
				
				unify(f2);
					
				//printf("%0.6lf %0.6lf %0.6lf %0.6lf\r\n", f2[0], f2[1], f2[2], f2[3]);
				//fpause();

				double diff = 0;
				for (uint i = 0; i < ff.size; i++)
				{
					auto p = &ff.GetEntry(i);
					diff += fabs(p->val - f2[p->key]);
					p->val = f2[p->key];
				}
				if (diff < 1e-10)
					break;
			}
			
			freobs[l] = new double[Locus[l].n + 1];
			frenull[l] = new double[Locus[l].n + 1];
			freobs[l][Locus[l].n] = frenull[l][Locus[l].n] = 1;
			for (int i = 0; i < Locus[l].n; ++i)
				freobs[l][i] = frenull[l][i] = f2[i];
		}
		
		printf("\r\n");
		
		char* od[16] = {"%0.0lf","%0.1lf","%0.2lf","%0.3lf","%0.4lf","%0.5lf","%0.6lf","%0.7lf","%0.8lf","%0.9lf","%0.10lf","%0.11lf","%0.12lf","%0.13lf","%0.14lf","%0.15lf"};
		char* nd[5] = {"", "%01d", "%02d", "%03d", "%04d"};
		FILE * f1 = 0;
		f1 = fopen("freq_em.txt", "wb");
		fprintf(f1, "//allele frequency\r\n");
		if (f1)
		{
			for (int l = 0; l < L; ++l)
				fprintf(f1, "%s\t%d\t", Locus[l].name, Locus[l].n);
			fprintf(f1, "\r\n");

			for (int k = 0; k < maxallele; ++k)
			{
				for (int l = 0; l < L; ++l)
				{
					if (Locus[l].n > k) fprintf(f1, nd[ndigits], findallele2(k, l));
					fprintf(f1, "\t");
					if (Locus[l].n > k) fprintf(f1, od[outputdigits], freobs[l][k]);
					fprintf(f1, "\t");
				}
				fprintf(f1, "\r\n");
			}

			fclose(f1);
			printf("\r\nAllele frequency has been writed to 'freq_em.txt'.\r\n");
		}
		else
		{
			printf("Can not write allele frequency to 'freq_em.txt'.\r\n");
			printf("\r\n");
		}
		delete[] nvis;
		delete[] buf;
	}

	int **na, *nmm, nne;
	double **pf;
	int N_t, N_o, N_c;
	double* N_Huang2014(int pop, bool isf, bool isb)
	{
		na = new int*[L];
		nmm = new int[L];
		memset(nmm, 0, sizeof(int) * L);
		pf = new double*[L];
		for (int l = 0; l < L; ++l)
		{
			pf[l] = new double[Locus[l].n];
			na[l] = new int[Locus[l].n * Locus[l].n];
			int *n = new int[Locus[l].n];
			memset(pf[l], 0, sizeof(double) * Locus[l].n);
			memset(n, 0, sizeof(int) * Locus[l].n);
			memset(na[l], 0, sizeof(int) * Locus[l].n * Locus[l].n);
			int ntot = 0;
			for (int i = 0; i < (int)pops[pop].inds.size(); ++i)
			{
				if (pops[pop].inds[i].genotype.a[l] < 0 || pops[pop].inds[i].genotype.b[l] < 0)
				{
					nmm[l]++;
					continue;
				}
				ntot++;
				n[pops[pop].inds[i].genotype.a[l]]++;
				n[pops[pop].inds[i].genotype.b[l]]++;
				if (pops[pop].inds[i].genotype.a[l] == pops[pop].inds[i].genotype.b[l])
					na[l][pops[pop].inds[i].genotype.a[l] * Locus[l].n + pops[pop].inds[i].genotype.b[l]]++;
				else
				{
					na[l][pops[pop].inds[i].genotype.a[l] * Locus[l].n + pops[pop].inds[i].genotype.b[l]]++;
					na[l][pops[pop].inds[i].genotype.b[l] * Locus[l].n + pops[pop].inds[i].genotype.a[l]]++;
				}
			}

			for (int i = 0; i < Locus[l].n; ++i)
				pf[l][i] = n[i] / (2.0 * ntot);
			delete[] n;
		}

		int df = L + isb + isf;
		point3* xx = new point3[df + 1];
		double vn[] = {-12, -3.8918, -1.3863};
		double vf[] = {-12, -3.8918, -1.3863};
		double vb[] = {-12, -3.8918, -1.3863};
		int nnul = 3, nf = 3, nb = 3;
		if (!isb)
		{
			nb = 1;
			vb[0] = -100;
		}
		if (!isf)
		{
			nf = 1;
			vf[0] = -100;
		}
		for (int i = 0; i <= df; ++i) 
			xx[i].init(df, -2);
		
		point3 x0, xr, xe, xc, xbest;
		xbest.li = -1e100;
		int totalcount = 0;
		N_t = (int)pops.size() * nnul * nf * nb;
		for (int l1 = 0; l1 < nnul; ++l1)
		for (int l2 = 0; l2 < nf; ++l2)
		for (int l3 = 0; l3 < nb; ++l3)
		{
			for (int i = 0; i <= df; ++i) 
			{
				if (i == 0)
				{
					for (int j = 0; j < L; ++j)
						xx[i].image[j] = vn[l1];
					switch (nne)
					{
					case 4:
						xx[i].image[L] = vf[l2];
						xx[i].image[L + 1] = vb[l3];
						break;
					case 5:
						xx[i].image[L] = vf[l2];
						break;
					case 6:
						xx[i].image[L] = vb[l3];
						break;
					default:
						break;
					}

				}
				if (i) xx[i].image[i - 1] = xx[0].image[i - 1] / 10;
				xx[i].li = Huang2014_Likelihood(xx[i]);
			}
			//Order
			double sep = 0.1;
			double likestop = LIKESTOP1;
			for (int kk = 0; kk < 10; ++kk)
			{
				//downhill simplex method
				order(xx);
				int searchcount;
				searchcount = 0;
				while (!isbreak(xx, LIKESTOP1) && searchcount < MAX_ITER_ML)
				{
					totalcount++;
					searchcount++;
					//Reflect
					x0 = xx[0];
					for (int i = 1; i < df; ++i)
						x0 += xx[i];
					x0 /= df;
					point3 xr;
					xr = x0; 
					xr += x0; 
					xr -= xx[df];
					xr.li = Huang2014_Likelihood(xr);
			
					//Expansion
					//best
					if (xr > xx[0])
					{
						xe = x0; 
						xe *= 3; 
						xe -= xx[df]; 
						xe -= xx[df];
						xe.li = Huang2014_Likelihood(xe);
						for (int i = 1; i <= df; ++i)
							xx[i] = xx[i - 1];
						xx[0] = xe > xr ? xe : xr;
						continue;
					}
					//better than second worst
					if (xr > xx[df - 1])
					{
						xx[df] = xr;
						order(xx);
						continue;
					}
					//worse than second worst
					//Contraction
					xc = x0; 
					xc -= xx[df];
					xc /= 2;
					xc += xx[df];
					xc.li = Huang2014_Likelihood(xc);
					if (xc > xx[df])
					{
						xx[df] = xc;
						order(xx);
						continue;
					}
			
					//Reduction
					for (int i = 1; i <= df; ++i)
					{
						xx[i] += xx[0];
						xx[i] /= 2;
						xx[i].li = Huang2014_Likelihood(xx[i]);
					}
					order(xx);
					continue;
				}
		
				//step 2
				for (int i = 1; i <= df; ++i) 
				{
					xx[i] = xx[0];
					xx[i].image[i - 1] *= (1 - sep);
					xx[i].li = Huang2014_Likelihood(xx[i]);
				}
				sep /= 8;
				likestop /= 2;
			}
			if (xbest < xx[0])
				xbest = xx[0];
			CheckProcessBar();
		}
		xbest.i2r();
		double* pn = new double[df + 2];
		memmove(pn, xbest.real, (df + 2) * sizeof(double));
		xe.uninit();
		xr.uninit();
		xc.uninit();
		x0.uninit();
		xbest.uninit();
		for (int i = 0; i < L; ++i)
		{
			delete pf[i];
			delete na[i];
		}
		for (int i = 0; i <= df; ++i) 
			xx[i].uninit();
		delete[] na;
		delete[] pf;
		delete[] nmm;
		delete[] xx;
		return pn;
	}
	double Huang2014_Likelihood(point3 xx)
	{
		//calc coef
		xx.i2r();
		double re = 0;
		for (int l = 0; l < L; ++l)
		{
			double f = 0, b = 0;
			switch (nne)
			{
			case 4:
				f = xx.real[L];
				b = xx.real[L + 1];
				break;
			case 5:
				f = xx.real[L];
				break;
			case 6:
				b = xx.real[L];
				break;
			default:
				break;
			}
			double py = xx.real[l];
			double v = 1 - py;
			double v2 = v * v;
			re += nmm[l] * mylog10(b + (1 - b) * ((1 - f) * py * py  + f * py));
			for (int i = 0; i < Locus[l].n; ++i)
			{
				if (pf[l][i] == 0)
					continue;
				re += na[l][i * Locus[l].n + i] * mylog10((1 - b) * ((1 - f) * (v2 * pf[l][i] * pf[l][i] + 2 * pf[l][i] * v * py) + f * v * pf[l][i]));
				for (int j = 0; j < i; ++j)
				{
					if (pf[l][j] == 0)
						continue;
					re += na[l][i * Locus[l].n + j] * mylog10(2 * v2 * pf[l][i] * pf[l][j] * (1 - f) * (1 - b));
				}
			}
		}
		xx.li = re < MINLIKELIHOOD ? MINLIKELIHOOD : re;
		return xx.li;
	}
    double* N_Kalinowski2006(double* &betal, double f = -1)
    {
		double *pnl = new double[L];
		betal = new double[L];
		double vb[] = {1e-5, 1e-1, 3e-1};
		int nb = 3;
		if (f < 0)
			f = 0;
		double *initnull = N_Chakraborty1992(false);
		double tdouble;
		for (int l = 0; l < L; ++l)
		{
			int nInds = (int)inds.size();
			double *pf = new double[Locus[l].n];
			double* pfnew = new double[Locus[l].n];
			double *pfbak = new double[Locus[l].n];
			double bestpnli = -1e100;
			int *na = new int[Locus[l].n * Locus[l].n];
			int *n = new int[Locus[l].n];
			int nmm = 0;
			memset(pf, 0, sizeof(double) * Locus[l].n);
			memset(pfnew, 0, sizeof(double) * Locus[l].n);
			memset(n, 0, sizeof(int) * Locus[l].n);
			memset(na, 0, sizeof(int) * Locus[l].n * Locus[l].n);
			int ntot = 0;
			int k1 = Locus[l].n;
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] < 0 || inds[i].genotype.b[l] < 0)
				{
					nmm++;
					continue;
				}
				ntot++;
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
				if (inds[i].genotype.a[l] == inds[i].genotype.b[l])
					na[inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
				else
				{
					na[inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
					na[inds[i].genotype.b[l] * Locus[l].n + inds[i].genotype.a[l]]++;
				}
			}

			bool flag = false;
			for (int i = 0; i < Locus[l].n; ++i)
			{
				if (n[i] == 2.0 * ntot)
					flag = true;
				pf[i] = n[i] / (2.0 * ntot);
			}
			if (flag || nmm == ntot)
			{
				pnl[l] = 0;
				betal[l] = 0;
				continue;
			}
			memmove(pfbak, pf, sizeof(double) * k1);

			for (int l2 = 0; l2 < nb; ++l2)
			{
				memmove(pf, pfbak, sizeof(double) * k1);
				double pn = initnull[l];
				double beta = vb[l2];
				for (int i = 0; i < k1; ++i)
					pf[i] *= 1 - pn;
				for (;;)
				{
					double pn2 = pn * pn;
					for (int i = 0; i < k1; ++i)
					{
						pfnew[i] = 0;
						if (pf[i] == 0) continue;
						tdouble = (na[i * k1 + i] * ((1 - f) * pf[i] * (pf[i] + pn) + f * pf[i])) / (nInds * ((1 - f) * pf[i] * (pf[i] + 2 * pn) + f * pf[i]));
						if (tdouble > 0) pfnew[i] += tdouble;
						for (int j = 0; j < k1; ++j)
							if (j != i)
								pfnew[i] += na[j * k1 + i] / 2.0 / nInds;
						tdouble = (nmm * beta * pf[i]) / (nInds * (beta + (1 - beta) * ((1 - f) * pn2 + f * pn)));
						if (tdouble > 0) pfnew[i] += tdouble;
					}
					double pnnew = 0.0;
					for (int i = 0; i < k1; ++i)
						if (pf[i] > 0)
						{
							tdouble = (na[i * k1 + i] * pf[i] * pn * (1 - f)) / (nInds * ((1 - f) * pf[i] *(pf[i] + 2 * pn) + f * pf[i]));
							if (tdouble > 0) pnnew += tdouble;
						}
					tdouble = (nmm * (beta * pn + (1 - beta) * ((1 - f) * pn2 + f * pn))) / (nInds * (beta + (1 - beta) * ((1 - f) * pn2 + f * pn)));
					if (tdouble > 0) pnnew += tdouble;
					tdouble = (nmm * beta) / (nInds * (beta + (1 - beta) * ((1 - f) * pn2 + f * pn)));
					double betanew;
					if (tdouble > 0) betanew = tdouble;
					else betanew = beta;
					double diff = 0.0;
					for (int i = 0; i < k1; i++)
					{
						if (pf[i] == 0) continue;
						diff += fabs((double)(pf[i] - pfnew[i]));
						pf[i] = pfnew[i];
						pfnew[i] = 0.0;
					}
					diff += fabs(pn - pnnew);
					diff += fabs(beta - betanew);

					beta = betanew;
					pn = pnnew;

					pnnew = 0.0;
					betanew = 0.0;
					if (diff < 1e-8)
						break;
				}

				double L = nmm * mylog10(beta + (1 - beta) * pn * pn);
				for (int i = 0; i < k1; ++i)
				{
					if (pf[i] == 0) continue;
					L += na[i * k1 + i] * mylog10((1 - beta) * (pf[i] * pf[i] + 2 * pf[i] * pn));
					for (int j = 0; j < i; ++j)
					{
						if (pf[j] == 0) continue;
						L += na[i * k1 + j] * mylog10(2 * pf[i] * pf[j] * (1 - beta));
					}
				}

				if (L > bestpnli)
				{
					bestpnli = L;
					pnl[l] = pn;
					betal[l] = beta;
				}
			}
			delete[] n;
			delete[] pf;
			delete[] na;
			delete[] pfnew;
			delete[] pfbak;
			CheckProcessBar();
		}
		delete[] initnull;
		return pnl;
    }
    double* N_HuangNull(double *&betabest, double & fbest, bool processbar = true)
    {
		double vb[] = {1e-2, 1e-1};
		double vf[] = {1e-2, 1e-1};
		int nb = 2, nf = 2;
		double *initnull = N_Chakraborty1992(false);
		int **na = new int*[L];
		double **pf = new double*[L];
		double **pfnew = new double*[L];
		double **pfbak = new double*[L];
		double *pn = new double[L];
		double *pnbest = new double[L];
		double *pnnew = new double[L];
		double *beta = new double[L];
		betabest = new double[L];
		memset(betabest, 0, sizeof(double) * L);
		double tdouble;
		double *betanew = new double[L];
		int *nmm = new int[L];
		memset(nmm, 0, sizeof(int) * L);
		if (processbar) N_t = nb * nf;
		//Locus information
		double bestpnli = -1e100;
		int nInds = (int)inds.size();
		if (processbar) N_t = nb * nb + L;
		for (int l = 0; l < L; ++l)
		{
			pf[l] = new double[Locus[l].n];
			pfnew[l] = new double[Locus[l].n];
			pfbak[l] = new double[Locus[l].n];
			na[l] = new int[Locus[l].n * Locus[l].n];
			int *n = new int[Locus[l].n];
			memset(pf[l], 0, sizeof(double) * Locus[l].n);
			memset(n, 0, sizeof(int) * Locus[l].n);
			memset(na[l], 0, sizeof(int) * Locus[l].n * Locus[l].n);
			int ntot = 0;
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				if (inds[i].genotype.a[l] < 0 || inds[i].genotype.b[l] < 0)
				{
					nmm[l]++;
					continue;
				}
				ntot++;
				n[inds[i].genotype.a[l]]++;
				n[inds[i].genotype.b[l]]++;
				if (inds[i].genotype.a[l] == inds[i].genotype.b[l])
					na[l][inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
				else
				{
					na[l][inds[i].genotype.a[l] * Locus[l].n + inds[i].genotype.b[l]]++;
					na[l][inds[i].genotype.b[l] * Locus[l].n + inds[i].genotype.a[l]]++;
				}
			}
			for (int i = 0; i < Locus[l].n; ++i)
				pf[l][i] = n[i] / (2.0 * ntot);

			bool flag = false;
			for (int i = 0; i < Locus[l].n; ++i)
			{
				if (n[i] == 2.0 * ntot)
					flag = true;
				pf[l][i] = n[i] / (2.0 * ntot);
			}
			if (flag || nmm[l] == nInds)
			{
				nmm[l] = nInds;
				pnbest[l] = nan;
				betabest[l] = nan;
			}
			delete[] n;
			memmove(pfbak[l], pf[l], sizeof(double) * Locus[l].n);
		}

		for (int l1 = 0; l1 < nf; ++l1)
		for (int l2 = 0; l2 < nb; ++l2)
		{
			double f = vf[l1];
			for (int l = 0; l < L; ++l)
			{
				if (nmm[l] == nInds) 
				{
					beta[l] = nan;
					pn[l] = nan;
					continue;
				}
				beta[l] = vb[l2];
				memmove(pf[l], pfbak[l], sizeof(double) * Locus[l].n);
				pn[l] = initnull[l] > 0.01 ? initnull[l] : 0.01;
				for (int i = 0; i < Locus[l].n; ++i)
					pf[l][i] *= 1 - pn[l];
			}

			int count = 0;
			for (;;)
			{
				double fnew = 0;
				double fnewweight= 0;
				for (int l = 0; l < L; ++l)
				{
					if (nmm[l] == nInds) continue;
					int k1 = Locus[l].n;
					for (int i = 0; i < k1; ++i)
					{
						pfnew[l][i] = 0;
						if (pf[l][i] == 0)
							continue;
						tdouble = (na[l][i * k1 + i] * ((1 - f) * pf[l][i] * (pf[l][i] + pn[l]) + f * pf[l][i])) / (nInds * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) pfnew[l][i] += tdouble;
						for (int j = 0; j < k1; ++j)
							if (j != i && pf[l][j] > 0)
								pfnew[l][i] += na[l][j * k1 + i] / 2.0 / nInds;

						tdouble = (nmm[l] * beta[l] * pf[l][i]) / (nInds * (beta[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l])));
						if (tdouble > 0) pfnew[l][i] += tdouble;
					}
					pnnew[l] = 0;
					betanew[l] = beta[l];
					for (int i = 0; i < k1; ++i)
					{
						if (pf[l][i] == 0)
							continue;
						tdouble = (na[l][i * k1 + i] * pf[l][i] * pn[l] * (1 - f)) / (nInds * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) pnnew[l] += tdouble;
					}
					tdouble = (nmm[l] * (beta[l] * pn[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l]))) / (nInds * (beta[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l])));
					if (tdouble > 0) pnnew[l] += tdouble;
					tdouble = (nmm[l] * beta[l]) / (nInds * (beta[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l])));
					if (tdouble > 0) betanew[l] = tdouble;

					fnewweight += nInds - nmm[l];
					double fnewt  = 0;
					for (int i = 0; i < k1; i++)
					{
						if (pf[l][i] == 0) 
							continue;
						tdouble = (na[l][i * k1 + i] * f * pf[l][i]) /  (nInds * (1 - beta[l]) * ((1 - f) * pf[l][i] * (pf[l][i] + 2 * pn[l]) + f * pf[l][i]));
						if (tdouble > 0) fnewt += tdouble;
					}
					tdouble = (nmm[l] * f * pn[l]) / (nInds * (beta[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l])));
					if (tdouble > 0) fnewt += tdouble;
					fnew += (nInds - nmm[l]) * fnewt;
				}
				
				//assign new value and calculate the likelihood
				f = fnew / fnewweight;
				double diff = 0.0;
				for (int l = 0; l < L; ++l)
				{
					if (nmm[l] == nInds) continue;
					int k1 = Locus[l].n;
					for (int i = 0; i < k1; i++)
					{
						if (pf[l][i] == 0)
							continue;
						diff += fabs((double)(pf[l][i] - pfnew[l][i]));
						pf[l][i] = pfnew[l][i];
					}
					diff += fabs(pn[l] - pnnew[l]);
					diff += fabs(beta[l] - betanew[l]);
					diff += fabs(f - fnew);
					if (IsNaN(pnnew[l]) || IsNaN(betanew[l]) || IsNaN(fnew))
						l = l;
					beta[l] = betanew[l];
					pn[l] = pnnew[l];
					memmove(pf[l], pfnew[l], k1 * sizeof(double));
				}
				//if (IsNaN(diff));
				if (diff < 1e-8 || count++ > 2000)
					break;
			}
			double li = 0;
			for (int l = 0; l < L; ++l)
			{
				if (nmm[l] == nInds) continue;
				int k1 = Locus[l].n;
				li += nmm[l] * mylog10(beta[l] + (1 - beta[l]) * ((1 - f) * pn[l] * pn[l] + f * pn[l]));
				for (int i = 0; i < k1; ++i)
				{
					if (pf[l][i] == 0)
						continue;
					li += na[l][i * k1 + i] * mylog10((1 - beta[l]) * ((1 - f) * (pf[l][i] * pf[l][i] + 2 * pf[l][i] * pn[l]) + f * pf[l][i]));
					for (int j = 0; j < i; ++j)
					{
						if (pf[l][j] == 0 || j == i)
							continue;
						li += na[l][i * k1 + j] * mylog10(2 * pf[l][i] * pf[l][j] * (1 - beta[l]) * (1 - f));
					}
				}
			}
			CheckProcessBar();
			if (li > bestpnli)
			{
				bestpnli = li;
				memmove(pnbest, pn, L * sizeof(double));
				memmove(betabest, beta, L * sizeof(double));
				fbest = f;
			}
		}
		for (int l = 0; l < L; ++l)
		{
			delete[] pf[l];
			delete[] pfnew[l];
			delete[] pfbak[l];
			delete[] na[l];
		}
		delete[] na;
		delete[] pf;
		delete[] pfnew;
		delete[] pfbak;
		delete[] pn;
		delete[] pnnew;
		delete[] beta;
		delete[] betanew;
		delete[] initnull;
		delete[] betabest;
		delete[] nmm;
		delete[] pnbest;
		pnbest = N_Kalinowski2006(betabest, fbest);
		return pnbest;
    }
	bool estnullallele(int e, double *fisinput = NULL, int fiscount = 0)
	{
		//check
		N_t = L;
		N_o = 0;
		N_c = 0;
		nne = e;
		for (int i = 0; i < N; ++i)
			for (int l = 0; l < L; ++l)
				if (inds[i].genotype.ploidy[l] != 2)
					return false;

		double* B = NULL;
		double* E = NULL;
		double f = 0;

		switch (e)
		{
			case 1: E = N_Chakraborty1992(); break;
			case 2: E = N_Summer1997(); break;
			case 3: E = N_Kalinowski2006(B); break;
			case 4: E = N_Chybicki2008(f); break;
			case 5: E = N_Oosterhout2006(f); break;
			case 6: E = N_Oosterhout2004(); break;
			case 7: E = N_Brookfield19961(); break;
			case 8: E = N_Brookfield19962(); break;
		}
		
		while (N_o < 80)
		{
			N_o++;
			cout << "|";
			fflush(stdout);
		}

		char* od[16] = {"\t%0.0lf","\t%0.1lf","\t%0.2lf","\t%0.3lf","\t%0.4lf","\t%0.5lf","\t%0.6lf","\t%0.7lf","\t%0.8lf","\t%0.9lf","\t%0.10lf","\t%0.11lf","\t%0.12lf","\t%0.13lf","\t%0.14lf","\t%0.15lf"};
		FILE *f1 = fopen(output, "wb");
		if (!f1)  EXIT("Error: Can not open output file.\r\n");
		fprintf(f1, "Null allele estimation by PolyRelatedness V%s\r\n", VERSION);

		switch (e)
		{
			case 1: fprintf(f1, "    Estimator: Chakraborty et al. (1992)\r\n"); break;
			case 2: fprintf(f1, "    Estimator: Summers & Amos (1997)\r\n"); break;
			case 3: fprintf(f1, "    Estimator: Kalinowski & Taper (2006)\r\n"); break;
			case 4: fprintf(f1, "    Estimator: Chybicki & Burczyk (2008)\r\n"); break;
			case 5: fprintf(f1, "    Estimator: van Oosterhout et al. (2006)\r\n"); break;
			case 6: fprintf(f1, "    Estimator: van Oosterhout et al. (2004)\r\n"); break;
			case 7: fprintf(f1, "    Estimator: Brookfield 1st (1996)\r\n"); break;
			case 8: fprintf(f1, "    Estimator: Brookfield 2nd (1996)\r\n"); break;
		}
		fprintf(f1, "    Input: %s\r\n", input);
		fprintf(f1, "    Output: %s\r\n", output);
		struct tm *t1;
		time_t tt1;
		time(&tt1);
		t1 = localtime(&tt1);
		fprintf(f1, "    Time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", t1->tm_year+1900, t1->tm_mon+1, t1->tm_mday, t1->tm_hour, t1->tm_min, t1->tm_sec); 
		
		fprintf(f1, "P(null)");
		for (int i = 0; i < L; ++i)
			fprintf(f1, "\t%s", Locus[i].name);
			if (e == 4 || e == 5)
				fprintf(f1, "\tFis");
		fprintf(f1, "\r\nTotalPop");
		for (int j = 0; j < L; ++j)
			fprintf(f1, od[outputdigits], E[j]);
		if (e == 4 || e == 5)
			fprintf(f1, od[outputdigits], f);
		fprintf(f1, "\r\n");

		if (e == 3)
		{
			fprintf(f1, "\r\nbeta");
			for (int i = 0; i < L; ++i)
				fprintf(f1, "\t%s", Locus[i].name);
			fprintf(f1, "\r\nTotalPop");
			for (int j = 0; j < L; ++j)
				fprintf(f1, od[outputdigits], B[j]);
			fprintf(f1, "\r\n");
		}
		

		fprintf(f1, "\r\n");
		fprintf(f1, "\r\n");
		for (int l = 0; l < L; ++l)
			fprintf(f1, "%s\t%d\t", Locus[l].name, Locus[l].n);
		fprintf(f1, "\r\n");

		char* nd[5] = {"", "%01d", "%02d", "%03d", "%04d"};
		char* od2[16] = {"%0.0lf","%0.1lf","%0.2lf","%0.3lf","%0.4lf","%0.5lf","%0.6lf","%0.7lf","%0.8lf","%0.9lf","%0.10lf","%0.11lf","%0.12lf","%0.13lf","%0.14lf","%0.15lf"};
		

		for (int k = 0; k < maxallele; ++k)
		{
			for (int l = 0; l < L; ++l)
			{
				if (Locus[l].n > k) fprintf(f1, nd[ndigits], findallele2(k, l));
				fprintf(f1, "\t");
				if (Locus[l].n > k) fprintf(f1, od2[outputdigits], freobs[l][k] * (1 - (E[l] < 0 ? 0 : E[l])));
				fprintf(f1, "\t");
			}
			fprintf(f1, "\r\n");
		}

		fclose(f1);
		if (E) delete[] E;
		if (B) delete[] B;
		return true;
	}

	//read input files
	vector<char *> splittab(char * a)
	{
		int slen = (int)strlen(a);
		char *b = new char[slen + 2];
		memmove(b, a, slen + 1);
		vector<char*> re;
		re.push_back(b);
		for (int i = 0; i < slen; ++i)
		{
			if (b[i] == '\t')
			{
				b[i] = 0;
				re.push_back(b + i + 1);
			}
			else if (b[i] == '\\' || b[i] == '\r' || b[i] == '\n')
			{
				b[i] = 0;
				break;
			}
		}
		return re;
	}

	bool readfile()
	{
		bool freqreaded = false;
		int cpos = 0;
		FST = 0;
		PLOIDY = 1;
		maxallele = 0;
		rem = false;
		nPops = 0;
		FILE *f1 = fopen(input, "rb");
		char errorinf[500];
		if (!f1)
			EXIT("Error: Can not open input file.\r\n");
		char *strbuf = new char[BUFLEN];
		int line = 0;
		int linet1, linet2;
		int t;
		fgets(strbuf, BUFLEN, f1);
		line++;
		if (linecmp("//configuration", strbuf))
		{
			sprintf(errorinf, "Error: Format error in input file at Line %d. It should be '//configuration...'.\r\n", line);
			EXIT(errorinf);
		}
		fgets(strbuf, BUFLEN, f1);
		line++;
		int missing, ambiguous;
		if (linecmp("//#alleledigits(1~4)	#outputdigits(0~10)	#missingallele	#ambiguousallele	#nthreads(1~64)", strbuf))
		{			
			sprintf(errorinf, "Error: Format error in input file at Line %d. It should be '//#alleledigits(1~4)	#outputdigits(0~10)	#missingallele	#ambiguousallele	#nthreads(1~64)...'.\r\n", line);
			EXIT(errorinf);
		}
		fgets(strbuf, BUFLEN, f1);
		line++;
		sscanf(strbuf, "%d %d %d %d %d", &ndigits, &outputdigits, &missing, &ambiguous, &nthread);
		if (missing == ambiguous)
			EXIT("Error: Missing allele label should not be equal to ambiguous allele label. \r\n");
		if (missing < 0 || ambiguous < 0)
			EXIT("Error: Missing allele or ambiguous allele label should be zero or positive integer. \r\n");
		if (ndigits < 1 || ndigits > 4)
			EXIT("Error: Number of digits is out of range, should between 1 to 4. \r\n");
		if (outputdigits < 0 || outputdigits > 10)
			EXIT("Error: Number of output digits is out of range, should between 0 to 10. \r\n");
		if (nthread < 1 || nthread > MAXTHREAD)
			EXIT("Error: Number of threads is out of range, should between 1 to 64. \r\n");
		cpos = ftell(f1);
		fgets(strbuf, BUFLEN, f1);
		line++;

		///////////////////////////////////////////////////////////////////////////////
		if (linecmp("//allele frequency", strbuf))
		{
			while (linecmp("//genotype", strbuf))
				fgets(strbuf, BUFLEN, f1);

			fgets(strbuf, BUFLEN, f1);
			vector<char *> ts = splittab(strbuf);
			L = (int)ts.size() - 2;
			Locus = new LOCUS[L];
			allele = new FASTTABLE<int, int>[L];
			for (int i = 0; i < L; ++i)
			{
				Locus[i].weight = 1;
				Locus[i].typed = 0;
				Locus[i].maxploidy = 0;
				Locus[i].rate = 0;
				Locus[i].py = 0;
				Locus[i].AR = 0;
				Locus[i].n = 0;
				Locus[i].name = new char[strlen(ts[i + 2]) + 1];
				memmove(Locus[i].name, ts[i + 2], strlen(ts[i + 2]) + 1);
			}
			delete[] ts[0];
			for (;;)
			{
				fgets(strbuf, BUFLEN, f1);
				if (linecmp("//end of file", strbuf) == 0)
					break;
				vector<char *> ts = splittab(strbuf);
				for (int i = 0; i < L; ++i)
				{
					int p = (int)strlen(ts[i + 2]) / ndigits;
					int tal = 0;
					for (int j = 0; j < p; ++j)
					{
						if (ReadInteger(ts[i + 2], ndigits, tal) != -1)
						{
							ts[i + 2] += ndigits;
							if (tal != missing && tal != ambiguous && !allele[i].HasKey(tal))
								allele[i][tal] = Locus[i].n++;
						}
						else
						{
							sprintf(errorinf, "Error: cannot read genotypes for individual %s at locus %s\r\n", ts[0], Locus[i].name);
							EXIT(errorinf);
						}
					}
				}
				delete[] ts[0];
			}
			
			for (int i = 0; i < L; ++i)
			{
				allele[i][missing] = MISSING_ALLELE;
				allele[i][ambiguous] = AMBIGUOUS_ALLELE;
				maxallele = maxallele > Locus[i].n ? maxallele : Locus[i].n;
			}
			fseek(f1, cpos, SEEK_SET);
			fgets(strbuf, BUFLEN, f1);
			freobs = new double*[L];
			frenull = new double*[L];
		}
		else
		{
			linet1 = ftell(f1);
			fgets(strbuf, BUFLEN, f1);
		
			//get L
			L = 0;
			int alen = (int)strlen(strbuf);
			bool flags = false;
			for (int i = 0; i < alen && strbuf[i] != '\r' && strbuf[i] != '\n'; ++i)
			{
				if (strbuf[i] != '\t')
				{
					if (flags == false)
					{
						flags = true;
						L++;
					}
				}
				else 
					flags = false; 
			}
			//alloc here
			Locus = new LOCUS[L];
			allele = new FASTTABLE<int, int>[L];
			freobs = new double*[L];
			frenull = new double*[L];
			for (int i = 0; i < L; ++i)
			{
				Locus[i].weight = 1;
				Locus[i].typed = 0;
				Locus[i].maxploidy = 0;
				Locus[i].rate = 0;
				Locus[i].py = 0;
				Locus[i].AR = 0;
			}
			L /= 2;
			linet2 = ftell(f1);
			fseek(f1, linet1, SEEK_SET);
			line++;
			maxallele = 0;
			if (L < 1 || L > MAXLOCUS)
			{
				sprintf(errorinf, "Error: Number of loci is out of range, should between 1 to %d. \r\n", MAXLOCUS);
				EXIT(errorinf);
			}
			for (int i = 0; i < L; ++i)
			{
				fscanf(f1, "%s %d", strbuf, &Locus[i].n);
				if (Locus[i].n < 2 || Locus[i].n > MAXALLELES)
				{
					sprintf(errorinf, "Error: Number of alleles is out of range, should between 2 to %d. \r\n", MAXALLELES);
					EXIT(errorinf);
				}
				freobs[i] = new double[Locus[i].n + 1];
				frenull[i] = new double[Locus[i].n + 1];
				freobs[i][Locus[i].n] = 1;
				frenull[i][Locus[i].n] = 1;
				Locus[i].name = new char[strlen(strbuf) + 1];
				strcpy(Locus[i].name, strbuf);
				if (Locus[i].n > maxallele)
					maxallele = Locus[i].n;
			}
			fseek(f1, linet2, SEEK_SET);
			for (int j = 0; j < maxallele; ++j)
			{
				for (int i = 0; i < L; ++i)
				{
					if (j < Locus[i].n)
					{
						fscanf(f1, "%d %lf", &t, &freobs[i][j]);
						if (t == missing || t == ambiguous)
							EXIT("Error: Missing allele or ambiguous allele should not be appeared in the allele frequency section.\r\n");
						allele[i][t] = j;
					}
				}
			}
		
			for (int i = 0; i < L; ++i)
			{
				double sum = 0;
				for (int j = 0; j < Locus[i].n; ++j)
				{
					sum += freobs[i][j];
					frenull[i][j] = freobs[i][j];
				}
				for (int j = 0; j < Locus[i].n; ++j)
					freobs[i][j] /= sum;
				if (sum > 1) for (int j = 0; j < Locus[i].n; ++j)
					frenull[i][j] /= sum;
				else 
					Locus[i].py = 1 - sum;
			}
		
			for (int i = 0; i < L; ++i)
			{
				allele[i][missing] = MISSING_ALLELE;
				allele[i][ambiguous] = AMBIGUOUS_ALLELE;
			}
			line += maxallele;

			fseek(f1, -2, SEEK_CUR);
			fgets(strbuf, BUFLEN, f1);
			fgets(strbuf, BUFLEN, f1);
			line++;

			freqreaded = true;
		}
		
		///////////////////////////////////////////////////////////////////////////////
		//weight

		if (linecmp("//locus weight", strbuf) == 0)
		{
			fgets(strbuf, BUFLEN, f1);
			line++;
			for (int i = 0; i < L; ++i)
				fscanf(f1, "%lf", &Locus[i].weight);
			
			fseek(f1, -2, SEEK_CUR);
			fgets(strbuf, BUFLEN, f1);
			fgets(strbuf, BUFLEN, f1);
			line++;
		}

		///////////////////////////////////////////////////////////////////////////////
		//genotype
		
		if (linecmp("//genotype", strbuf))
		{
			sprintf(errorinf, "Error: Format error in input file at Line %d. It should be '//genotype...'\r\n", line);
			EXIT(errorinf);
		}
		linet1 = ftell(f1);
		for (N = 0; ; ++N)
		{
			fgets(strbuf, BUFLEN, f1);
			if (!linecmp("//end of file", strbuf) || feof(f1) || strlen(strbuf) <= 2)
				break;
			if (N >= MAXINDS)
			{
				sprintf(errorinf, "Error: Number of individual is out of range, should between 0 to %d. \r\n", MAXINDS);
				EXIT(errorinf);
			}
		}
		N--;
		fseek(f1, linet1, SEEK_SET);
		fgets(strbuf, BUFLEN, f1);
		line++;
		int i1 = 0, i2 = 0;
		for (int i = 0; i < L + 2; ++i)
		{
			while (strbuf[i2] && strbuf[i2] != 0x0d && strbuf[i2] != 0x0a && strbuf[i2] != '\t')
				++i2;
			if (strbuf[i2] == 0 && i < L - 1)
			{
				sprintf(errorinf, "Error: The number of column mismatch the number of loci, missing locus? At line: %d\r\n", line);
				EXIT(errorinf);
			}
			if (i > 1)
			{
				if (memcmp(Locus[i - 2].name, strbuf + i1, max2(i2 - i1, (int)strlen(Locus[i - 2].name))) != 0)
				{
					sprintf(errorinf, "Error: Locus name or order mismatch at Line %d.\r\n", line);
					EXIT(errorinf);
				}
			}
			i1 = ++i2;
		}
		for (int i = 0; i < N; ++i)
		{
			fgets(strbuf, BUFLEN, f1);
			line++;
			i1 = i2 = 0;
			IND tind;
			tind.genotype.a = new int[L];
			tind.genotype.b = new int[L];
			tind.genotype.c = new int[L];
			tind.genotype.d = new int[L];
			tind.genotype.e = new int[L];
			tind.genotype.f = new int[L];
			tind.genotype.g = new int[L];
			tind.genotype.h = new int[L];
			memset(tind.genotype.a, 0xFF, L * sizeof(int));
			memset(tind.genotype.b, 0xFF, L * sizeof(int));
			memset(tind.genotype.c, 0xFF, L * sizeof(int));
			memset(tind.genotype.d, 0xFF, L * sizeof(int));
			memset(tind.genotype.e, 0xFF, L * sizeof(int));
			memset(tind.genotype.f, 0xFF, L * sizeof(int));
			memset(tind.genotype.g, 0xFF, L * sizeof(int));
			memset(tind.genotype.h, 0xFF, L * sizeof(int));
			tind.genotype.ploidy = new int[L];
			tind.popid = -1;
			tind.id = i;
			for (int j = 0; j < L + 2; ++j)
			{
				while (strbuf[i2] && strbuf[i2] != '\t')
					++i2;
				if (strbuf[i2] == 0 && j < L + 1)
				{
					sprintf(errorinf, "Error: The number of column mismatch the number of loci, missing locus? At line: %d\r\n", line);
					EXIT(errorinf);
				}
				if (j == 0)
				{
					//ind name
					tind.name = new char[i2 - i1 + 1];
					memmove(tind.name, strbuf + i1, i2 - i1);
					tind.name[i2 - i1] = 0;
					i1 = ++i2;
				}
				else if (j == 1)
				{
					//pop
					char *popname = new char[i2 - i1 + 1];
					memmove(popname, strbuf + i1, i2 - i1);
					popname[i2 - i1] = 0;
					i1 = ++i2;
					//find if exist
					for (int k = 0; k < (int)pops.size(); ++k)
					{
						if (strcmp(pops[k].name, popname) == 0)
						{
							tind.popid = k;
							break;
						}
					}
					//assign a new pop
					if (tind.popid == -1)
					{
						POP tgru;
						tgru.frecalced = false;
						tgru.name = popname;
						tind.popid = tgru.popid = (int)pops.size();
						pops.push_back(tgru);
						nPops++;
					}
				}
				else
				{
					//read genotype at locus j-2
					int tlen = 0;
					while (strbuf[i1 + tlen] == '\t')
						i1++;
					while (strbuf[i1 + tlen] != '\t' && strbuf[i1 + tlen] != '\r' && strbuf[i1 + tlen] != '\r' && strbuf[i1 + tlen] != '\n' && strbuf[i1 + tlen] != 0)
						tlen++;
					tind.genotype.ploidy[j - 2] = tlen / ndigits;
					PLOIDY = tind.genotype.ploidy[j - 2] > PLOIDY ? tind.genotype.ploidy[j - 2] : PLOIDY;
					if (tind.genotype.ploidy[j - 2] < 1 || tind.genotype.ploidy[j - 2] > MAXPLOIDY)
					{
						sprintf(errorinf, "Error: Polidy is out of range, should be 1 to 8. At line: %d.\r\n", line);
						EXIT(errorinf);
					}
					switch (tind.genotype.ploidy[j - 2])
					{
						case 8:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.h[j - 2]);
							i1 += ndigits;
						case 7:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.g[j - 2]);
							i1 += ndigits;
						case 6:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.f[j - 2]);
							i1 += ndigits;
						case 5:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.e[j - 2]);
							i1 += ndigits;
						case 4:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.d[j - 2]);
							i1 += ndigits;
						case 3:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.c[j - 2]);
							i1 += ndigits;
						case 2:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.b[j - 2]);
							i1 += ndigits;
						case 1:
							ReadInteger(strbuf + i1, ndigits, tind.genotype.a[j - 2]);
							i1 += ndigits;
					}
				}
			}
			pops[tind.popid].inds.push_back(tind);
			inds.push_back(tind);
		}
		for (int i = 0; i < N; ++i)
		{
			for (int j = 0; j < L; ++j)
			{
				if (inds[i].genotype.ploidy[j] == 2 && (inds[i].genotype.a[j] == ambiguous || inds[i].genotype.b[j] == ambiguous))
				{
					if (inds[i].genotype.a[j] == ambiguous && inds[i].genotype.b[j] == ambiguous)
						inds[i].genotype.a[j] = inds[i].genotype.b[j] = missing;
					else if (inds[i].genotype.a[j] == ambiguous)
						inds[i].genotype.a[j] = inds[i].genotype.b[j];
					else
						inds[i].genotype.b[j] = inds[i].genotype.a[j];
				}

				switch (inds[i].genotype.ploidy[j])
				{
				case 8: inds[i].genotype.h[j] = findallele(inds[i].genotype.h[j], j, i); 
				case 7: inds[i].genotype.g[j] = findallele(inds[i].genotype.g[j], j, i); 
				case 6: inds[i].genotype.f[j] = findallele(inds[i].genotype.f[j], j, i); 
				case 5: inds[i].genotype.e[j] = findallele(inds[i].genotype.e[j], j, i); 
				case 4: inds[i].genotype.d[j] = findallele(inds[i].genotype.d[j], j, i); 
				case 3: inds[i].genotype.c[j] = findallele(inds[i].genotype.c[j], j, i); 
				case 2: inds[i].genotype.b[j] = findallele(inds[i].genotype.b[j], j, i); 
				case 1: inds[i].genotype.a[j] = findallele(inds[i].genotype.a[j], j, i); 
				}

				switch (inds[i].genotype.ploidy[j])
				{
					case 8: if (inds[i].genotype.h[j] == MISSING_ALLELE) break;
					case 7: if (inds[i].genotype.g[j] == MISSING_ALLELE) break;
					case 6: if (inds[i].genotype.f[j] == MISSING_ALLELE) break;
					case 5: if (inds[i].genotype.e[j] == MISSING_ALLELE) break;
					case 4: if (inds[i].genotype.d[j] == MISSING_ALLELE) break;
					case 3: if (inds[i].genotype.c[j] == MISSING_ALLELE) break;
					case 2: if (inds[i].genotype.b[j] == MISSING_ALLELE) break;
					case 1: if (inds[i].genotype.a[j] == MISSING_ALLELE) break;
						Locus[j].typed++;
						Locus[j].maxploidy = max2(Locus[j].maxploidy, inds[i].genotype.ploidy[j]);
				}
			}
		}
		for (int j = 0; j < L; ++j)
			Locus[j].rate = Locus[j].typed / (double)N;
		
		
		if (!freqreaded)
			AlleleFrequencyNoNull();
		else
		{
			for (int i = 0; i < (int)inds.size(); ++i)
			{
				for (int l = 0; l < L; ++l)
				{
					if (IsMissingGenotype(inds[i].genotype, l)) 
						continue; 
					int p = inds[i].genotype.ploidy[l];
					int tal[] = {inds[i].genotype.a[l], inds[i].genotype.b[l], inds[i].genotype.c[l], inds[i].genotype.d[l], inds[i].genotype.e[l], inds[i].genotype.f[l], inds[i].genotype.g[l]};
					int namb = 0;
					for (int i = 0; i < p; ++i)
						if (tal[i] == AMBIGUOUS_ALLELE) namb++;
					if (namb > 0)
					{
						for (int i = 0; i < p; ++i)
							for (int j = i + 1; j < p; ++j)
								if (tal[i] == tal[j] && tal[j] != AMBIGUOUS_ALLELE)
								{
									tal[j] = AMBIGUOUS_ALLELE;
									namb++;
								}
					}
					sortuint((unsigned int *)&tal[0], p);
				}
			}
		}
		//delete[] allele;
		delete[] strbuf;
		fclose(f1);

		for (int i = 0; i < L; ++i)
		{
			/*
			double a2 = 0, a3 = 0, a4 = 0;
			double a22 = 0;
			for (int j = 0 ; j < Locus[i].n; ++j)
			{
				a2 += freobs[i][j] * freobs[i][j];
				a3 += freobs[i][j] * freobs[i][j] * freobs[i][j];
				a4 += freobs[i][j] * freobs[i][j] * freobs[i][j] * freobs[i][j];
			}
			if (iscurrent)
			{
				int n = Locus[i].typed;
				a2 = (n * a2 - 1) / (n - 1);
				a3 = (n * n * a3 - 3 * (n - 1) * a2 - 1) / (n - 1) / (n - 2);
				a4 = (n * n * n * a4 - 6 * (n - 1) * (n - 2) * a3 - 7 * (n - 1) * a2 - 1) / (n * n * n - 6 * n * n + 11 * n - 6);
			} 
			a22 = a2 * a2;
			Locus[i].a2 = a2;
			Locus[i].a22 = a2 * a2;
			Locus[i].a3 = a3;
			Locus[i].a4 = a4;
			Locus[i].u = 2 * a2 - a3;

			Locus[i].c1 = 1 - 2 * a2 + a3;
			Locus[i].c2 = 0.5 - a2 + 0.5 * a3;
			Locus[i].c3 = 2 * a2 - a3;
			Locus[i].c4 = 1 - a2 - a22 - 0.25 * a3 + 1.25 * a4;
			Locus[i].c5 = 0.25 + 0.375 * a2 - a22 - 0.875 * a3 + 1.25 * a4;
			Locus[i].c6 = a2 + a22 + 0.25 * a3 - 1.25 * a4;
			*/
			
			double A0 = Locus[i].py;
			double A1 = 1 - A0;
			double A2 = 0, A3 = 0, A4 = 0;
			for (int j = 0; j < Locus[i].n; ++j)
			{
				A2 += frenull[i][j] * frenull[i][j];
				A3 += frenull[i][j] * frenull[i][j] * frenull[i][j];
				A4 += frenull[i][j] * frenull[i][j] * frenull[i][j] * frenull[i][j];
				Locus[i].AR += freobs[i][j] * freobs[i][j];
			}
			Locus[i].AR = 1 / Locus[i].AR;

			Locus[i].A0 = A0;
			Locus[i].A02 = A0 * A0;
			Locus[i].A1 = A1;
			Locus[i].A12 = A1 * A1;
			Locus[i].A13 = A1 * A1 * A1;
			Locus[i].A2 = A2;
			Locus[i].A22 = A2 * A2;
			Locus[i].A3 = A3;
			Locus[i].A4 = A4;
			Locus[i].Au = (6 * A0 * A1 * A2 + 4 * A0 * A2 - 2 * A0 * A3 + 2 * A1 * A1 * A2 - A1 * A3) / (A1 + A0 * A1);
			
			double f1 = 1 - A0 * A0;
			double f2 = 1 - A0 * A0 * (2 - A0);
			double f3 = f1 * f1;
			
			double b = (2 * A2 * A2 - A4 + 4 * A0 * A0 * A2 + 4 * A0 * A3) / f3;
			double d = (4 * A1 * A3 - 4 * A4 + 8 * A0 * A1 * A2 - 8 * A0 * A3) / f3;
			double f = (4 * A1 * A1 * A2 - 8 * A1 * A3 - 4 * A2 * A2 + 8 * A4) / f3;
			double c = (A1 * A2 + A0 * A0 * A1 + 3 * A0 * A2) / f2;
			double e = (2 * A1 * A2 -2 * A3 + 2 * A0 * A1 * A1 - 2 * A0 * A2) / f2;
			double g = (A1 * A1 * A1 - 3 * A1 * A2 + 2 * A3) / f2;

			Locus[i].C1 = 1 - b - 0.75 * d - 0.5 * f;
			Locus[i].C2 = c - b + 0.75 * e - 0.75 * d + 0.5 * g - 0.5 * f;
			Locus[i].C3 = b + 0.75 * d + 0.5 * f;
			Locus[i].C4 = 1 - b - 0.5625 * d - 0.25 * f;
			Locus[i].C5 = c - b + 0.5625 * e - 0.5625 * d + 0.25 * g - 0.25 * f;
			Locus[i].C6 = b + 0.5625 * d + 0.25 * f;
			
			sx = new double[maxallele][35];
			sy = new double[maxallele][35];
		}
		return true;
	}
	int findallele2(int val, int l)
	{
		for (uint i = 0; i < allele[l].size; ++i)
		{
			auto p = &allele[l].GetEntry(i);
			if (p->val == val)
				return p->key; 
		}
		return -1;
	}
	int findallele(int key, int l, int i)
	{
		if (allele[l].HasKey(key))
			return allele[l][key];
		else 
		{
			char extmsg[500];
			sprintf(extmsg, "Allele is outside the allele frequency section, at individual: '%s', locus: '%s'", inds[i].name, Locus[l].name);
			EXIT(extmsg);
			return 0;
		}
	}

	//simulation function
	void simulate()
	{
		issim = true;
		double Ploid[4][19][9] ={
			{{0, 0, 1}, {0, 1, 0}, {0, 0.5, 0.5}, {0.5, 0.5, 0}, {1, 0, 0}, {0, 1, 0}, {0.5, 0.5, 0}, {1, 0, 0}, {0, 1, -1}, {0.5, 0.5, -1}, {1, 0, -1}, {0, 0, 1}, {0, 1, 0}, {0.25, 0.5, 0.25}, {0.5, 0.5, 0}, {0.5, 0.5, 0}, {0.75, 0.25, 0}, {0.75, 0.25, 0}, {1, 0, 0}},
			{{0, 0, 0, 0, 1}, {0, 0, 1, 0, 0}, {0, 0, 0.166666666666667, 0.666666666666667, 0.166666666666667}, {0.166666666666667, 0.666666666666667, 0.166666666666667, 0, 0}, {1, 0, 0, 0, 0}, {0, 0, 1, 0, 0}, {0.166666666666667, 0.666666666666667, 0.166666666666667, 0, 0}, {1, 0, 0, 0, 0}, {0, 0, 1, -1, -1}, {0.166666666666667, 0.666666666666667, 0.166666666666667, -1, -1}, {1, 0, 0, -1, -1}, {0, 0, 0, 0, 1}, {0, 0, 1, 0, 0}, {0.02777777777777777, 0.2222222222222222, 0.5, 0.2222222222222222, 0.02777777777777777}, {0.1666666666666666, 0.6666666666666666, 0.1666666666666666, 0, 0}, {0.2222222222222222, 0.5555555555555555, 0.2222222222222222, 0, 0}, {0.5277777777777777, 0.4444444444444444, 0.02777777777777777, 0, 0}, {0.5370370370370380, 0.4259259259259250, 0.0370370370370370, 0, 0}, {1, 0, 0, 0, 0, 0}},
			{{0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 1, 0, 0, 0}, {0, 0, 0, 0.05, 0.450, 0.450, 0.05}, {0.05, 0.450, 0.450, 0.05, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, 0, 0, 0}, {0.05, 0.450, 0.450, 0.05, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 1, -1, -1, -1}, {0.05, 0.450, 0.450, 0.05, -1, -1, -1}, {1, 0, 0, 0, -1, -1, -1}, {0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 1, 0, 0, 0}, {0.0025, 0.045, 0.24750, 0.410, 0.24750, 0.0450, 0.00250}, {0.050, 0.450, 0.450, 0.050, 0, 0, 0}, {0.0950, 0.4050, 0.4050, 0.0950, 0, 0, 0}, {0.33850, 0.53750, 0.12150, 0.00250, 0, 0, 0}, {0.383250, 0.488250, 0.123750, 0.004750, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0}},
			{{0, 0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0, 0, 0, 0, 0.0142857142857143, 0.228571428571429, 0.514285714285714, 0.228571428571429, 0.0142857142857143}, {0.0142857142857143, 0.228571428571429, 0.514285714285714, 0.228571428571429, 0.0142857142857143, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0.0142857142857143, 0.228571428571429, 0.514285714285714, 0.228571428571429, 0.0142857142857143, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 1, -1, -1, -1, -1}, {0.0142857142857143, 0.228571428571429, 0.514285714285714, 0.228571428571429, 0.0142857142857143, -1, -1, -1, -1}, {1, 0, 0, 0, 0, -1, -1, -1, -1}, {0, 0, 0, 0, 0, 0, 0, 0, 1}, {0, 0, 0, 0, 1, 0, 0, 0, 0}, {0.0002040816326551, 0.0065306122448980, 0.0669387755102040, 0.2416326530612240, 0.369387755102040, 0.2416326530612240, 0.0669387755102040, 0.0065306122448980, 0.0002040816326531}, {0.0142857142857158, 0.2285714285714280, 0.5142857142857140, 0.2285714285714280, 0.0142857142857142, 0, 0, 0, 0}, {0.0403674064377954, 0.2467878711251260, 0.4256894448741590, 0.2467878711251260, 0.0403674064377937, 0, 0, 0, 0}, {0.233925239483550, 0.5332813411078710, 0.2176651395251970, 0.0149241982507288, 0.0002040816326531, 0, 0, 0, 0}, {0.2731973807682180, 0.4816115126350410, 0.2177241901758620, 0.0268777720167617, 0.0005891444041173, 0, 0, 0, 0}, {1, 0, 0, 0, 0, 0, 0, 0, 0}}};
		char* od[16] = {"\t%0.0lf","\t%0.1lf","\t%0.2lf","\t%0.3lf","\t%0.4lf","\t%0.5lf","\t%0.6lf","\t%0.7lf","\t%0.8lf","\t%0.9lf","\t%0.10lf","\t%0.11lf","\t%0.12lf","\t%0.13lf","\t%0.14lf","\t%0.15lf"};
		char* relation_name[] = {"Female clone", "Mother-daughter", "Female full-sibs", "Female half-sibs", "Unrelated females", "Daughter-father, mother-son", "Female-male sibs", "Unrelated female-male", "Male clone", "Male sibs", "Unrelated males", "Clone", "Parent-offspring", "Full-sib", "Half-sib/grandparent", "Nephew", "Great-grandparent", "First cousin/grand-nephew", "Unrelated"};
		char *simulation_name[] = {"Diploid with null allele", "Tetraploid", "Tetraploid with ambiguous genotype", "Hexaploid", "Hexaploid with ambiguous genotype", "Octoploid", "Octoploid with ambiguous genotype", "Haplo-diploid", "Diplo-tetraploid", "Diplo-tetraploid with ambiguous genotype", "Triplo-hexaploid", "Triplo-hexaploid with ambiguous genotype", "Tetraplo-octoploid", "Tetraplo-octoploid with ambiguous genotype"};
		//0 Female clone
		//1 Mother-daughter
		//2 Female full-sibs
		//3 Female half-sibs
		//4 Unrelated females
		//5 Daughter-father, mother-son
		//6 Female-male sibs
		//7 Unrelated female-male
		//8 Male clone
		//9 Male sibs
		//10 Unrelated males
		//11 Clone
		//12 Parent-offspring
		//13 Full-sib
		//14 Half-sib/grandparent
		//15 Nephew
		//16 Great-grandparent
		//17 First cousin/grand-nephew
		//18 Unrelated
		
		switch ((method - 1) % 7 + 1)
		{
			case 1: rem = false;  PLOIDY = 2; break;
			case 2: rem = false;  PLOIDY = 4; break;
			case 3: rem = true;   PLOIDY = 4; break;
			case 4: rem = false;  PLOIDY = 6; break;
			case 5: rem = true;   PLOIDY = 6; break;
			case 6: rem = false;  PLOIDY = 8; break;
			case 7: rem = true;   PLOIDY = 8; break;
			default: break;
		}
		int relation_start = method > 7 ? 0 : 11;
		int relation_end = method > 7 ? 11 : 19;
		
		double bias[ESTIMATOR_NUM][19] = {0};
		double var[ESTIMATOR_NUM][19] = {0};
		double Q01[ESTIMATOR_NUM][19] = {0};
		double Q05[ESTIMATOR_NUM][19] = {0};
		double Q10[ESTIMATOR_NUM][19] = {0};
		double Q25[ESTIMATOR_NUM][19] = {0};
		double Q50[ESTIMATOR_NUM][19] = {0};
		double Q75[ESTIMATOR_NUM][19] = {0};
		double Q90[ESTIMATOR_NUM][19] = {0};
		double Q95[ESTIMATOR_NUM][19] = {0};
		double Q99[ESTIMATOR_NUM][19] = {0};
		memset(r1, 0, sizeof(double) * ESTIMATOR_NUM);
		memset(r2, 0, sizeof(double) * ESTIMATOR_NUM);
		
		int nsim2 = 0;
		for (int j = 0; j < ESTIMATOR_NUM; ++j)
			r3[j] = new double[nsim];
		
for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			nsim2 += nsim;
			deltas = Ploid[PLOIDY / 2 - 1][relationid];
			printf("\r\nSimulating relationship: %s\r\n", relation_name[relationid]);
			cdeltas = new double[PLOIDY + 1];
			double rr = 0;
			double td = 0;
			if (deltas[PLOIDY] >= 0)
				for (int i = 0; i <= PLOIDY; ++i)
				{
					rr += i * 1.0 / PLOIDY * deltas[i];
					td += deltas[i];
					cdeltas[i] = td;
				}
			else
			{
				for (int i = 0; i <= PLOIDY / 2; ++i)
				{
					rr += i * 1.0 / PLOIDY * 2 * deltas[i];
					td += deltas[i];
					cdeltas[i] = td;
				}
				for (int i = PLOIDY / 2 + 1; i <= PLOIDY; ++i)
					cdeltas[i] = -1;
			}
			double process = nsim / 80.0;
			double process1 = 0;
			
			HANDLE* hThread = new HANDLE[nthread];
			ThreadPar* par = new ThreadPar[nthread];
			for (int i = 0; i < nthread; ++i)
			{
				ThreadPar tpar = {this, i, nthread, 2, relationid};
				memmove(par + i, &tpar, sizeof(ThreadPar));
#ifdef WIN64
				unsigned int threadID;
				hThread[i] = (HANDLE)_beginthreadex(NULL, 0, &ThreadFunc, par + i, 0, &threadID);
#else
				pthread_t threadID;
				pthread_attr_init(hThread + i);
				pthread_create(&threadID, hThread + i, &ThreadFunc, (void*)(par + i)); 
#endif
			}
			
			N_c = 0;
			N_o = 0;
			while (N_c != nsim && thread_count != nsim2)
			{
				while (N_c > process1)
				{
					N_o++;
					cout << "|";
					fflush(stdout);
					process1 += process;
				}
				SLEEP(SLEEP_TIME);
			}
			while (N_o < 80)
			{
				cout << "|";
				fflush(stdout);
				N_o++;
			}
			
			/*
				for (int i = 0; i < nthread; ++i)
				{
					#ifdef WIN64
					TerminateThread(hThread[i], NULL);
					#else
					pthread_attr_destroy(hThread + i);
					#endif
				}
			*/
			delete[] hThread;
			delete[] par;
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
			{
				r1[i] /= nsim;
				r2[i] /= nsim;
				bias[i][relationid] = r1[i] - rr;
				var[i][relationid] = r2[i] - r1[i] * r1[i];
				quickSort(r3[i], 0, nsim - 1);
				Q01[i][relationid] = r3[i][(int)(nsim * 0.01)];
				Q05[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q10[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q25[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q50[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q75[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q90[i][relationid] = r3[i][(int)(nsim * 0.05)];
				Q95[i][relationid] = r3[i][(int)(nsim * 0.95)];
				Q99[i][relationid] = r3[i][(int)(nsim * 0.99)];
			}
		}
		
		for (int j = 0; j < ESTIMATOR_NUM; ++j)
			delete[] r3[j];

		FILE *f1 = fopen(output, "wb");
		if (!f1)  EXIT("Can not open output file.\r\n");
		fprintf(f1, "Relatedness coefficient calculated by PolyRelatedness V%s\r\n", VERSION);
		fprintf(f1, "    Simulation type: %s\r\n", simulation_name[method - 1]);
		fprintf(f1, "    Number of simulations: %d\r\n", nsim);
		fprintf(f1, "    Input: %s\r\n", input);
		fprintf(f1, "    Output: %s\r\n", output);
		
		struct tm *t1;
		time_t tt1;
		time(&tt1);
		t1 = localtime(&tt1);
		fprintf(f1, "    Time: %04d-%02d-%02d %02d:%02d:%02d\r\n\r\n", t1->tm_year+1900, t1->tm_mon+1, t1->tm_mday, t1->tm_hour, t1->tm_min, t1->tm_sec); 
		
		fprintf(f1, "Bias:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], bias[i][relationid]);
		}
		fprintf(f1, "\r\nVar:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], var[i][relationid]);
		}
		fprintf(f1, "\r\n1%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q01[i][relationid]);
		}
		fprintf(f1, "\r\n5%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q05[i][relationid]);
		}
		fprintf(f1, "\r\n10%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q10[i][relationid]);
		}
		fprintf(f1, "\r\n25%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q25[i][relationid]);
		}
		fprintf(f1, "\r\n50%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q50[i][relationid]);
		}
		fprintf(f1, "\r\n75%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q75[i][relationid]);
		}
		fprintf(f1, "\r\n90%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q90[i][relationid]);
		}
		fprintf(f1, "\r\n95%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q95[i][relationid]);
		}
		fprintf(f1, "\r\n99%% Percentile:\r\n");
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			fprintf(f1, "\t%s", estimator_name[i]);
		for (int relationid = relation_start; relationid < relation_end; ++relationid)
		{
			fprintf(f1, "\r\n%s", relation_name[relationid]);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
				fprintf(f1, od[outputdigits], Q99[i][relationid]);
		}
		fclose(f1);
	}
	
	//universal function for all estimators
	double estimators(int e, GENOTYPE x, GENOTYPE y)
	{
		if (issim)
		{
			//Simulating
			if ((method >= 7 || PLOIDY != 2 ) && e >= 5)
				return nan;
		}
		//if (e != 5 && e != 11 && e != 13) return nan;
		double rx;
		switch (e)
		{
			case 0: rx = Huang2014Moment(x, y); break;
			case 1: rx = Huang2015ML(x, y); break;
			case 2: rx = R_Ritland(x, y, true); break;
			case 3: rx = R_Loiselle(x, y, true); break;
			case 4: rx = R_Ritland(x, y, false); break;
			case 5: rx = R_Loiselle(x, y, false); break;
			case 6: rx = R_Weir(x, y); break;
			case 7: rx = R_Lynch(x, y); break;
			case 8: rx = R_Wang(x, y); break;
			case 9: rx = R_Thomas_Wang(x, y); break;
			case 10: rx = R_Thomas_Original(x, y); break;
			case 11: rx = R_Li(x, y); break;
			case 12: rx = R_Queller(x, y); break;
			case 13: rx = R_Huang2016DiploidA(x, y); break;
			case 14: rx = R_Huang2016DiploidB(x, y); break;
			case 15: rx = R_Anderson2D(x, y); break;
			case 16: rx = R_Milligan2D(x, y); break;
			case 17: rx = R_Milligan8D(x, y); break;
			default: return nan;
		}
		
		if (issim && rx <= 100 == false && rx > 100 == false)
			return 0;
		return rx;
	}

	//threads are not allowed to access a same memory at a same time, so I clone a class, and allocate private memory for each thread
	void Clone(Relatedness &b)
	{
		b.freobs = new double*[L];
		b.frenull = new double*[L];
		b.Locus = new LOCUS[L];
		b.sx = new double[maxallele][35];
		b.sy = new double[maxallele][35];

		memmove(b.Locus, Locus, sizeof(LOCUS) * L);
		if (cdeltas) 
		{
			b.cdeltas = new double[PLOIDY + 1];
			memmove(b.cdeltas, cdeltas, sizeof(double) * (PLOIDY + 1));
		}

		for (int i = 0; i < L; ++i)
		{
			b.freobs[i] = new double[Locus[i].n + 1];
			b.frenull[i] = new double[Locus[i].n + 1];
			memmove(b.freobs[i], freobs[i], sizeof(double) * (Locus[i].n + 1));
			memmove(b.frenull[i], frenull[i], sizeof(double) * (Locus[i].n + 1));
		}

		for (int i = 0; i < N; ++i)
		{
			b.inds[i].genotype.a = new int[L];
			b.inds[i].genotype.b = new int[L];
			b.inds[i].genotype.c = new int[L];
			b.inds[i].genotype.d = new int[L];
			b.inds[i].genotype.e = new int[L];
			b.inds[i].genotype.f = new int[L];
			b.inds[i].genotype.g = new int[L];
			b.inds[i].genotype.h = new int[L];
			b.inds[i].genotype.ploidy = new int[L];
			memmove(b.inds[i].genotype.a, inds[i].genotype.a, sizeof(int) * L);
			memmove(b.inds[i].genotype.b, inds[i].genotype.b, sizeof(int) * L);
			memmove(b.inds[i].genotype.c, inds[i].genotype.c, sizeof(int) * L);
			memmove(b.inds[i].genotype.d, inds[i].genotype.d, sizeof(int) * L);
			memmove(b.inds[i].genotype.e, inds[i].genotype.e, sizeof(int) * L);
			memmove(b.inds[i].genotype.f, inds[i].genotype.f, sizeof(int) * L);
			memmove(b.inds[i].genotype.g, inds[i].genotype.g, sizeof(int) * L);
			memmove(b.inds[i].genotype.h, inds[i].genotype.h, sizeof(int) * L);
			memmove(b.inds[i].genotype.ploidy, inds[i].genotype.ploidy, sizeof(int) * L);
		}
	}

public:
	//assign initial value for variables, and initialize functions
	Relatedness(char *indf, char *outf, int fun, int nsim1)
	{
		for (int i = 0; i <= 8; ++i)
			for (int j = 0; j <= i; ++j)
				bi[i][j] = (int)binomial(i, j);

		xorshf96init();
		issim = false;
		allele = NULL;
		cryptTable = NULL;
		Huang2012ML_Initialized = false;
		R_Anderson_Initialized = false;
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			r2[i] = r1[i] = 0;
		thread_count = 0;
		uint64 nan1 = 0xFFF8000000000000ull;
		nan = *(double*)&nan1;
		isreal = true;
		PLOIDY = 0;
		if (fun <= 0)
			EXIT("Invalid function.");
		cdeltas = 0;
		input = indf;
		output = outf;
		nsim = nsim1;
		//Initialize
		if (readfile())
		{
			if (fun >= 100)
			{
				method = fun / 100;
				simulate();
				return;
			}
			
			method = (fun - 1) / 2;
			if (method < 0 || method >= ESTIMATOR_NUM)
				EXIT("Invalid function.");
			
			if (fun % 2)
				calc();
			else
				calcpop();
		}
	}
	Relatedness(char *indf, char *outf)
	{
		for (int i = 0; i <= 8; ++i)
			for (int j = 0; j <= i; ++j)
				bi[i][j] = (int)binomial(i, j);

		xorshf96init();
		issim = false;
		
		allele = NULL;
		cryptTable = NULL;
		Huang2012ML_Initialized = false;
		R_Anderson_Initialized = false;
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			r2[i] = r1[i] = 0;
		thread_count = 0;
		uint64 nan1 = 0xFFF8000000000000ull;
		nan = *(double*)&nan1;
		isreal = true;
		PLOIDY = 0;
		cdeltas = 0;
		input = indf;
		output = outf;
		//Initialize
		if (readfile())
		{
			if (calcind())
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			else
				EXIT("\r\nFail! \r\nThe ploidy of all individuals at all locus should be 2.\r\n");
		}
	}

	void getpopfre(int p)
	{
		if (pops[p].frecalced == 1)
			return;
		else
		{
			pops[p].freobs = new double*[L];
			for (int i = 0; i < L; ++i)
			{
				pops[p].freobs[i] = new double[Locus[i].n];
				memset(pops[p].freobs[i], 0, Locus[i].n * sizeof(double));
			}
		}
		
		double** freobsbak = new double*[L];
		for (int i = 0; i < L; ++i)
		{
			freobsbak[i] = new double[Locus[i].n];
			memmove(freobsbak[i], freobs[i], sizeof(double) * Locus[i].n);
		}

		double * calleles = new double[L];
		for (int k = 0; k < 100; ++k)
		{
			for (int i = 0; i < L; ++i)
			{
				memset(pops[p].freobs[i], 0, sizeof(double) * Locus[i].n);
				calleles[i] = 0;
				for (int j = 0; j < (int)pops[p].inds.size(); ++j)
				{
					GENOTYPE x = pops[p].inds[j].genotype;
					switch (x.ploidy[i])
					{
						case 8: if (x.h[i] == MISSING_ALLELE) continue;
						case 7: if (x.g[i] == MISSING_ALLELE) continue;
						case 6: if (x.f[i] == MISSING_ALLELE) continue;
						case 5: if (x.e[i] == MISSING_ALLELE) continue;
						case 4: if (x.d[i] == MISSING_ALLELE) continue;
						case 3: if (x.c[i] == MISSING_ALLELE) continue;
						case 2: if (x.b[i] == MISSING_ALLELE) continue;
						case 1: if (x.a[i] == MISSING_ALLELE) continue;
					}
			
					switch (x.ploidy[i])
					{
						case 8: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE && x.h[i] == AMBIGUOUS_ALLELE) continue; break;
						case 7: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE && x.g[i] == AMBIGUOUS_ALLELE) continue; break;
						case 6: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE && x.f[i] == AMBIGUOUS_ALLELE) continue; break;
						case 5: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE && x.e[i] == AMBIGUOUS_ALLELE) continue; 
						case 4: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE && x.d[i] == AMBIGUOUS_ALLELE) continue; break;
						case 3: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE && x.c[i] == AMBIGUOUS_ALLELE) continue; break;
						case 2: if (x.a[i] == AMBIGUOUS_ALLELE && x.b[i] == AMBIGUOUS_ALLELE) continue; break;
						case 1: if (x.a[i] == AMBIGUOUS_ALLELE) continue; break;
					}
			
					int xx1[CPM8] = {x.a[i], x.b[i], x.c[i], x.d[i], x.e[i], x.f[i], x.g[i], x.h[i]};
					int xx[35][CPM8], xxn;	
					double xxp[35] = {0};	
					int ploidyx = x.ploidy[i];
					int cx = sort_count(xx1, ploidyx);
					xxn = getcandidate(cx, xx1, (int *)&xx[0][0], xxp, i, ploidyx, ploidyx, MAXPLOIDY);
			
					calleles[i] += x.ploidy[i];
					for (int a = 0; a < xxn; ++a)
						for (int b = 0; b < ploidyx; ++b)
							pops[p].freobs[i][xx[a][b]] += xxp[a];
				}
			}
			for (int i = 0; i < L; ++i)
			{
				for (int j = 0; j < Locus[i].n; ++j)
					pops[p].freobs[i][j] /= calleles[i];
				memmove(freobs[i], pops[p].freobs[i], sizeof(double) * Locus[i].n);
			}
		}
		
		pops[p].Hs = new double[L];
		for (int i = 0; i < L; ++i)
		{
			pops[p].Hs[i] = 1;
			for (int j = 0; j < Locus[i].n; ++j)
				pops[p].Hs[i] -= pops[p].freobs[i][j] * pops[p].freobs[i][j];

			delete[] freobsbak[i];
			memmove(freobs[i], freobsbak[i], sizeof(double) * Locus[i].n);
		}
		delete[] freobsbak;
		
	}
	void GST()
	{
		for (int i = 0; i < (int)pops.size(); ++i)
			getpopfre(i);
			
		for (int i = 0; i < L; ++i)
		{
			for (int j = 0; j < Locus[i].n; ++j)
				frenull[i][j] = 0;
			for (int p = 0; p < (int)pops.size(); ++p)
				for (int j = 0; j < Locus[i].n; ++j)
					frenull[i][j] += pops[p].freobs[i][j];
			for (int j = 0; j < Locus[i].n; ++j)
				frenull[i][j] /= pops.size();
		}

		double *Hsmean = new double[L];
		memset(Hsmean, 0, sizeof(double) * L);
		double *Ht = new double[L];
		for (int i = 0; i < L; ++i)
		{
			for (int p = 0; p < (int)pops.size(); ++p)
				Hsmean[i] += pops[p].Hs[i];

			Hsmean[i] /= pops.size();
		}
		
		double *Gst = new double[L];
		double Gstmean = 0;
		for (int i = 0; i < L; ++i)
		{
			Ht[i] = 1;
			for (int j = 0; j < Locus[i].n; ++j)
				Ht[i] -= frenull[i][j] * frenull[i][j];

			Gst[i] = 1 - Hsmean[i] / Ht[i];
			Gstmean += Gst[i] / L;
		}

		//pairwise GST
		double* pairGst = new double[pops.size() * pops.size()];
		memset(pairGst, 0, sizeof(double) * pops.size() * pops.size());

		for (int i = 0; i < L; ++i)
		{
			for (int a = 0; a < (int)pops.size(); ++a)
			{
				for (int b = 0; b < a; ++b)
				{
					double hs = (pops[a].Hs[i] + pops[b].Hs[i]) / 2;
					double ht = 1;
					for (int j = 0; j < Locus[i].n; ++j)
					{
						double pi = (pops[a].freobs[i][j] + pops[b].freobs[i][j]) / 2;
						ht -= pi * pi;
					}
					pairGst[a * pops.size() + b] = pairGst[b * pops.size() + a] += (1 - hs / ht) / L;
				}
			}
		}
	}

	//estimating population differentitation
	Relatedness(int e, char *indf, char *outf)
	{
		for (int i = 0; i <= 8; ++i)
			for (int j = 0; j <= i; ++j)
				bi[i][j] = (int)binomial(i, j);

		xorshf96init();
		issim = false;
		allele = NULL;
		cryptTable = NULL;
		Huang2012ML_Initialized = false;
		R_Anderson_Initialized = false;
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			r2[i] = r1[i] = 0;
		thread_count = 0;
		uint64 nan1 = 0xFFF8000000000000ull;
		nan = *(double*)&nan1;
		isreal = true;
		PLOIDY = 0;
		cdeltas = 0;
		input = indf;
		output = outf;
		//Initialize
		if (readfile())
		{
			switch (e)
			{
			case 1: GST(); break;
			}
			
		}
	}

	Relatedness(char *indf, char *outf, int e, double *fisinput = NULL, int fiscount = 0)
	{
		for (int i = 0; i <= 8; ++i)
			for (int j = 0; j <= i; ++j)
				bi[i][j] = (int)binomial(i, j);

		xorshf96init();
		allele = NULL;
		issim = false;
		cryptTable = NULL;
		Huang2012ML_Initialized = false;
		R_Anderson_Initialized = false;
		for (int i = 0; i < ESTIMATOR_NUM; ++i)
			r2[i] = r1[i] = 0;
		thread_count = 0;
		uint64 nan1 = 0xFFF8000000000000ull;
		nan = *(double*)&nan1;
		isreal = true;
		PLOIDY = 0;
		cdeltas = 0;
		input = indf;
		output = outf;

		//Initialize
		if (readfile())
		{
			if (estnullallele(e, fisinput, fiscount))
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			else
				EXIT("\r\nFail! \r\nThe ploidy of all individuals at all locus should be 2.\r\n");
		}
	}
	
	//free memory
	~Relatedness()
	{
		Huang2012ML_Uninitialize();
		if (isreal)
		{
			if (allele) delete[] allele;
			delete[] sx;
			delete[] sy;
			for (int i = 0; i < L; ++i)
			{
				delete[] Locus[i].name;
				delete[] freobs[i];
				delete[] frenull[i];
			}
			if (cdeltas) 
				delete[] cdeltas;
			delete[] freobs;
			delete[] frenull;
			delete[] Locus;
			for (int i = 0; i < nPops; ++i)
				delete[] pops[i].name;
			for (int i = 0; i < N; ++i)
			{
				delete[] inds[i].name;
				delete[] inds[i].genotype.a;
				delete[] inds[i].genotype.b;
				delete[] inds[i].genotype.c;
				delete[] inds[i].genotype.d;
				delete[] inds[i].genotype.e;
				delete[] inds[i].genotype.f;
				delete[] inds[i].genotype.g;
				delete[] inds[i].genotype.h;
				delete[] inds[i].genotype.ploidy;
			}
			for (int i = 0; i < (int)pops.size(); ++i)
				vector<IND>().swap(pops[i].inds);
			vector<POP>().swap(pops); 
			vector<IND>().swap(inds); 
		}
		else
		{
			//Clone
			delete[] sx;
			delete[] sy;
			for (int i = 0; i < L; ++i)
			{
				delete[] freobs[i];
				delete[] frenull[i];
			}
			if (cdeltas) 
				delete[] cdeltas;
			delete[] freobs;
			delete[] frenull;
			delete[] Locus;
			for (int i = 0; i < N; ++i)
			{
				delete[] inds[i].genotype.a;
				delete[] inds[i].genotype.b;
				delete[] inds[i].genotype.c;
				delete[] inds[i].genotype.d;
				delete[] inds[i].genotype.e;
				delete[] inds[i].genotype.f;
				delete[] inds[i].genotype.g;
				delete[] inds[i].genotype.h;
				delete[] inds[i].genotype.ploidy;
			}
			for (int i = 0; i < (int)pops.size(); ++i)
				vector<IND>().swap(pops[i].inds);
			vector<POP>().swap(pops); 
			vector<IND>().swap(inds); 
		}
	}
};

//multi-thread processing function
#ifdef WIN64
unsigned int __stdcall ThreadFunc(void * p)
#else
void* ThreadFunc(void * p)
#endif
{
#define f(r,v) ((r)-1)/((v)-1)
	srand((unsigned int)time(NULL));
	ThreadPar* p1 = (ThreadPar*) p;
	Relatedness* rreal = (Relatedness*)p1->a;
	Relatedness rclone = *(Relatedness*)p1->a;
	//lock_(&lock1);
	rreal->Clone(rclone);
	//unlock_(&lock1);
	rclone.isreal = false;
	int N, L = rreal->L, c = 0, c2 = 0;
	int total = p1->total;
	int id = p1->id;
	double * r4 = rclone.r4;
	int method = rclone.method;
	for (int i = 0; i < ESTIMATOR_NUM; ++i)
		rclone.r2[i] = rclone.r1[i] = 0;
	switch (p1->fun)
	{
		//individual inbreeding coefficinet
		case 3:
			N = rclone.N;
			for (int i = 0; i < N; ++i)
				if (i % total == id)
				{
					r4[i * 3 * (L + 1)] = f(rclone.R_Ritland1(rclone.inds[i].genotype), rclone.inds[i].genotype.ploidy[0]);
					r4[i * 3 * (L + 1) + (L + 1)] = f(rclone.R_Loiselle1(rclone.inds[i].genotype), rclone.inds[i].genotype.ploidy[0]); 
					r4[i * 3 * (L + 1) + (L + 1) + (L + 1)] = f(rclone.R_Weir1(rclone.inds[i].genotype), rclone.inds[i].genotype.ploidy[0]); 
					for (int j = 0; j < L; ++j)
					{
						r4[i * 3 * (L + 1) + j + 1] = f(rclone.R_Ritland1(rclone.inds[i].genotype, j), rclone.inds[i].genotype.ploidy[0]);
						r4[i * 3 * (L + 1) + (L + 1) + j + 1] = f(rclone.R_Loiselle1(rclone.inds[i].genotype, j), rclone.inds[i].genotype.ploidy[0]); 
						r4[i * 3 * (L + 1) + (L + 1) + (L + 1) + j + 1] = f(rclone.R_Weir1(rclone.inds[i].genotype, j), rclone.inds[i].genotype.ploidy[0]); 
					}
					//lock_(&lock1);
					rreal->N_c++;
					//unlock_(&lock1);
					c++;
				}
			break;
		//between individuals in the total population
		case 0:
			N = rclone.N;
			for (int i = 0; i < N; ++i)
				for (int j = i; j < N; ++j)
				{
					if (c2 % total == id)
					{
						r4[N * i + j] = r4[N * j + i] = rclone.estimators(method, rclone.inds[i].genotype, rclone.inds[j].genotype);
						//lock_(&lock1);
						rreal->N_c++;
						//unlock_(&lock1);
						c++;
					}
					c2++;
				}
			break;
			
		//between individuals in the same subpopulation
		case 1:
			//lock_(&lock1);
			N = (int)rreal->pops[p1->popid].inds.size();
			//unlock_(&lock1);
			for (int i = 0; i < N; ++i)
				for (int j = i; j < N; ++j)
				{
					if (c2 % total == id)
					{
						r4[N * i + j] = r4[N * j + i] = rclone.estimators(method, rclone.pops[p1->popid].inds[i].genotype, rclone.pops[p1->popid].inds[j].genotype);
						//lock_(&lock1);
						rreal->N_c++;
						//unlock_(&lock1);
						c++;
					}
					c2++;
				}
			break;
			
		//simulation
		case 2:
			//lock_(&lock1);
			L = rreal->L;
			//unlock_(&lock1);
			GENOTYPE x, y;
			x.a = new int[L];
			x.b = new int[L];
			x.c = new int[L];
			x.d = new int[L];
			x.e = new int[L];
			x.f = new int[L];
			x.g = new int[L];
			x.h = new int[L];
			x.ploidy = new int[L];
			y.a = new int[L];
			y.b = new int[L];
			y.c = new int[L];
			y.d = new int[L];
			y.e = new int[L];
			y.f = new int[L];
			y.g = new int[L];
			y.h = new int[L];
			y.ploidy = new int[L];
			
			int relationid = p1->popid;
			//lock_(&lock1);
			int nsim = rreal->nsim;
			//unlock_(&lock1);
			int total = p1->total;
			double* r1 = rclone.r1;
			double* r2 = rclone.r2;
			double** rr = rreal->r3;
			for (int j = p1->id; j < nsim; j += total)
			{
				//Generate reference genotype
				rclone.randomtype(x);
				
				//Generate conditional proband genotype
				rclone.conditionaltype(x, y, relationid);
				
				//handling the null alleles, produce observed genotypes from true genotypes
				if (method == 1)
				{
					bool flag = true;
					for (int i = 0; i < L; ++i)
					{
						if (x.a[i] == NULL_ALLELE) x.a[i] = x.b[i];
						if (x.b[i] == NULL_ALLELE) x.b[i] = x.a[i];
						if (y.a[i] == NULL_ALLELE) y.a[i] = y.b[i];
						if (y.b[i] == NULL_ALLELE) y.b[i] = y.a[i];
						if (x.a[i] == NULL_ALLELE) x.a[i] = x.b[i] = MISSING_ALLELE;
						if (y.a[i] == NULL_ALLELE) y.a[i] = y.b[i] = MISSING_ALLELE;
						if (x.a[i] >= 0 && y.a[i] >= 0) flag = false;
					}
					if (flag)
					{
						//no locus generate valid genotypes, try again
						j--;
						continue;
					}
				}
				double rx;
				for (int i = 0; i < ESTIMATOR_NUM; ++i)
				{
					rx = rclone.estimators(i, x, y);
					rr[i][j] = rx;
					r1[i] += rx; 
					r2[i] += rx * rx;
				}
				//lock_(&lock1);
				rreal->N_c++;
				//unlock_(&lock1);
				c++;
			}
			
			delete[] x.a;
			delete[] x.b;
			delete[] x.c;
			delete[] x.d;
			delete[] x.e;
			delete[] x.f;
			delete[] x.g;
			delete[] x.h;
			delete[] x.ploidy;
			delete[] y.a;
			delete[] y.b;
			delete[] y.c;
			delete[] y.d;
			delete[] y.e;
			delete[] y.f;
			delete[] y.g;
			delete[] y.h;
			delete[] y.ploidy;
			lock_(&lock1);
			for (int i = 0; i < ESTIMATOR_NUM; ++i)
			{
				rreal->r1[i] += r1[i]; 
				rreal->r2[i] += r2[i];
			}
			unlock_(&lock1);
			break;
	}
	lock_(&lock1);
	thread_count += c;
	unlock_(&lock1);
	return NULL;
}

//Genepop format converter
void rempading(char *str)
{
	int len = (int)strlen(str);
	while (len > 0 && (str[len - 1] == '\r' 
		|| str[len - 1] == '\n' 
		|| str[len - 1] == ' ' 
		|| str[len - 1] == '\t' 
		|| str[len - 1] == ',' 
		|| str[len - 1] == ';'))
	{
		len--;
		str[len] = 0;
	}
}
int getnextallele(char *str, int &p, int len, int width)
{
	while (p < len && (str[p] < '0' || str[p] > '9'))
		p++;
	if (p + 3 > len)
		return 0;//genepop missing allele
	int re = 0;
	switch (width)
	{
	case 1: sscanf(str + p, "%01d", &re); break;
	case 2: sscanf(str + p, "%02d", &re); break;
	case 3: sscanf(str + p, "%03d", &re); break;
	case 4: sscanf(str + p, "%04d", &re); break;
	default: re = 0; break;
	}
	p += width;
	return re;
}
int getwidth(char *str, int p, int len)
{
	while (p < len && (str[p] < '0' || str[p] > '9'))
		p++;
	int p0 = p;
	while (p < len && !(str[p] < '0' || str[p] > '9'))
		p++;
	return (p - p0) / 2;
}
void ConvertGenpop(char *in, char *out)
{
	FILE * f1 = fopen(in, "r");
	char *strbuf = new char[BUFLEN];
	char *strbuf2 = new char[BUFLEN];
	fgets(strbuf, BUFLEN, f1);
	vector <IND> inds;
	vector <LOCUS> loci;
	while (!feof(f1))
	{
		LOCUS tl;
		fscanf(f1, "%s", strbuf);
		tl.name = new char[strlen(strbuf) + 1];
		strcpy(tl.name, strbuf);
		rempading(tl.name);
		StrLwr(strbuf);
		if (linecmp(strbuf, "pop") == 0)
		{
			fgets(strbuf, BUFLEN, f1);
			delete [] tl.name;
			break;
		}
		loci.push_back(tl);
	}

	int l = (int)loci.size();
	map <int, int> *allele = new map <int, int>[l];
	int width = 0;
	int* allelesum = new int[l];
	memset(allelesum, 0, l * sizeof(int));
	int npop = 1;
	int indid = 0;
	while (!feof(f1))
	{
		IND tind;
		fgets(strbuf, BUFLEN, f1);
		strcpy(strbuf2, strbuf);
		rempading(strbuf2);
		StrLwr(strbuf2);
		if (strlen(strbuf2) == 0)
			break;
		if (linecmp(strbuf2, "pop") == 0)
		{
			npop++;
			continue;
		}
		sscanf(strbuf, "%s", strbuf2);
		tind.id = ++indid;
		tind.popid = npop;
		tind.genotype.a = new int[l];
		tind.genotype.b = new int[l];
		tind.name = new char[strlen(strbuf2) + 1];
		strcpy(tind.name, strbuf2);
		rempading(tind.name);
		int p = (int)strlen(tind.name) + 1;
		int len = (int)strlen(strbuf);
		width = width == 0 ? getwidth(strbuf, p, len) : width;
		for (int i = 0; i < l; ++i)
		{
			tind.genotype.a[i] = getnextallele(strbuf, p, len, width);
			tind.genotype.b[i] = getnextallele(strbuf, p, len, width);
			if (tind.genotype.b[i] && tind.genotype.a[i])
			{
				allele[i][tind.genotype.a[i]]++;
				allele[i][tind.genotype.b[i]]++;
				allelesum[i] += 2;
			}
		}
		inds.push_back(tind);
	}

	fclose(f1);

	
	int maxallele = 0;
	for (int i = 0; i < l; ++i)
	{
		if (maxallele < (int)allele[i].size())
			maxallele = (int)allele[i].size();
	}
	
	double* fretab = new double[l * maxallele];
	int* frename = new int[l * maxallele];
	memset(frename, 0xFF, l * maxallele * sizeof(int));
	for (int i = 0; i < l; ++i)
	{
		int j = 0;
		for (map<int, int>::iterator cIter = allele[i].begin(); cIter != allele[i].end(); cIter++)
		{
			
			frename[maxallele * i + j] = cIter->first;
			fretab[maxallele * i + j] = cIter->second * 1.0 / allelesum[i];
			j++;
		}
	}

	f1 = fopen(out, "w");
	fprintf(f1, "//configuration\n");
	fprintf(f1, "//#alleledigits(1~4)	#outputdigits(0~10)	#missingallele	#ambiguousallele	#nthreads(1~64)\n");
	fprintf(f1, "%d\t8\t0\t999\t1\n", width);
	fprintf(f1, "//allele frequency\n");
	for (int i = 0; i < l; ++i)
		fprintf(f1, "%s\t%d%s", loci[i].name, allele[i].size(), i == l - 1 ? "\n" : "\t");
	for (int i = 0; i < maxallele; ++i)
	{
		for (int j = 0; j < l; ++j)
		{
			if (frename[maxallele * j + i] == -1)
				fprintf(f1, "\t%s", j == l - 1 ? "\n" : "\t");
			else switch (width)
			{
			case 1: fprintf(f1, "%01d\t%0.15lf%s", frename[j * maxallele + i], fretab[j * maxallele + i], j == l - 1 ? "\n" : "\t"); break;
			case 2: fprintf(f1, "%02d\t%0.15lf%s", frename[j * maxallele + i], fretab[j * maxallele + i], j == l - 1 ? "\n" : "\t"); break;
			case 3: fprintf(f1, "%03d\t%0.15lf%s", frename[j * maxallele + i], fretab[j * maxallele + i], j == l - 1 ? "\n" : "\t"); break;
			case 4: fprintf(f1, "%04d\t%0.15lf%s", frename[j * maxallele + i], fretab[j * maxallele + i], j == l - 1 ? "\n" : "\t"); break;
			}
		}
	}

	fprintf(f1, "//locus weight\n");
	for (int i = 0; i < l; ++i)
		fprintf(f1, "1\t");
	fprintf(f1, "\n");

	fprintf(f1, "//genotype\nInd\tPop\t");
	for (int i = 0; i < l; ++i)
		fprintf(f1, "%s%s", loci[i].name, i == l - 1 ? "\n" : "\t");
	for (int i = 0; i < (int)inds.size(); ++i)
	{
		fprintf(f1, "%s\tPop%d\t", inds[i].name, inds[i].popid);
		for (int j = 0; j < l; ++j)
		{
			switch (width)
			{
			case 1: fprintf(f1, "%01d%01d%s", inds[i].genotype.a[j], inds[i].genotype.b[j], j == l - 1 ? "\n" : "\t"); break;
			case 2: fprintf(f1, "%02d%02d%s", inds[i].genotype.a[j], inds[i].genotype.b[j], j == l - 1 ? "\n" : "\t"); break;
			case 3: fprintf(f1, "%03d%03d%s", inds[i].genotype.a[j], inds[i].genotype.b[j], j == l - 1 ? "\n" : "\t"); break;
			case 4: fprintf(f1, "%04d%04d%s", inds[i].genotype.a[j], inds[i].genotype.b[j], j == l - 1 ? "\n" : "\t"); break;
			default: fprintf(f1, "%03d%03d%s", inds[i].genotype.a[j], inds[i].genotype.b[j], j == l - 1 ? "\n" : "\t"); break;
			}
		}
	}
	fprintf(f1, "//end of file");
	fclose(f1);
	delete[] strbuf;
	delete[] strbuf2;
	delete[] fretab;
	delete[] frename;
	delete[] allelesum;
	for (int i = 0; i < l; ++i)
	{
		delete[] loci[i].name;
		map<int,int>().swap(allele[i]);
	}
	delete[] allele;
	for (int i = 0; i < (int)inds.size(); ++i)
	{
		delete[] inds[i].name;
		delete[] inds[i].genotype.a;
		delete[] inds[i].genotype.b;
	}
	vector<LOCUS>().swap(loci); 
	vector<IND>().swap(inds); 
}

//Main menu
char input[BUFLEN];
char output[BUFLEN];
int main(int argc, char** argv)
{
	switch (argc)
	{
	case 1:
	case 0:
	case -1: iscommand = false; break;
	default: iscommand = true; break;
	}
	
	if (argc != -1)
	{
		sprintf(input, "in.txt");
		sprintf(output, "out.txt");
	}

	int fun1 = 0;
	int fun2 = 0;
	int nsim = 30000;
	int scanresult = 0;
	char *within[] = {"Between all individuals", "Within populations"};
	bool iswithin = false;
	//Relatedness(input, output, 5, false);//xxx
	char path[BUFLEN];
	fun2 = BUFLEN - 1;
#ifdef __APPLE__
	_NSGetExecutablePath(path, (uint32_t*)&fun2);
	fun2 = strlen(path);
	while (fun2 >= 0)
	{
		if (path[fun2] == '/')
		{
			path[fun2 + 1] = NULL;
			break;
		}
		fun2--;
	}
#endif
#ifdef WIN64
	GetCurrentDirectoryA(fun2, path);
	InitializeCriticalSection(&lock1);
#endif
#ifdef linux
	fun2 = readlink("/proc/self/exe", path, fun2);
	fun2 = strlen(path);
	while (fun2 >= 0)
	{
		if (path[fun2] == '/')
		{
			path[fun2 + 1] = NULL;
			break;
		}
		fun2--;
	}
#endif
	chdir(path);
	fun2 = 0;
	
	fflush(stdin);
	//Command
	if (argc >= 5)
	{
		iscommand = true;
		//exe
		//method
		//input
		//output
		//nsim
		int fun1 = 0;
		sscanf(argv[1], "%s", input);
		sscanf(argv[2], "%s", output);
		if (argv[3][0] == 'e' || argv[3][0] == 'E')
		{
			fun2 = 0;
			sscanf(argv[4], "%d", &fun1);
			if (fun1 < 1 || fun1 > 16) 
				EXIT("Error: Unknown estimator type at parameter 4.\r\n");

			if (argc > 5)  
				iswithin = argv[5][0] != '0';

			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				Relatedness(input, output, fun1 * 2 - 1 + iswithin, nsim);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
		else if (argv[3][0] == 'i' || argv[3][0] == 'I')
		{
			fun2 = 0;

			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				Relatedness(input, output);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
		else if (argv[3][0] == 's' || argv[3][0] == 'S')
		{
			sscanf(argv[4], "%d", &fun2);
			if (fun2 < 1 || fun2 > 14) 
				EXIT("Error: Unknown simulation type at parameter 4.\r\n");

			if (argc <= 5)  
				nsim = 10000;
			else
				sscanf(argv[5], "%d", &nsim);

			fun1 = 0;
			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				Relatedness(input, output, 100 * fun2, nsim);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
		else if (argv[3][0] == 'n' || argv[3][0] == 'N')
		{
			sscanf(argv[4], "%d", &fun2);
			if (fun2 < 1 || fun2 > 6) 
				EXIT("Error: Unknown null allele estimator at parameter 4.\r\n");

			double *fis = new double[argc - 5];
			for (int i = 5; i < argc; ++i)
				sscanf(argv[i], "%lf", &fis[i - 5]);
			
			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				Relatedness(input, output, fun2, fis, argc - 5);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
		else
				EXIT("Error: Unknown function at parameter 3.\r\n");

	}

	//Menu
	for (;;)
	{
		fflush(stdin);
#ifdef WIN64
		system("cls");
#else
		system("clear");
#endif
		printf("PolyRelatedness V%s\r\n", VERSION);
		printf("   Estimating the relatedness under a varity of situations.\r\n");
		printf("   Functions:\r\n");
		printf("     1. Huang et al. 2014 MOM estimator (ploidy <= 8);\r\n");
		printf("     2. Huang et al. 2015 ML estimator (ploidy <= 8);\r\n");
		printf("     3. Ritland 1996 estimator (corrected by Eqn 7 in Huang et al. 2015 MER, ploidy <= 8);\r\n");
		printf("     4. Loiselle et al. 1995 estimator (corrected by Eqn 7 in Huang et al. 2015 MER, ploidy <= 8);\r\n");
		printf("     5. Ritland 1996 estimator (ploidy <= 8);\r\n");
		printf("     6. Loiselle et al. 1995 estimator (ploidy <= 8);\r\n");
		printf("     7. Weir 1996 estimator (ploidy <= 8);\r\n");
		printf("     8. Diploid estimators (ploidy = 2);\r\n");
		printf("     9. Simulations;\r\n");
		printf("     10. Switch calculation mode, current: %s;\r\n", within[iswithin]);
		printf("     11. Change I/O files: \r\n");
		printf("         input: %s\r\n", input);
		printf("         output: %s\r\n", output);
		printf("     12. Convert from Genepop V4 format (ploidy = 2);\r\n");
		printf("     13. Estimate the frequency of null alleles (ploidy = 2);\r\n");
		printf("     14. Estimate individual inbreeding coefficient (ploidy <= 8, not aneuploid);\r\n");
		printf("     0. Exit.\r\n");
		printf("     \r\n");
		printf("     Working directory: \r\n          %s\r\n", path);
		printf("     Bug report & suggestions: huangkang@nwu.edu.cn\r\n");
		scanresult = scanf("%d", &fun1);
		if (fun1 > 14 || fun1 < 0 || scanresult == EOF || scanresult == 0);
		else if (fun1 == 0)
			exit(0);
		else if (fun1 == 12)
		{
			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				ConvertGenpop(input, output);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
		else if (fun1 == 13) for (;;)
		{
			printf("Null allele estimators:\r\n");
			printf("     1. Chakraborty et al. (1992, MOM);\r\n");
			printf("     2. Summers & Amos (1997, MOM);\r\n");
			printf("     3. Kalinowski & Taper (2006, *EM);\r\n");
			printf("     4. Chybicki & Burczyk (2008, #EM);\r\n");
			printf("     5. van Oosterhout et al. (2006, *#EM);\r\n");
			printf("     6. van Oosterhout et al. (2004, MOM);\r\n");
			//printf("     7. Brookfield 1st (1996, MOM);\r\n");
			//printf("     8. Brookfield 2nd (1996, MOM);\r\n");
			printf("     0. Return;\r\n\r\n");
			printf("     * means estimator consider PCR fail (beta), # for consider inbreeding (f).\r\n");
			scanresult = scanf("%d", &fun2);
			if (fun2 > 6 || fun2 < 0 || scanresult == EOF || scanresult == 0)
			{
				fflush(stdin);
				continue;
			}
			if (fun2 == 0) 
				break;
			Relatedness(input, output, fun2);
			break;
		}
		else if (fun1 == 14) for (;;)
		{
			Relatedness(input, output);
			break;
		}
		else if (fun1 == 10)
		{
			iswithin = !iswithin;
			continue;
		}
		else if (fun1 == 8) for (;;)
		{
			printf("Diploid estimators:\r\n");
			printf("     1. Lynch & Ritland 1999 *;\r\n");
			printf("     2. Wang 2002 *;\r\n");
			printf("     3. Thomas 2010 *;\r\n");
			printf("     4. Thomas 2010 weighted by Wang 2002 *;\r\n");
			printf("     5. Li et al. 1993;\r\n");
			printf("     6. Queller & Goodnight 1989;\r\n");
			printf("     7. Huang 2016 A for diploid *;\r\n");
			printf("     8. Huang 2016 B for diploid *;\r\n");
			printf("     9. Anderson & Weir 2007 *;\r\n");
			printf("     10. Milligan 2003 *;\r\n");
			printf("     11. Milligan 2003 for inbreeding *.\r\n");
			printf("     0. Return;\r\n\r\n");
			printf("     * denotes estimators corrected for null alleles.\r\n");
			scanresult = scanf("%d", &fun1);
			if (fun1 > 11 || fun1 < 0 || scanresult == EOF || scanresult == 0)
			{
				fflush(stdin);
				continue;
			}
			if (fun1 == 0) break;
			fun1 += 7;
			goto run;
		}
		else if (fun1 == 11)
		{
#ifdef WIN64
			fflush(stdin);
#else
			setbuf(stdin, NULL);
#endif
			printf(" New input:");
			fgets(input, BUFLEN, stdin);
			
#ifdef WIN64
			fflush(stdin);
#else
			setbuf(stdin, NULL);
#endif
			printf(" New output:");
			fgets(output, BUFLEN, stdin);
			for (int i = 0; i < BUFLEN; ++i)
				if (input[i] == '\r' || input[i] == '\n')
				{
					input[i] = NULL;
					break;
				}
			for (int i = 0; i < BUFLEN; ++i)
				if (output[i] == '\r' || output[i] == '\n')
				{
					output[i] = NULL;
					break;
				}
			continue;
		}
		else if (fun1 == 9) for (;;)
		{
			printf("Simulation functions:\r\n");
			printf("     1. Diploid with null alleles;\r\n");
			printf("     2. Tetraploid;\r\n");
			printf("     3. Tetraploid with ambiguous genotype;\r\n");
			printf("     4. Hexaploid;\r\n");
			printf("     5. Hexaploid with ambiguous genotype;\r\n");
			printf("     6. Octoploid;\r\n");
			printf("     7. Octoploid with ambiguous genotype;\r\n");
			printf("     8. Haplo-diploid;\r\n");
			printf("     9. Diplo-tetraploid;\r\n");
			printf("     10. Diplo-tetraploid with ambiguous genotype;\r\n");
			printf("     11. Triplo-hexaploid;\r\n");
			printf("     12. Triplo-hexaploid with ambiguous genotype;\r\n");
			printf("     13. Tetraplo-octoploid;\r\n");
			printf("     14. Tetraplo-octoploid with ambiguous genotype;\r\n");
			printf("     0. Return;\r\n");
			scanresult = scanf("%d", &fun2);
			if (fun2 > 14 || fun2 < 0 || scanresult == EOF || scanresult == 0)
			{
				fflush(stdin);
				continue;
			}
			if (fun2 == 0) break;

			mainreinptx1:
			printf("Input the number of simulations you want to perform:\r\n");
			scanresult = scanf("%d", &nsim);
			if (nsim <= 0 || scanresult == EOF || scanresult == 0)
			{
				fflush(stdin);
				goto mainreinptx1;
			}
			goto run;
		}
		else
		{
			run:
			FILE * f1 = fopen(input, "rb");
			if (NULL != f1)
			{
				fclose(f1);
				Relatedness(input, output, fun1 * 2 - 1 + iswithin + 100 * fun2, nsim);
				EXIT("\r\nDone! \r\nResults are saved in the output file.\r\n");
			}
			else
				EXIT("Error: Input file is missing!\r\n");
		}
	}
}