call vcvars.bat amd64
cl.exe /c /O2 /Ot /Oy- /nologo /w /D "WIN64" /D "_CONSOLE" /D "_UNICODE" /D "UNICODE" /EHsc /MT /GS- /Gy- /fp:precise /Zc:wchar_t /Zc:forScope /GR- "ml2.cpp"
cl.exe /c /O2 /Ot /Oy- /nologo /w /D "WIN64" /D "_CONSOLE" /D "_UNICODE" /D "UNICODE" /EHsc /MT /GS- /Gy- /fp:precise /Zc:wchar_t /Zc:forScope /GR- "ml.cpp"
cl.exe /c /O2 /Ot /Oy- /nologo /w /D "WIN64" /D "_CONSOLE" /D "_UNICODE" /D "UNICODE" /EHsc /MT /GS- /Gy- /fp:precise /Zc:wchar_t /Zc:forScope /GR- "mom.cpp"
cl.exe /c /O2 /Ot /Oy- /nologo /w /D "WIN64" /D "_CONSOLE" /D "_UNICODE" /D "UNICODE" /EHsc /MT /GS- /Gy- /fp:precise /Zc:wchar_t /Zc:forScope /GR- "polyrelatedness.cpp"
cl.exe /OUT:PolyRelatedness.exe /subsystem:console /INCREMENTAL:NO /NOLOGO /MANIFEST /ALLOWISOLATION /MANIFESTUAC:"level='asInvoker' uiAccess='false'" /MACHINE:X64 /SUBSYSTEM:CONSOLE /OPT:REF /OPT:ICF /TLBID:1 /DYNAMICBASE /NXCOMPAT /MACHINE:X64 polyrelatedness.obj ml.obj ml2.obj mom.obj
