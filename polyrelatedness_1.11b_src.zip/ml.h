#ifndef ML_H
#define ML_H
#include <iostream>
#include <map>
using namespace std;
extern void ml_assign(int sumploidy, double *f, int *a, double *c, int IBS);
#endif