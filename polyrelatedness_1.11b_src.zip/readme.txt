# to compile the binary, Visual Studio or GCC compiler is required.

Procedures:
1. open command mode or terminal
2. cd to the directory of source files
3. run the makefile
for linux: rename 'makefile_linux.txt' to 'makefile', then execute 'make' command
for mac: rename 'makefile_mac.txt' to 'makefile', then execute 'make' command
for windows: execute makefile_visualstudio.bat
4. wait for 20 min or longer, then the binary will be genearted
   e.g. 'polyrelatedness.out', 'polyrelatedness', or 'polyrelatedness.exe'