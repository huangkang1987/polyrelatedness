#ifndef MOM_H
#define MOM_H
#include <iostream>
double mp(double base, int index);
void mom_assign1(int refmode, double e[2][2], double *f, int *xx);
void mom_assign2(int refmode, double e[3][3], double *f, int *xx);
void mom_assign3(int refmode, double e[4][4], double *f, int *xx);
void mom_assign4(int refmode, double e[5][5], double *f, int *xx);
void mom_assign5(int refmode, double e[6][6], double *f, int *xx);
void mom_assign6(int refmode, double e[7][7], double *f, int *xx);
void mom_assign7(int refmode, double e[8][8], double *f, int *xx);
void mom_assign8(int refmode, double e[9][9], double *f, int *xx);
#endif